import React, { useState } from 'react';
import { User, EventCategory, EventSeverity, AiAnalysis } from '../types.js';
import { ALL_CATEGORIES, CATEGORIES, getTrustTierBadge } from '../utils/categories.js';
import {
  X,
  MapPin,
  Calendar,
  Sparkles,
  ShieldAlert,
  Send,
  Loader2,
  FileText,
  Link2,
  AlertTriangle,
  Info,
  CheckCircle,
  Radio,
  Tag,
} from 'lucide-react';

interface StructuredSubmitModalProps {
  currentUser: User | null;
  onClose: () => void;
  onSubmitSuccess: () => void;
  onUserCreated?: (user: User) => void;
}

const CITY_PRESETS = [
  { name: 'New Delhi, India', country: 'India', state: 'Delhi NCR', city: 'New Delhi', lat: 28.6139, lng: 77.209 },
  { name: 'Mumbai, India', country: 'India', state: 'Maharashtra', city: 'Mumbai', lat: 19.076, lng: 72.8777 },
  { name: 'Bengaluru, India', country: 'India', state: 'Karnataka', city: 'Bengaluru', lat: 12.9716, lng: 77.5946 },
  { name: 'Guwahati, Assam', country: 'India', state: 'Assam', city: 'Guwahati', lat: 26.1445, lng: 91.7362 },
  { name: 'London, United Kingdom', country: 'United Kingdom', state: 'England', city: 'London', lat: 51.5074, lng: -0.1278 },
  { name: 'New York, USA', country: 'United States', state: 'New York', city: 'New York', lat: 40.7128, lng: -74.006 },
  { name: 'Tokyo, Japan', country: 'Japan', state: 'Tokyo', city: 'Tokyo', lat: 35.6762, lng: 139.6503 },
  { name: 'Berlin, Germany', country: 'Germany', state: 'Berlin', city: 'Berlin', lat: 52.52, lng: 13.405 },
  { name: 'Nairobi, Kenya', country: 'Kenya', state: 'Nairobi', city: 'Nairobi', lat: -1.2921, lng: 36.8219 },
];

export const StructuredSubmitModal: React.FC<StructuredSubmitModalProps> = ({
  currentUser,
  onClose,
  onSubmitSuccess,
  onUserCreated,
}) => {
  const [step, setStep] = useState<number>(1);
  const [guestCallsign, setGuestCallsign] = useState('');
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<EventCategory>('Corruption');
  const [subcategory, setSubcategory] = useState('');
  const [description, setDescription] = useState('');

  // Location
  const [country, setCountry] = useState('India');
  const [state, setState] = useState('Delhi NCR');
  const [city, setCity] = useState('New Delhi');
  const [locationDesc, setLocationDesc] = useState('');
  const [lat, setLat] = useState<number>(28.6139);
  const [lng, setLng] = useState<number>(77.209);

  // Time & Severity
  const [eventDate, setEventDate] = useState(new Date().toISOString().slice(0, 16));
  const [severity, setSeverity] = useState<EventSeverity>('high');

  // Evidence & Statement
  const [imageUrl, setImageUrl] = useState('');
  const [sourceTitle, setSourceTitle] = useState('');
  const [sourceUrl, setSourceUrl] = useState('');
  const [reporterStatement, setReporterStatement] = useState('');

  // AI Pre-check State
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<AiAnalysis | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleCityPreset = (preset: typeof CITY_PRESETS[0]) => {
    setCountry(preset.country);
    setState(preset.state);
    setCity(preset.city);
    setLat(preset.lat);
    setLng(preset.lng);
  };

  const handleDetectLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setLat(Math.round(pos.coords.latitude * 10000) / 10000);
          setLng(Math.round(pos.coords.longitude * 10000) / 10000);
          setLocationDesc('Detected via GPS sensor');
        },
        (err) => {
          console.warn('Geolocation failed', err);
        }
      );
    }
  };

  // Run AI Pre-check
  const handleRunAiPrecheck = async () => {
    if (!title || !description) {
      setErrorMsg('Please enter a title and description before running AI analysis.');
      return;
    }
    setErrorMsg(null);
    setIsAnalyzing(true);

    try {
      const res = await fetch('/api/events/ai-precheck', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          description,
          category,
          subcategory,
          country,
          city,
          statement: reporterStatement,
        }),
      });

      const data = await res.json();
      if (data.success && data.analysis) {
        setAiAnalysis(data.analysis);
        if (data.analysis.suggestedCategory && !category) {
          setCategory(data.analysis.suggestedCategory);
        }
        if (data.analysis.suggestedSubcategory && !subcategory) {
          setSubcategory(data.analysis.suggestedSubcategory);
        }
      }
    } catch (err: any) {
      setErrorMsg('AI Pre-check request failed. Please check network.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Final Submit
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) {
      setErrorMsg('Title and description are required.');
      return;
    }

    setErrorMsg(null);
    setIsSubmitting(true);

    try {
      // Determine active reporter
      const resolvedPseudonym = (
        currentUser?.codeName ||
        currentUser?.reporterProfile?.pseudonym ||
        currentUser?.name ||
        guestCallsign.trim() ||
        'Field_Reporter'
      );

      const activeUser: User = currentUser || {
        id: `user-reporter-${Date.now()}`,
        name: resolvedPseudonym,
        codeName: resolvedPseudonym,
        designation: 'Field Reporter',
        email: `${resolvedPseudonym.toLowerCase().replace(/[^a-z0-9]/g, '') || 'reporter'}@watchtower.local`,
        role: 'field-reporter',
        createdAt: new Date().toISOString(),
        reporterProfile: {
          anonymousId: `REP-${Math.floor(1000 + Math.random() * 9000)}`,
          pseudonym: resolvedPseudonym,
          trustScore: 0,
          tier: 'Rookie',
          approvedReportsCount: 0,
          rejectedReportsCount: 0,
          falseReportsCount: 0,
          totalSubmitted: 0,
          joinedDate: new Date().toISOString(),
        },
      };

      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${activeUser.id}`,
        'x-user-data': encodeURIComponent(JSON.stringify(activeUser)),
      };

      const res = await fetch('/api/events/submit', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          reporterUser: activeUser,
          reporterPseudonym: resolvedPseudonym,
          title,
          description,
          category,
          subcategory: subcategory || 'Field Report',
          location: {
            country,
            state,
            city,
            description: locationDesc,
            lat,
            lng,
          },
          eventDate: new Date(eventDate).toISOString(),
          severity,
          images: imageUrl ? [imageUrl] : [],
          sources: sourceTitle ? [{ title: sourceTitle, url: sourceUrl }] : [],
          reporterStatement,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        if (!currentUser && onUserCreated) {
          onUserCreated(activeUser);
        }
        onSubmitSuccess();
        onClose();
      } else {
        setErrorMsg(data.error || 'Submission failed. Please verify required fields.');
      }
    } catch (err: any) {
      setErrorMsg('Failed to submit report. Server error.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const reporterTier = currentUser?.reporterProfile?.tier || 'Rookie';
  const tierMeta = getTrustTierBadge(reporterTier);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div
        id="structured-submission-modal"
        className="relative w-full max-w-3xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden my-auto text-slate-100 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80 sticky top-0 z-20">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-sky-500/20 border border-sky-500/40 flex items-center justify-center text-sky-400">
              <Radio className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white leading-tight">
                Structured Field Report Submission
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Reporter Identity: {currentUser?.codeName || currentUser?.reporterProfile?.pseudonym || currentUser?.name || (guestCallsign.trim() || 'Field Reporter')} •{' '}
                <span className={tierMeta.className + ' px-1.5 py-0.2 rounded font-semibold text-[10px]'}>
                  {reporterTier} Tier
                </span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Indicator Navigation */}
        <div className="px-6 py-2.5 bg-slate-950/40 border-b border-slate-800 flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setStep(1)}
              className={`flex items-center gap-1.5 pb-1 border-b-2 transition-all ${
                step === 1 ? 'border-sky-400 text-sky-300 font-bold' : 'border-transparent text-slate-400'
              }`}
            >
              1. Event Basics
            </button>
            <button
              onClick={() => setStep(2)}
              className={`flex items-center gap-1.5 pb-1 border-b-2 transition-all ${
                step === 2 ? 'border-sky-400 text-sky-300 font-bold' : 'border-transparent text-slate-400'
              }`}
            >
              2. Geographic Location
            </button>
            <button
              onClick={() => setStep(3)}
              className={`flex items-center gap-1.5 pb-1 border-b-2 transition-all ${
                step === 3 ? 'border-sky-400 text-sky-300 font-bold' : 'border-transparent text-slate-400'
              }`}
            >
              3. Severity & Evidence
            </button>
            <button
              onClick={() => setStep(4)}
              className={`flex items-center gap-1.5 pb-1 border-b-2 transition-all ${
                step === 4 ? 'border-sky-400 text-sky-300 font-bold' : 'border-transparent text-slate-400'
              }`}
            >
              4. AI Check & Review
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 flex-1">
          {errorMsg && (
            <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-700/60 text-rose-300 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* STEP 1: EVENT BASICS */}
          {step === 1 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {!currentUser && (
                <div className="p-3 bg-sky-950/20 border border-sky-800/40 rounded-xl space-y-1">
                  <label className="block text-xs font-semibold text-sky-300 uppercase tracking-wider">
                    Reporter Callsign / Pseudonym (Optional)
                  </label>
                  <input
                    type="text"
                    value={guestCallsign}
                    onChange={(e) => setGuestCallsign(e.target.value)}
                    placeholder="e.g. Field_Reporter_01, Sentinel_Sky"
                    className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700 rounded-lg text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500 font-mono"
                  />
                  <p className="text-[11px] text-slate-400">
                    A secure field reporter identity starting at trust score 0 will be assigned.
                  </p>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Report Headline / Title <span className="text-rose-400">*</span>
                </label>
                <input
                  id="input-report-title"
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Major Municipal Water Pipeline Rupture Floods Tech Corridor"
                  className="w-full px-4 py-2.5 bg-slate-950/80 border border-slate-700 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Category <span className="text-rose-400">*</span>
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as EventCategory)}
                    className="w-full px-3.5 py-2.5 bg-slate-950/80 border border-slate-700 rounded-xl text-sm text-slate-100 focus:outline-none focus:border-sky-500 cursor-pointer"
                  >
                    {ALL_CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Subcategory / Specific Incident Type
                  </label>
                  <input
                    type="text"
                    value={subcategory}
                    onChange={(e) => setSubcategory(e.target.value)}
                    placeholder="e.g. Urban Pipeline Failure, Flash Flood"
                    className="w-full px-3.5 py-2.5 bg-slate-950/80 border border-slate-700 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Detailed Field Description <span className="text-rose-400">*</span>
                </label>
                <textarea
                  id="input-report-desc"
                  rows={4}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Provide objective, structured facts: What happened? Who was affected? What emergency measures are in progress?"
                  className="w-full px-4 py-2.5 bg-slate-950/80 border border-slate-700 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500 leading-relaxed resize-none"
                />
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-5 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-white text-xs font-semibold shadow transition-all"
                >
                  Next: Geographic Location →
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: GEOGRAPHIC LOCATION */}
          {step === 2 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* Quick City Presets */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Quick Location Presets
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {CITY_PRESETS.map((p, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleCityPreset(p)}
                      className={`text-xs px-2.5 py-1 rounded-lg border font-mono transition-all ${
                        city === p.city
                          ? 'bg-sky-500/20 text-sky-300 border-sky-500/50'
                          : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 border-slate-700/60'
                      }`}
                    >
                      {p.name}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={handleDetectLocation}
                    className="text-xs px-2.5 py-1 rounded-lg bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 hover:bg-indigo-500/30 font-mono flex items-center gap-1"
                  >
                    <MapPin className="w-3 h-3" /> Detect GPS
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Country *</label>
                  <input
                    type="text"
                    required
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950/80 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">State / Province</label>
                  <input
                    type="text"
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950/80 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">City / District *</label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950/80 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Latitude (°N) *</label>
                  <input
                    type="number"
                    step="0.0001"
                    required
                    value={lat}
                    onChange={(e) => setLat(parseFloat(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-950/80 border border-slate-700 rounded-xl text-xs font-mono text-slate-100 focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Longitude (°E) *</label>
                  <input
                    type="number"
                    step="0.0001"
                    required
                    value={lng}
                    onChange={(e) => setLng(parseFloat(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-950/80 border border-slate-700 rounded-xl text-xs font-mono text-slate-100 focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1">Specific Location Notes / Landmark</label>
                <input
                  type="text"
                  value={locationDesc}
                  onChange={(e) => setLocationDesc(e.target.value)}
                  placeholder="e.g. Ring Road interchange near river drainage canal"
                  className="w-full px-3 py-2 bg-slate-950/80 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="flex justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs hover:bg-slate-700"
                >
                  ← Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="px-5 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-white text-xs font-semibold shadow transition-all"
                >
                  Next: Severity & Evidence →
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: SEVERITY & EVIDENCE */}
          {step === 3 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Incident Date & Time
                  </label>
                  <input
                    type="datetime-local"
                    value={eventDate}
                    onChange={(e) => setEventDate(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-sky-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Assessed Severity Level
                  </label>
                  <select
                    value={severity}
                    onChange={(e) => setSeverity(e.target.value as EventSeverity)}
                    className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-sky-500 cursor-pointer"
                  >
                    <option value="critical">Critical (Mass casualty / major emergency)</option>
                    <option value="high">High (Severe regional impact / high fraud)</option>
                    <option value="medium">Moderate (Significant local interest)</option>
                    <option value="low">Low (Standard observational notice)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Supporting Image URL (Optional)
                </label>
                <input
                  type="url"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Source / Reference Title</label>
                  <input
                    type="text"
                    value={sourceTitle}
                    onChange={(e) => setSourceTitle(e.target.value)}
                    placeholder="e.g. Official Municipal Bulletin #82"
                    className="w-full px-3 py-2 bg-slate-950/80 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Source URL</label>
                  <input
                    type="url"
                    value={sourceUrl}
                    onChange={(e) => setSourceUrl(e.target.value)}
                    placeholder="https://..."
                    className="w-full px-3 py-2 bg-slate-950/80 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Reporter Statement (How you confirmed this information)
                </label>
                <textarea
                  rows={2}
                  value={reporterStatement}
                  onChange={(e) => setReporterStatement(e.target.value)}
                  placeholder="e.g. Direct eye-witness observation; cross-referenced with emergency dispatch radio."
                  className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-sky-500 resize-none"
                />
              </div>

              <div className="flex justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs hover:bg-slate-700"
                >
                  ← Back
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setStep(4);
                    if (!aiAnalysis) handleRunAiPrecheck();
                  }}
                  className="px-5 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-white text-xs font-semibold shadow transition-all"
                >
                  Next: AI Check & Review →
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: AI PRE-CHECK & SUBMISSION */}
          {step === 4 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* AI Precheck Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-950/40 via-slate-900 to-sky-950/40 border border-indigo-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-sky-400 animate-spin" />
                    <span className="text-xs font-mono font-bold text-sky-300">
                      GEMINI AI REPORT PRE-CHECK
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={handleRunAiPrecheck}
                    disabled={isAnalyzing}
                    className="flex items-center gap-1 text-[11px] font-mono text-sky-400 hover:text-sky-300"
                  >
                    {isAnalyzing ? (
                      <>
                        <Loader2 className="w-3 h-3 animate-spin" /> Analyzing...
                      </>
                    ) : (
                      'Re-run AI Analysis'
                    )}
                  </button>
                </div>

                {isAnalyzing ? (
                  <div className="py-6 text-center space-y-2">
                    <Loader2 className="w-6 h-6 text-sky-400 animate-spin mx-auto" />
                    <p className="text-xs text-slate-300 font-mono">
                      Running Gemini neural classification & risk assessment...
                    </p>
                  </div>
                ) : aiAnalysis ? (
                  <div className="space-y-2 text-xs">
                    <p className="text-slate-200 leading-relaxed italic">
                      "{aiAnalysis.rawAiAssessment}"
                    </p>

                    <div className="flex flex-wrap items-center gap-2 pt-1 font-mono text-[11px]">
                      <span className="px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 border border-sky-500/30">
                        Risk: {aiAnalysis.riskLevel.toUpperCase()}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        Confidence: {Math.round(aiAnalysis.confidence * 100)}%
                      </span>
                    </div>

                    {aiAnalysis.suggestedTags && aiAnalysis.suggestedTags.length > 0 && (
                      <div className="flex flex-wrap gap-1 pt-1">
                        {aiAnalysis.suggestedTags.map((tag, idx) => (
                          <span
                            key={idx}
                            className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700"
                          >
                            #{tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400">
                    Click re-run to trigger Gemini AI classification and risk audit.
                  </p>
                )}
              </div>

              {/* Submission Summary Checklist */}
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2 text-xs">
                <p className="font-semibold text-slate-200">Review Submission:</p>
                <p className="text-slate-300">
                  <span className="text-slate-500">Headline:</span> {title}
                </p>
                <p className="text-slate-300">
                  <span className="text-slate-500">Location:</span> {city}, {country} ({lat.toFixed(2)}°, {lng.toFixed(2)}°)
                </p>
                <p className="text-slate-300">
                  <span className="text-slate-500">Category:</span> {category} ({subcategory})
                </p>
                <p className="text-[11px] text-slate-400 pt-1 border-t border-slate-800 font-mono">
                  Report will be logged under protected pseudonym{' '}
                  <span className="text-sky-300 font-semibold">{currentUser?.codeName || currentUser?.reporterProfile?.pseudonym || (guestCallsign.trim() || 'Field Reporter')}</span>{' '}
                  and submitted to the live intelligence grid.
                </p>
              </div>

              <div className="flex justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs hover:bg-slate-700"
                >
                  ← Back
                </button>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white text-xs font-bold shadow-lg shadow-sky-500/20 transition-all active:scale-95 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" /> Submitting...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" /> Submit Field Report
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};
