import React from 'react';
import { User, GlobalEvent } from '../types.js';
import { UserDashboard } from './UserDashboard.js';

interface ReporterProfilePanelProps {
  isOpen?: boolean;
  onClose: () => void;
  currentUser: User | null;
  events: GlobalEvent[];
  onSelectEvent?: (event: GlobalEvent) => void;
  onOpenSubmitModal?: () => void;
  onSignOut?: () => void;
  onOpenAuthModal?: () => void;
}

export const ReporterProfilePanel: React.FC<ReporterProfilePanelProps> = ({
  isOpen = true,
  onClose,
  currentUser,
  events,
  onSelectEvent,
  onOpenSubmitModal,
  onSignOut,
  onOpenAuthModal,
}) => {
  return (
    <UserDashboard
      isOpen={isOpen}
      onClose={onClose}
      currentUser={currentUser}
      events={events}
      onSelectEvent={onSelectEvent}
      onOpenSubmitModal={onOpenSubmitModal}
      onSignOut={onSignOut || (() => {})}
      onOpenAuthModal={onOpenAuthModal}
    />
  );
};
