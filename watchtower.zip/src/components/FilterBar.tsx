import React from 'react';
import { ALL_CATEGORIES, CATEGORIES, getCategoryMeta } from '../utils/categories.js';
import { EventCategory, EventSeverity } from '../types.js';
import { Flame, Layers, SlidersHorizontal, Sparkles } from 'lucide-react';

interface FilterBarProps {
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
  selectedSeverity: string;
  onSelectSeverity: (sev: string) => void;
  isHotOnly: boolean;
  onToggleHotOnly: () => void;
  totalEventsCount: number;
  viewLayout: 'split' | 'globe-only' | 'feed-only';
  onChangeViewLayout: (layout: 'split' | 'globe-only' | 'feed-only') => void;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  selectedCategory,
  onSelectCategory,
  selectedSeverity,
  onSelectSeverity,
  isHotOnly,
  onToggleHotOnly,
  totalEventsCount,
  viewLayout,
  onChangeViewLayout,
}) => {
  return (
    <div className="w-full bg-slate-900/80 backdrop-blur-md border-b border-slate-800/80 py-2.5 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        {/* Category Pills Slider */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar w-full md:w-auto py-0.5">
          <button
            id="cat-all"
            onClick={() => onSelectCategory('All')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
              selectedCategory === 'All'
                ? 'bg-sky-500 text-white font-semibold shadow-md shadow-sky-500/20'
                : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700/60'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            All Events
          </button>

          {ALL_CATEGORIES.map((cat) => {
            const meta = CATEGORIES[cat];
            const Icon = meta.icon;
            const isSelected = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => onSelectCategory(cat)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
                  isSelected
                    ? `${meta.bgColor} ${meta.color} font-semibold border ${meta.borderColor} shadow-sm`
                    : 'bg-slate-800/80 text-slate-400 hover:bg-slate-700 hover:text-slate-200 border border-slate-700/40'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {cat}
              </button>
            );
          })}
        </div>

        {/* Secondary Filters: Hot Alerts, Severity, Layout */}
        <div className="flex items-center gap-2.5 shrink-0 self-end md:self-auto">
          {/* Hot Alert Toggle Button */}
          <button
            id="toggle-hot-filter"
            onClick={onToggleHotOnly}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
              isHotOnly
                ? 'bg-red-500/25 text-red-300 border border-red-500/60 shadow-lg shadow-red-500/20 animate-pulse'
                : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 border border-slate-700/60'
            }`}
          >
            <Flame className={`w-3.5 h-3.5 ${isHotOnly ? 'text-red-400' : 'text-slate-500'}`} />
            <span>Hot Alerts Only</span>
          </button>

          {/* Severity Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-800/80 border border-slate-700/60 rounded-xl px-2.5 py-1">
            <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedSeverity}
              onChange={(e) => onSelectSeverity(e.target.value)}
              className="bg-transparent text-xs text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="All" className="bg-slate-900 text-slate-200">
                All Severities
              </option>
              <option value="critical" className="bg-slate-900 text-red-400">
                Critical
              </option>
              <option value="high" className="bg-slate-900 text-orange-400">
                High
              </option>
              <option value="medium" className="bg-slate-900 text-amber-400">
                Moderate
              </option>
              <option value="low" className="bg-slate-900 text-slate-400">
                Low
              </option>
            </select>
          </div>

          {/* Result Count Indicator */}
          <span className="text-[11px] font-mono text-slate-400 px-2 py-1 rounded-lg bg-slate-800/60 border border-slate-700/40">
            {totalEventsCount} {totalEventsCount === 1 ? 'Event' : 'Events'}
          </span>
        </div>
      </div>
    </div>
  );
};
