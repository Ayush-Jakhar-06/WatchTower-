import React, { useState } from 'react';
import { GlobalEvent, User } from '../types.js';
import { getCategoryMeta, getSeverityBadge, getTrustTierBadge } from '../utils/categories.js';
import {
  X,
  MapPin,
  Calendar,
  Clock,
  Flame,
  ThumbsUp,
  ThumbsDown,
  ShieldCheck,
  ShieldAlert,
  Sparkles,
  ExternalLink,
  Globe2,
  AlertTriangle,
  FileText,
  UserCheck,
  CheckCircle2,
  Ban,
  Tag,
  Share2,
  Check,
  Trash2,
} from 'lucide-react';

interface EventDetailModalProps {
  event: GlobalEvent | null;
  onClose: () => void;
  currentUser: User | null;
  onVote: (eventId: string, type: 'up' | 'down') => void;
  onFocusGlobe: (eventId: string) => void;
  onAdminModerate?: (eventId: string, action: 'approve' | 'reject' | 'mark_false', reason?: string) => void;
  onAdminToggleHot?: (eventId: string) => void;
  onAdminDelete?: (eventId: string) => void;
}

export const EventDetailModal: React.FC<EventDetailModalProps> = ({
  event,
  onClose,
  currentUser,
  onVote,
  onFocusGlobe,
  onAdminModerate,
  onAdminToggleHot,
  onAdminDelete,
}) => {
  const [copied, setCopied] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [showRejectInput, setShowRejectInput] = useState<'reject' | 'mark_false' | null>(null);

  if (!event) return null;

  const meta = getCategoryMeta(event.category);
  const CategoryIcon = meta.icon;
  const sev = getSeverityBadge(event.severity);
  const tierMeta = getTrustTierBadge(event.anonymousReporter.tier);

  const userVote = currentUser ? event.trustMetrics.userVotes?.[currentUser.id] : undefined;
  const isAdmin = currentUser?.role === 'admin';

  const totalVotes = event.trustMetrics.upvotes + event.trustMetrics.downvotes;
  const trustPercent =
    totalVotes > 0 ? Math.round((event.trustMetrics.upvotes / totalVotes) * 100) : 50;

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div
        id="event-detail-modal-container"
        className="relative w-full max-w-3xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden my-auto text-slate-100 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Action Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60 sticky top-0 z-20">
          <div className="flex items-center gap-2">
            <span
              className={`flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-semibold border ${meta.bgColor} ${meta.color} ${meta.borderColor}`}
            >
              <CategoryIcon className="w-4 h-4" />
              {event.category}
            </span>
            <span className="text-xs font-mono text-slate-400">
              {event.subcategory}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              title="Copy link"
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Main Title & Status Tags */}
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              {event.isHotAlert && (
                <span className="flex items-center gap-1 text-xs font-bold px-2.5 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/40 animate-pulse font-mono">
                  <Flame className="w-3.5 h-3.5" />
                  HOT ALERT
                </span>
              )}
              <span className={`text-xs font-mono font-semibold px-2.5 py-0.5 rounded-lg ${sev.className}`}>
                SEVERITY: {sev.label}
              </span>
              <span className="text-xs font-mono px-2.5 py-0.5 rounded-lg bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                {event.trustMetrics.verificationBadge}
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-bold text-white leading-tight font-sans">
              {event.title}
            </h2>
          </div>

          {/* Location & Time Info Card */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 text-xs">
            <div className="space-y-1.5">
              <div className="flex items-center gap-1.5 text-slate-400">
                <MapPin className="w-4 h-4 text-sky-400" />
                <span className="font-semibold text-slate-200">
                  {event.location.city}, {event.location.state ? `${event.location.state}, ` : ''}
                  {event.location.country}
                </span>
              </div>
              <p className="text-slate-400 pl-5 text-[11px]">
                {event.location.description || 'Target coordinates verified'}
              </p>
              <div className="pl-5 pt-1 flex items-center gap-2">
                <span className="font-mono text-[10px] text-slate-500">
                  {event.location.lat.toFixed(4)}° N, {event.location.lng.toFixed(4)}° E
                </span>
                <button
                  onClick={() => {
                    onFocusGlobe(event.id);
                    onClose();
                  }}
                  className="text-sky-400 hover:text-sky-300 text-[11px] font-medium flex items-center gap-1"
                >
                  <Globe2 className="w-3.5 h-3.5" /> Focus on 3D Globe
                </button>
              </div>
            </div>

            <div className="space-y-1.5 sm:border-l sm:border-slate-800 sm:pl-4">
              <div className="flex items-center gap-1.5 text-slate-400">
                <Calendar className="w-4 h-4 text-slate-400" />
                <span className="text-slate-200 font-medium">
                  Event Date: {new Date(event.eventDate).toLocaleDateString()}
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-slate-400">
                <Clock className="w-4 h-4 text-slate-400" />
                <span className="text-slate-300 text-[11px]">
                  Logged: {new Date(event.submissionDate).toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* Full Description & Executive Summary */}
          <div className="space-y-3">
            <div>
              <h4 className="text-xs font-mono font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                Executive Briefing
              </h4>
              <p className="text-sm font-medium text-slate-200 leading-relaxed p-3.5 rounded-xl bg-slate-800/40 border border-slate-700/40">
                {event.summary}
              </p>
            </div>

            <div>
              <h4 className="text-xs font-mono font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                Detailed Field Report
              </h4>
              <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-line font-normal">
                {event.description}
              </p>
            </div>
          </div>

          {/* AI Situational Intelligence Panel */}
          {event.aiAnalysis && (
            <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-950/30 via-slate-900 to-sky-950/30 border border-indigo-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sky-400">
                  <Sparkles className="w-4 h-4 text-sky-400" />
                  <span className="text-xs font-mono font-bold tracking-wider">
                    GEMINI AI SITUATIONAL PRE-CHECK
                  </span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 border border-sky-500/30">
                  Confidence {Math.round(event.aiAnalysis.confidence * 100)}%
                </span>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed italic">
                "{event.aiAnalysis.rawAiAssessment}"
              </p>

              {event.aiAnalysis.sensitivityFlags && event.aiAnalysis.sensitivityFlags.length > 0 && (
                <div className="space-y-1 pt-1">
                  <span className="text-[11px] font-mono text-amber-400 font-semibold flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" /> Sensitivity & Verification Notes:
                  </span>
                  <ul className="text-xs text-slate-400 space-y-1 pl-4 list-disc">
                    {event.aiAnalysis.sensitivityFlags.map((flag, idx) => (
                      <li key={idx}>{flag}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* Tags */}
          {event.tags && event.tags.length > 0 && (
            <div>
              <h4 className="text-xs font-mono font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5" /> Intelligence Tags
              </h4>
              <div className="flex flex-wrap gap-1.5">
                {event.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="text-xs px-2.5 py-1 rounded-lg bg-slate-800/80 text-slate-300 border border-slate-700/60 font-mono"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Anonymous Reporter & Trust Tier Card */}
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-sky-400 font-mono font-bold">
                {event.anonymousReporter.pseudonym.slice(0, 2).toUpperCase()}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-white">
                    {event.anonymousReporter.pseudonym}
                  </span>
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 border border-slate-700">
                    {event.anonymousReporter.anonymousId}
                  </span>
                </div>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded border inline-block mt-0.5 ${tierMeta.className}`}>
                  {tierMeta.label}
                </span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 max-w-xs text-left sm:text-right">
              Public Identity Protected. Real identity verified & audited by Platform Admins.
            </p>
          </div>

          {/* Community Trust Voting Panel */}
          <div className="p-5 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider">
                  Community Trust Rating
                </h4>
                <p className="text-[11px] text-slate-400">
                  {currentUser
                    ? 'Registered user vote cast directly influences trust calculation'
                    : 'Log in to vote on this intelligence report'}
                </p>
              </div>

              <div className="text-right">
                <span className="text-lg font-bold font-mono text-white">
                  {event.trustMetrics.netTrustScore >= 0 ? `+${event.trustMetrics.netTrustScore}` : event.trustMetrics.netTrustScore}
                </span>
                <p className="text-[10px] font-mono text-slate-400">{totalVotes} TOTAL VOTES</p>
              </div>
            </div>

            {/* Trust Meter Bar */}
            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden flex">
              <div
                className="bg-emerald-500 h-full transition-all duration-500"
                style={{ width: `${trustPercent}%` }}
              />
              <div
                className="bg-rose-500 h-full transition-all duration-500"
                style={{ width: `${100 - trustPercent}%` }}
              />
            </div>

            {/* Voting Buttons */}
            <div className="flex items-center justify-between pt-1">
              <span className="text-[11px] text-emerald-400 font-mono font-medium">
                {trustPercent}% Trustworthy
              </span>

              <div className="flex items-center gap-2">
                <button
                  id="btn-vote-up"
                  onClick={() => onVote(event.id, 'up')}
                  title={!currentUser ? 'Sign in to vote / verify' : 'Upvote verification'}
                  className={`flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    userVote === 'up'
                      ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                  }`}
                >
                  <ThumbsUp className="w-3.5 h-3.5" />
                  <span>Trust (+1)</span>
                </button>

                <button
                  id="btn-vote-down"
                  onClick={() => onVote(event.id, 'down')}
                  title={!currentUser ? 'Sign in to vote / dispute' : 'Downvote dispute'}
                  className={`flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    userVote === 'down'
                      ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/20'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                  }`}
                >
                  <ThumbsDown className="w-3.5 h-3.5" />
                  <span>Dispute (-1)</span>
                </button>
              </div>
            </div>
          </div>

          {/* Admin Control Actions (Visible to Admin only) */}
          {isAdmin && onAdminModerate && (
            <div className="p-4 rounded-2xl bg-purple-950/30 border border-purple-500/40 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-purple-300">
                  <ShieldAlert className="w-4 h-4" />
                  <span className="text-xs font-mono font-bold uppercase tracking-wider">
                    ADMIN MODERATION CONTROL PANEL
                  </span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  CURRENT STATUS: {event.status.toUpperCase()}
                </span>
              </div>

              {event.reporterId && (
                <p className="text-xs text-slate-300 font-mono">
                  Reporter ID: <span className="text-purple-300 font-semibold">{event.reporterId}</span> (Admin Identity Disclosure Access)
                </p>
              )}

              <div className="flex flex-wrap items-center gap-2 pt-1">
                {event.status !== 'published' && (
                  <button
                    onClick={() => onAdminModerate(event.id, 'approve')}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-xl shadow transition-all"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Approve & Publish (+10 Trust on 3 milestone)
                  </button>
                )}

                {onAdminToggleHot && (
                  <button
                    onClick={() => onAdminToggleHot(event.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      event.isHotAlert
                        ? 'bg-red-500/30 text-red-300 border border-red-500/60'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
                    }`}
                  >
                    <Flame className="w-3.5 h-3.5" />
                    {event.isHotAlert ? 'Demote Hot Alert' : 'Promote to Hot Alert'}
                  </button>
                )}

                <button
                  onClick={() => setShowRejectInput(showRejectInput === 'reject' ? null : 'reject')}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-xl border border-slate-700 transition-all"
                >
                  <Ban className="w-3.5 h-3.5 text-amber-400" />
                  Reject Report
                </button>

                <button
                  onClick={() =>
                    setShowRejectInput(showRejectInput === 'mark_false' ? null : 'mark_false')
                  }
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 text-xs font-semibold rounded-xl border border-rose-700/60 transition-all"
                >
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                  Mark Confirmed False (-25 Penalty)
                </button>

                {onAdminDelete && (
                  <button
                    onClick={() => {
                      if (
                        window.confirm(
                          'Permanently purge this report from the Watchtower network? This cannot be undone.'
                        )
                      ) {
                        onAdminDelete(event.id);
                        onClose();
                      }
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-red-900/70 hover:bg-red-800 text-red-200 text-xs font-semibold rounded-xl border border-red-700/70 transition-all ml-auto"
                    title="Permanently remove report from registry"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-red-300" />
                    Delete Report
                  </button>
                )}
              </div>

              {showRejectInput && (
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-700 space-y-2 mt-2">
                  <label className="text-xs text-slate-300 font-medium">
                    {showRejectInput === 'mark_false'
                      ? 'Reason for False Report Penalty (-25 Trust Score Deduction):'
                      : 'Reason for Rejection:'}
                  </label>
                  <input
                    type="text"
                    value={rejectReason}
                    onChange={(e) => setRejectReason(e.target.value)}
                    placeholder="Enter factual explanation or reason..."
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-sky-500"
                  />
                  <div className="flex justify-end gap-2">
                    <button
                      onClick={() => setShowRejectInput(null)}
                      className="px-3 py-1 text-xs text-slate-400 hover:text-slate-200"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => {
                        onAdminModerate(event.id, showRejectInput, rejectReason);
                        setShowRejectInput(null);
                        setRejectReason('');
                      }}
                      className="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold"
                    >
                      Confirm Action
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
