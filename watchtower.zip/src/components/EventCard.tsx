import React from 'react';
import { GlobalEvent, User } from '../types.js';
import { getCategoryMeta, getSeverityBadge, getTrustTierBadge } from '../utils/categories.js';
import {
  MapPin,
  Calendar,
  Flame,
  ThumbsUp,
  ThumbsDown,
  ShieldCheck,
  Globe2,
  ExternalLink,
  ChevronRight,
  Sparkles,
} from 'lucide-react';

interface EventCardProps {
  event: GlobalEvent;
  isSelected: boolean;
  currentUser: User | null;
  onSelect: () => void;
  onFocusGlobe: (e: React.MouseEvent) => void;
  onVote: (type: 'up' | 'down', e: React.MouseEvent) => void;
}

export const EventCard: React.FC<EventCardProps> = ({
  event,
  isSelected,
  currentUser,
  onSelect,
  onFocusGlobe,
  onVote,
}) => {
  const meta = getCategoryMeta(event.category);
  const CategoryIcon = meta.icon;
  const sev = getSeverityBadge(event.severity);
  const tierMeta = getTrustTierBadge(event.anonymousReporter.tier);

  const userVote = currentUser ? event.trustMetrics.userVotes?.[currentUser.id] : undefined;

  return (
    <div
      id={`event-card-${event.id}`}
      onClick={onSelect}
      className={`group relative p-4 rounded-2xl transition-all cursor-pointer border ${
        isSelected
          ? 'bg-slate-900/95 border-sky-500/80 shadow-xl shadow-sky-500/10 ring-1 ring-sky-500/30'
          : 'bg-slate-900/70 hover:bg-slate-900/90 border-slate-800 hover:border-slate-700 shadow-md'
      }`}
    >
      {/* Top Header: Category Badge + Severity + Hot Alert */}
      <div className="flex items-center justify-between gap-2 mb-2.5">
        <div className="flex items-center gap-2">
          <span
            className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg text-xs font-semibold border ${meta.bgColor} ${meta.color} ${meta.borderColor}`}
          >
            <CategoryIcon className="w-3.5 h-3.5" />
            {event.category}
          </span>
          <span className="text-[11px] font-mono text-slate-400 truncate max-w-[140px]">
            {event.subcategory}
          </span>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {event.isHotAlert && (
            <span className="flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/40">
              <Flame className="w-3 h-3 text-red-400 animate-pulse" />
              HOT
            </span>
          )}
          <span className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded-md ${sev.className}`}>
            {sev.label}
          </span>
        </div>
      </div>

      {/* Title */}
      <h3 className="text-sm font-semibold text-white group-hover:text-sky-300 transition-colors line-clamp-2 mb-1.5 leading-snug">
        {event.title}
      </h3>

      {/* Summary */}
      <p className="text-xs text-slate-300 line-clamp-2 mb-3 leading-relaxed">
        {event.summary}
      </p>

      {/* Location & Time */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 mb-3 pt-2.5 border-t border-slate-800/80">
        <div className="flex items-center gap-1 text-slate-300">
          <MapPin className="w-3.5 h-3.5 text-sky-400 shrink-0" />
          <span className="truncate max-w-[180px]">
            {event.location.city}, {event.location.country}
          </span>
        </div>
        <div className="flex items-center gap-1 text-[11px] text-slate-400 font-mono">
          <Calendar className="w-3 h-3 text-slate-500" />
          {new Date(event.eventDate).toLocaleDateString(undefined, {
            month: 'short',
            day: 'numeric',
          })}
        </div>
      </div>

      {/* Anonymous Reporter Badge & Trust Voting Controls */}
      <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800/60 text-xs">
        {/* Public Anonymous Reporter Tag */}
        <div className="flex items-center gap-1.5">
          <span className="text-[11px] text-slate-400 font-mono">
            By <span className="text-slate-200 font-semibold">{event.anonymousReporter.pseudonym}</span>
          </span>
          <span
            className={`text-[9px] font-mono px-1.5 py-0.2 rounded border ${tierMeta.className}`}
          >
            {event.anonymousReporter.tier}
          </span>
        </div>

        {/* Action Buttons: Focus Globe & Vote */}
        <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
          <button
            onClick={onFocusGlobe}
            title="Focus in 3D Globe"
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-sky-500/20 text-slate-400 hover:text-sky-300 border border-slate-700/60 transition-all"
          >
            <Globe2 className="w-3.5 h-3.5" />
          </button>

          {/* Upvote */}
          <button
            onClick={(e) => onVote('up', e)}
            title={currentUser ? 'Vote Trustworthy (+1)' : 'Sign in to vote on trust score'}
            className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-mono font-medium transition-all ${
              userVote === 'up'
                ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-500/50'
                : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700/80 hover:text-white border border-slate-700/50'
            }`}
          >
            <ThumbsUp className="w-3 h-3" />
            <span>{event.trustMetrics.upvotes}</span>
          </button>

          {/* Downvote */}
          <button
            onClick={(e) => onVote('down', e)}
            title={currentUser ? 'Vote Suspicious / Untrustworthy (-1)' : 'Sign in to vote on trust score'}
            className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-mono font-medium transition-all ${
              userVote === 'down'
                ? 'bg-rose-500/25 text-rose-300 border border-rose-500/50'
                : 'bg-slate-800/80 text-slate-400 hover:bg-slate-700/80 hover:text-slate-200 border border-slate-700/50'
            }`}
          >
            <ThumbsDown className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );
};
