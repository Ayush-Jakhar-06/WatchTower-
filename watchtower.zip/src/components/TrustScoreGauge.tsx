import React from 'react';
import { TrustTier } from '../types.js';

interface TrustScoreGaugeProps {
  score: number; // 0 to 200
  tier: TrustTier;
  size?: 'sm' | 'md' | 'lg';
}

export const TrustScoreGauge: React.FC<TrustScoreGaugeProps> = ({
  score = 0,
  tier = 'Rookie',
}) => {
  // Clamp score between 0 and 200
  const clampedScore = Math.max(0, Math.min(200, score));
  const fraction = clampedScore / 200;

  // Arc calculations
  const cx = 130;
  const cy = 125;
  const r = 90;
  const arcLength = Math.PI * r; // ~282.74
  const strokeDashoffset = arcLength * (1 - fraction);

  // Needle angle in radians: from PI (left, 0) to 0 (right, 200)
  const angleDeg = 180 - fraction * 180;
  const angleRad = (angleDeg * Math.PI) / 180;

  const needleLength = 70;
  const needleTipX = cx + needleLength * Math.cos(angleRad);
  const needleTipY = cy - needleLength * Math.sin(angleRad);

  // Determine tier color accent
  const getTierAccent = () => {
    if (clampedScore <= 50) {
      return {
        text: 'text-amber-400',
        bg: 'bg-amber-500/20 border-amber-500/40 text-amber-300',
        needleColor: '#f59e0b',
        glow: 'shadow-amber-500/20',
      };
    }
    if (clampedScore <= 170) {
      return {
        text: 'text-emerald-400',
        bg: 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300',
        needleColor: '#10b981',
        glow: 'shadow-emerald-500/20',
      };
    }
    return {
      text: 'text-sky-400',
      bg: 'bg-sky-500/20 border-sky-500/40 text-sky-300',
      needleColor: '#0ea5e9',
      glow: 'shadow-sky-500/20',
    };
  };

  const accent = getTierAccent();

  return (
    <div className="flex flex-col items-center select-none">
      <div className="relative w-[260px] h-[145px] flex items-center justify-center">
        <svg
          viewBox="0 0 260 145"
          className="w-full h-full overflow-visible"
        >
          <defs>
            {/* Multi-tier gradient track: Red/Amber -> Emerald -> Sky */}
            <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#ef4444" />
              <stop offset="25%" stopColor="#f59e0b" />
              <stop offset="70%" stopColor="#10b981" />
              <stop offset="100%" stopColor="#06b6d4" />
            </linearGradient>

            <filter id="needleGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="3" floodColor={accent.needleColor} floodOpacity="0.6" />
            </filter>
          </defs>

          {/* Background Track Arc */}
          <path
            d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
            fill="none"
            stroke="#1c2230"
            strokeWidth="14"
            strokeLinecap="round"
          />

          {/* Zone Dividers (Tick Marks) */}
          {/* Tick 0 (Rookie start) */}
          <line x1="40" y1="125" x2="48" y2="125" stroke="#475569" strokeWidth="2" />
          {/* Tick 50 (Veteran threshold: 45 degrees from left) */}
          <line
            x1={cx + (r - 8) * Math.cos((135 * Math.PI) / 180)}
            y1={cy - (r - 8) * Math.sin((135 * Math.PI) / 180)}
            x2={cx + (r + 8) * Math.cos((135 * Math.PI) / 180)}
            y2={cy - (r + 8) * Math.sin((135 * Math.PI) / 180)}
            stroke="#64748b"
            strokeWidth="2"
          />
          {/* Tick 170 (Virtuoso threshold: ~27 degrees from right) */}
          <line
            x1={cx + (r - 8) * Math.cos((27 * Math.PI) / 180)}
            y1={cy - (r - 8) * Math.sin((27 * Math.PI) / 180)}
            x2={cx + (r + 8) * Math.cos((27 * Math.PI) / 180)}
            y2={cy - (r + 8) * Math.sin((27 * Math.PI) / 180)}
            stroke="#64748b"
            strokeWidth="2"
          />
          {/* Tick 200 (Max) */}
          <line x1="212" y1="125" x2="220" y2="125" stroke="#475569" strokeWidth="2" />

          {/* Dynamic Active Trust Score Arc */}
          <path
            d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
            fill="none"
            stroke="url(#gaugeGradient)"
            strokeWidth="14"
            strokeLinecap="round"
            strokeDasharray={arcLength}
            strokeDashoffset={strokeDashoffset}
            className="transition-all duration-700 ease-out"
          />

          {/* Needle */}
          <line
            x1={cx}
            y1={cy}
            x2={needleTipX}
            y2={needleTipY}
            stroke={accent.needleColor}
            strokeWidth="3.5"
            strokeLinecap="round"
            filter="url(#needleGlow)"
            className="transition-all duration-700 ease-out"
          />

          {/* Center Hub */}
          <circle cx={cx} cy={cy} r="8" fill="#0f141f" stroke={accent.needleColor} strokeWidth="3" />
          <circle cx={cx} cy={cy} r="3" fill="#ffffff" />
        </svg>

        {/* Center Numerical Overlay */}
        <div className="absolute top-[52px] flex flex-col items-center text-center pointer-events-none">
          <span className="text-3xl font-black font-mono tracking-tight text-white drop-shadow">
            {clampedScore}
          </span>
          <span className="text-[10px] font-mono font-semibold tracking-wider text-slate-400 -mt-1 uppercase">
            / 200 PTS
          </span>
        </div>
      </div>

      {/* Under-Gauge Range Legend */}
      <div className="w-[260px] flex justify-between items-center text-[10px] font-mono text-slate-400 px-2 -mt-2">
        <span className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-red-500 inline-block" />
          0 (Rookie)
        </span>
        <span className="text-slate-400">50 (Veteran)</span>
        <span className="flex items-center gap-1">
          170+ (Virtuoso)
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 inline-block" />
        </span>
      </div>

      {/* Current Tier Badge */}
      <div className="mt-2">
        <span
          className={`inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-xs font-mono font-bold uppercase tracking-wider border shadow-sm ${accent.bg}`}
        >
          <span className="w-2 h-2 rounded-full bg-current animate-pulse" />
          {tier.toUpperCase()} TIER
        </span>
      </div>
    </div>
  );
};
