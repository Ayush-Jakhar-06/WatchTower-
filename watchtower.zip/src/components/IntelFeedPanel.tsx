import React, { useState } from 'react';
import {
  Radio,
  Volume2,
  VolumeX,
  RefreshCw,
  Search,
  SlidersHorizontal,
  Flame,
  Shield,
  MapPin,
  ExternalLink,
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  PanelLeftClose,
  Video,
  FileText,
  Lock,
  Compass,
  AlertTriangle,
} from 'lucide-react';
import { GlobalEvent, User } from '../types.js';

interface IntelFeedPanelProps {
  events: GlobalEvent[];
  selectedEventId: string | null;
  currentUser: User | null;
  onSelectEvent: (event: GlobalEvent) => void;
  onFocusGlobe: (eventId: string) => void;
  onVote: (eventId: string, type: 'up' | 'down') => void;
  onRefresh: () => void;
  loading: boolean;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedFilter: 'ALL' | 'PULSE' | 'NEWS' | 'HIGH' | 'RADAR';
  setSelectedFilter: (filter: 'ALL' | 'PULSE' | 'NEWS' | 'HIGH' | 'RADAR') => void;
  onOpenRadar?: () => void;
  panelState?: 'standard' | 'expanded' | 'collapsed';
  onToggleExpand?: () => void;
  onCollapse?: () => void;
}

export const IntelFeedPanel: React.FC<IntelFeedPanelProps> = ({
  events,
  selectedEventId,
  currentUser,
  onSelectEvent,
  onFocusGlobe,
  onVote,
  onRefresh,
  loading,
  searchQuery,
  setSearchQuery,
  selectedFilter,
  setSelectedFilter,
  onOpenRadar,
  panelState = 'standard',
  onToggleExpand,
  onCollapse,
}) => {
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Filter events based on active feed filter
  const filteredEvents = events.filter((evt) => {
    if (selectedFilter === 'PULSE' && !evt.isHotAlert) return false;
    if (selectedFilter === 'NEWS' && !evt.isNewsIntel) return false;
    if (selectedFilter === 'HIGH' && evt.severity !== 'high' && evt.severity !== 'critical') return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        evt.title.toLowerCase().includes(q) ||
        evt.summary.toLowerCase().includes(q) ||
        evt.location.country.toLowerCase().includes(q) ||
        evt.location.city.toLowerCase().includes(q) ||
        evt.tags.some((t) => t.toLowerCase().includes(q));
      if (!match) return false;
    }
    return true;
  });

  // Pinned Community Top 24h item (e.g. North Korean missile deployment)
  const top24hEvent = events.find((e) => e.id === 'evt-top-1') || events[0];

  return (
    <div className="w-full h-full flex flex-col bg-[#0b0d12] border-r border-[#1a1d26] text-slate-200 select-none overflow-hidden">
      {/* Daily Briefing Top Bar */}
      <div className="px-3.5 py-2 bg-[#08090d] border-b border-[#171922] flex items-center justify-between text-[11px] font-mono">
        <button
          onClick={() => top24hEvent && onSelectEvent(top24hEvent)}
          className="flex items-center gap-1.5 text-slate-300 hover:text-white transition-colors"
        >
          <FileText className="w-3.5 h-3.5 text-red-400" />
          <span className="font-bold tracking-wide">DAILY BRIEFING</span>
          <Lock className="w-2.5 h-2.5 text-slate-400" />
        </button>
      </div>

      {/* Intel Feed Header Bar (Matching Screenshot) */}
      <div className="px-3.5 py-2.5 flex items-center justify-between border-b border-[#171922]">
        <div className="flex items-center gap-2">
          <Radio className="w-4 h-4 text-red-500 animate-pulse" />
          <span className="font-mono font-black text-xs tracking-wider text-white uppercase">
            INTEL FEED
          </span>
          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-red-500/20 text-red-300 border border-red-500/30">
            {filteredEvents.length}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Expand / Restore Width Toggle */}
          {onToggleExpand && (
            <button
              onClick={onToggleExpand}
              className={`p-1.5 rounded border transition-colors ${
                panelState === 'expanded'
                  ? 'bg-sky-950/60 text-sky-300 border-sky-700/60'
                  : 'bg-[#151822] text-slate-400 hover:text-white border-[#262b3a]'
              }`}
              title={panelState === 'expanded' ? 'Reduce to standard width' : 'Expand feed width'}
            >
              {panelState === 'expanded' ? (
                <Minimize2 className="w-3.5 h-3.5" />
              ) : (
                <Maximize2 className="w-3.5 h-3.5" />
              )}
            </button>
          )}

          {/* Sound toggle button */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-1.5 rounded border transition-colors ${
              soundEnabled
                ? 'bg-[#151822] text-slate-300 border-[#262b3a]'
                : 'bg-[#151822] text-slate-400 border-[#262b3a]'
            }`}
            title={soundEnabled ? 'Mute Audio Feed' : 'Unmute Audio Feed'}
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          </button>

          {/* Refresh button with clock */}
          <button
            onClick={onRefresh}
            className="flex items-center gap-1.5 px-2 py-1 rounded bg-[#151822] border border-[#262b3a] text-slate-300 hover:text-white text-[10px] font-mono transition-colors"
          >
            <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
            <span>07:00 PM</span>
          </button>

          {/* Collapse Panel Button */}
          {onCollapse && (
            <button
              onClick={onCollapse}
              className="p-1.5 rounded bg-[#151822] border border-[#262b3a] text-slate-400 hover:text-red-400 hover:border-red-800/60 transition-colors"
              title="Collapse Intel Feed (Give Globe More Space)"
            >
              <PanelLeftClose className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Filter Chips Bar (ALL FEED | PULSE ONLY | NEWS ONLY | HIGH | RADAR) */}
      <div className="px-3 py-2 flex items-center gap-1.5 overflow-x-auto no-scrollbar border-b border-[#171922] font-mono text-[10px]">
        <button
          onClick={() => setSelectedFilter('ALL')}
          className={`px-2.5 py-1 rounded flex items-center gap-1 font-semibold transition-all shrink-0 ${
            selectedFilter === 'ALL'
              ? 'bg-[#1e2330] text-white border border-[#333a4f]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-[#13161f]'
          }`}
        >
          <Radio className="w-3 h-3 text-sky-400" />
          ALL FEED
        </button>

        <button
          onClick={() => setSelectedFilter('PULSE')}
          className={`px-2.5 py-1 rounded flex items-center gap-1 font-semibold transition-all shrink-0 ${
            selectedFilter === 'PULSE'
              ? 'bg-amber-950/60 text-amber-300 border border-amber-800'
              : 'text-slate-400 hover:text-slate-200 hover:bg-[#13161f]'
          }`}
        >
          PULSE ONLY
        </button>

        <button
          onClick={() => setSelectedFilter('NEWS')}
          className={`px-2.5 py-1 rounded flex items-center gap-1 font-semibold transition-all shrink-0 ${
            selectedFilter === 'NEWS'
              ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800'
              : 'text-slate-400 hover:text-slate-200 hover:bg-[#13161f]'
          }`}
        >
          NEWS ONLY
        </button>

        <button
          onClick={() => setSelectedFilter('HIGH')}
          className={`px-2.5 py-1 rounded flex items-center gap-1 font-bold transition-all shrink-0 ${
            selectedFilter === 'HIGH'
              ? 'bg-red-600 text-white'
              : 'text-red-400 bg-red-950/30 border border-red-900/50 hover:bg-red-950/60'
          }`}
        >
          <Flame className="w-3 h-3" />
          HIGH
        </button>

        {onOpenRadar && (
          <button
            onClick={onOpenRadar}
            className="px-2 py-1 rounded text-slate-400 hover:text-slate-200 hover:bg-[#13161f] transition-all shrink-0"
            title="Local Radar View"
          >
            <Compass className="w-3 h-3" />
          </button>
        )}
      </div>

      {/* Search Input Bar */}
      <div className="px-3 py-2 border-b border-[#171922] flex items-center gap-2">
        <div className="flex-1 relative flex items-center">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search..."
            className="w-full pl-8 pr-3 py-1.5 rounded bg-[#12141c] border border-[#222735] text-xs text-white placeholder-slate-400 focus:outline-none focus:border-red-500/80 font-mono transition-colors"
          />
        </div>
        <button
          onClick={() => setSelectedFilter(selectedFilter === 'HIGH' ? 'ALL' : 'HIGH')}
          title="Filter High Priority"
          className="p-2 rounded bg-[#12141c] border border-[#222735] text-slate-400 hover:text-white"
        >
          <SlidersHorizontal className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Scrollable Feed List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3 no-scrollbar">
        {/* Pinned Community Top 24h Card (Matching Screenshot) */}
        {top24hEvent && (
          <div
            onClick={() => onSelectEvent(top24hEvent)}
            className="p-3 rounded-md bg-[#10131a] border border-[#222735] hover:border-red-500/50 cursor-pointer transition-all space-y-2 relative group shadow-lg"
          >
            <div className="flex items-center justify-between text-[10px] font-mono">
              <span className="flex items-center gap-1 text-amber-400 font-bold tracking-tight">
                👑 COMMUNITY TOP 24H
              </span>
              <span className="px-1.5 py-0.5 rounded bg-red-600/90 text-white font-black text-[9px]">
                HIGH
              </span>
            </div>

            <div className="flex items-start gap-2">
              {top24hEvent.clusterCount && (
                <span className="px-1.5 py-0.5 rounded bg-red-950/80 border border-red-800 text-red-400 font-mono text-[10px] font-bold">
                  {top24hEvent.clusterCount}
                </span>
              )}
              <h4 className="text-xs font-bold text-white leading-snug group-hover:text-red-400 transition-colors">
                {top24hEvent.title}
              </h4>
            </div>

            <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
              {top24hEvent.summary}
            </p>

            {/* Confidence Badge */}
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-800/80 text-emerald-400 font-mono text-[10px] font-bold flex items-center gap-1">
                <Shield className="w-3 h-3" />
                CONFIDENCE 95%
              </span>
            </div>

            {/* Bottom Card Footer with Flag, Time, and Vote Controls */}
            <div className="pt-2 border-t border-[#1a1d27] flex items-center justify-between text-[11px] font-mono">
              <div className="flex items-center gap-2 text-slate-400">
                <span>{top24hEvent.countryFlag || '🇷🇺'}</span>
                <span>2h</span>
              </div>

              {/* Voting buttons */}
              <div className="flex items-center gap-1 bg-[#151822] px-1.5 py-0.5 rounded border border-[#252936]">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onVote(top24hEvent.id, 'up');
                  }}
                  className="text-slate-400 hover:text-emerald-400 p-0.5"
                >
                  <ChevronUp className="w-3 h-3" />
                </button>
                <span className="text-white font-bold text-[10px] px-1">
                  {top24hEvent.trustMetrics.upvotes - top24hEvent.trustMetrics.downvotes}
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onVote(top24hEvent.id, 'down');
                  }}
                  className="text-slate-400 hover:text-red-400 p-0.5"
                >
                  <ChevronDown className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Intelligence Stream List */}
        {filteredEvents
          .filter((e) => e.id !== top24hEvent?.id)
          .map((evt) => (
            <div
              key={evt.id}
              onClick={() => onSelectEvent(evt)}
              className={`p-3 rounded-md border transition-all cursor-pointer space-y-2 ${
                selectedEventId === evt.id
                  ? 'bg-red-950/20 border-red-600/70 shadow-lg'
                  : 'bg-[#0f1118] border-[#1e222e] hover:border-[#303749]'
              }`}
            >
              {/* Card Header */}
              <div className="flex items-center justify-between text-[10px] font-mono">
                <div className="flex items-center gap-1.5">
                  {evt.isNewsIntel ? (
                    <span className="px-1.5 py-0.5 rounded bg-red-950/60 border border-red-800 text-red-400 font-bold flex items-center gap-1">
                      <Video className="w-2.5 h-2.5" />
                      NEWS
                    </span>
                  ) : (
                    <span className="px-1.5 py-0.5 rounded bg-[#171a24] text-slate-300 border border-[#272c3d]">
                      {evt.category}
                    </span>
                  )}
                  <span className="text-slate-400">{evt.location.country}</span>
                </div>

                {evt.severity === 'critical' || evt.severity === 'high' ? (
                  <span className="px-1.5 py-0.5 rounded bg-red-600 text-white font-black text-[9px]">
                    HIGH
                  </span>
                ) : null}
              </div>

              {/* Title & Summary */}
              <h4 className="text-xs font-bold text-white leading-snug hover:text-red-400 transition-colors">
                {evt.title}
              </h4>

              <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                {evt.summary}
              </p>

              {/* Card Footer */}
              <div className="pt-2 border-t border-[#171923] flex items-center justify-between text-[10px] font-mono text-slate-400">
                <div className="flex items-center gap-2">
                  <span>{evt.countryFlag || '🌐'}</span>
                  <span>{evt.location.city}</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onFocusGlobe(evt.id);
                    }}
                    title="Focus on Globe"
                    className="text-slate-400 hover:text-red-400"
                  >
                    <MapPin className="w-3 h-3" />
                  </button>

                  {/* Trust Score */}
                  <span className="text-emerald-400 font-bold">
                    +{evt.trustMetrics.upvotes}
                  </span>
                </div>
              </div>
            </div>
          ))}
      </div>
    </div>
  );
};
