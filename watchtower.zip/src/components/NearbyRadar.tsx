import React, { useState, useEffect } from 'react';
import { GlobalEvent, User } from '../types.js';
import { getCategoryMeta, getSeverityBadge } from '../utils/categories.js';
import {
  Navigation,
  MapPin,
  Compass,
  Sliders,
  ChevronRight,
  Globe2,
  Radio,
  Search,
  Crosshair,
  Flame,
} from 'lucide-react';

interface NearbyRadarProps {
  events: GlobalEvent[];
  currentUser: User | null;
  onSelectEvent: (event: GlobalEvent) => void;
  onFocusGlobe: (eventId: string) => void;
}

const RADAR_PRESETS = [
  { label: 'New Delhi', lat: 28.6139, lng: 77.209 },
  { label: 'Bengaluru', lat: 12.9716, lng: 77.5946 },
  { label: 'Guwahati', lat: 26.1445, lng: 91.7362 },
  { label: 'London', lat: 51.5074, lng: -0.1278 },
  { label: 'New York', lat: 40.7128, lng: -74.006 },
  { label: 'Tokyo', lat: 35.6762, lng: 139.6503 },
  { label: 'Hamburg', lat: 53.5511, lng: 9.9937 },
];

export const NearbyRadar: React.FC<NearbyRadarProps> = ({
  events,
  currentUser,
  onSelectEvent,
  onFocusGlobe,
}) => {
  const [currentLat, setCurrentLat] = useState<number>(28.6139);
  const [currentLng, setCurrentLng] = useState<number>(77.209);
  const [locationLabel, setLocationLabel] = useState<string>('New Delhi, India');
  const [radiusKm, setRadiusKm] = useState<number>(2500);
  const [nearbyEvents, setNearbyEvents] = useState<(GlobalEvent & { distanceKm?: number })[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  // Fetch nearby events from backend with local fallback
  const fetchNearby = async (lat: number, lng: number, radius: number) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/events/nearby?lat=${lat}&lng=${lng}&radiusKm=${radius}`, {
        headers: currentUser ? { Authorization: `Bearer ${currentUser.id}` } : {},
      });
      const data = await res.json();
      if (data.success && data.events) {
        setNearbyEvents(data.events);
        setLoading(false);
        return;
      }
    } catch (err) {
      console.warn('Failed to fetch nearby events from API, calculating from active stream', err);
    }

    // Local calculation fallback
    const calcDist = (lat1: number, lon1: number, lat2: number, lon2: number) => {
      const R = 6371;
      const dLat = ((lat2 - lat1) * Math.PI) / 180;
      const dLon = ((lon2 - lon1) * Math.PI) / 180;
      const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos((lat1 * Math.PI) / 180) *
          Math.cos((lat2 * Math.PI) / 180) *
          Math.sin(dLon / 2) *
          Math.sin(dLon / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      return Math.round(R * c);
    };

    const localFiltered = events
      .map((e) => ({
        ...e,
        distanceKm: calcDist(lat, lng, e.location.lat, e.location.lng),
      }))
      .filter((e) => (e.distanceKm || 0) <= radius)
      .sort((a, b) => (a.distanceKm || 0) - (b.distanceKm || 0));

    setNearbyEvents(localFiltered);
    setLoading(false);
  };

  useEffect(() => {
    fetchNearby(currentLat, currentLng, radiusKm);
  }, [currentLat, currentLng, radiusKm, currentUser]);

  const handleDetectGPS = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = Math.round(pos.coords.latitude * 10000) / 10000;
          const lng = Math.round(pos.coords.longitude * 10000) / 10000;
          setCurrentLat(lat);
          setCurrentLng(lng);
          setLocationLabel(`Device GPS Coordinates (${lat}°, ${lng}°)`);
        },
        (err) => {
          console.warn('Geolocation denied or failed', err);
        }
      );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 backdrop-blur-xl shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-sky-400">
            <Radio className="w-5 h-5 animate-pulse" />
            <span className="text-xs font-mono font-bold uppercase tracking-wider">
              GEOSPATIAL SITUATIONAL RADAR
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white">
            Nearby Events & Regional Intelligence
          </h2>
          <p className="text-xs text-slate-300">
            Discover verified incidents, calamities, and corruption probes relative to your geographic radius.
          </p>
        </div>

        {/* Location Selector Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleDetectGPS}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white text-xs font-semibold rounded-xl shadow-md transition-all active:scale-95"
          >
            <Crosshair className="w-4 h-4" />
            <span>Use My GPS</span>
          </button>

          {RADAR_PRESETS.map((p, idx) => (
            <button
              key={idx}
              onClick={() => {
                setCurrentLat(p.lat);
                setCurrentLng(p.lng);
                setLocationLabel(p.label);
              }}
              className={`text-xs px-3 py-1.5 rounded-xl border font-mono transition-all ${
                locationLabel.includes(p.label)
                  ? 'bg-sky-500/20 text-sky-300 border-sky-500/60 font-semibold'
                  : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 border-slate-700'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Grid: Interactive Radar Visualizer + Nearby Events List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Radar Graphic Scanner Card */}
        <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col items-center justify-between gap-6 shadow-xl">
          <div className="w-full flex items-center justify-between text-xs font-mono text-slate-400">
            <span className="flex items-center gap-1.5 text-slate-200">
              <Compass className="w-4 h-4 text-sky-400" />
              RADAR SWEEP
            </span>
            <span className="text-sky-400">{locationLabel}</span>
          </div>

          {/* Animated Circular Radar Display */}
          <div className="relative w-64 h-64 rounded-full border-2 border-sky-500/30 bg-slate-950 flex items-center justify-center overflow-hidden shadow-2xl shadow-sky-950/50">
            {/* Concentric Rings */}
            <div className="absolute w-48 h-48 rounded-full border border-sky-500/20" />
            <div className="absolute w-32 h-32 rounded-full border border-sky-500/20" />
            <div className="absolute w-16 h-16 rounded-full border border-sky-500/20" />
            <div className="absolute w-full h-px bg-sky-500/20" />
            <div className="absolute h-full w-px bg-sky-500/20" />

            {/* Pulsing Center */}
            <div className="w-3 h-3 rounded-full bg-sky-400 z-10 animate-ping" />
            <div className="w-2.5 h-2.5 rounded-full bg-sky-400 z-10" />

            {/* Rotating Scanner Cone */}
            <div
              className="absolute inset-0 origin-center animate-spin"
              style={{
                background:
                  'conic-gradient(from 0deg at 50% 50%, rgba(56, 189, 248, 0.45) 0deg, rgba(56, 189, 248, 0) 60deg)',
                animationDuration: '4s',
              }}
            />

            {/* Radar Blips representing nearby events */}
            {nearbyEvents.slice(0, 8).map((evt, idx) => {
              const angle = (idx * 45 * Math.PI) / 180;
              const distNorm = Math.min(100, Math.max(20, (evt.distanceKm || 500) / 25));
              const x = Math.cos(angle) * distNorm;
              const y = Math.sin(angle) * distNorm;

              return (
                <button
                  key={evt.id}
                  onClick={() => onSelectEvent(evt)}
                  title={`${evt.title} (${evt.distanceKm} km)`}
                  className="absolute w-3 h-3 rounded-full bg-red-400 hover:scale-150 border border-white z-20 transition-transform shadow-lg cursor-pointer"
                  style={{
                    transform: `translate(${x}px, ${y}px)`,
                  }}
                />
              );
            })}
          </div>

          {/* Radius Range Slider */}
          <div className="w-full space-y-2 pt-2 border-t border-slate-800 text-xs">
            <div className="flex items-center justify-between text-slate-300 font-mono">
              <span>Detection Radius:</span>
              <span className="text-sky-400 font-bold">{radiusKm} km</span>
            </div>
            <input
              type="range"
              min={100}
              max={5000}
              step={100}
              value={radiusKm}
              onChange={(e) => setRadiusKm(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-500"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>100 km (Local)</span>
              <span>2500 km</span>
              <span>5000 km (Continental)</span>
            </div>
          </div>
        </div>

        {/* Nearby Events List (2 columns) */}
        <div className="lg:col-span-2 space-y-3">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400 px-1">
            <span>
              FOUND <strong className="text-white">{nearbyEvents.length}</strong> EVENTS WITHIN {radiusKm} KM
            </span>
            <span>SORTED BY PROXIMITY</span>
          </div>

          {loading ? (
            <div className="p-12 text-center text-slate-400 font-mono text-xs">
              Scanning geospatial coordinates...
            </div>
          ) : nearbyEvents.length === 0 ? (
            <div className="p-12 text-center bg-slate-900/60 border border-slate-800 rounded-3xl text-slate-400 text-xs space-y-2">
              <p>No published events found within {radiusKm} km of this location.</p>
              <p className="text-slate-500">Try expanding the detection radius slider above.</p>
            </div>
          ) : (
            <div className="space-y-3 max-h-[580px] overflow-y-auto pr-1">
              {nearbyEvents.map((evt) => {
                const meta = getCategoryMeta(evt.category);
                const CategoryIcon = meta.icon;
                const sev = getSeverityBadge(evt.severity);

                return (
                  <div
                    key={evt.id}
                    onClick={() => onSelectEvent(evt)}
                    className="group p-4 rounded-2xl bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-md"
                  >
                    <div className="space-y-1.5 flex-1">
                      <div className="flex items-center gap-2">
                        <span
                          className={`flex items-center gap-1 text-[11px] font-semibold px-2.5 py-0.5 rounded-lg border ${meta.bgColor} ${meta.color} ${meta.borderColor}`}
                        >
                          <CategoryIcon className="w-3.5 h-3.5" />
                          {evt.category}
                        </span>
                        {evt.isHotAlert && (
                          <span className="flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/40">
                            <Flame className="w-3 h-3" />
                            HOT
                          </span>
                        )}
                        <span className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded-md ${sev.className}`}>
                          {sev.label}
                        </span>
                      </div>

                      <h4 className="text-sm font-semibold text-white group-hover:text-sky-300 transition-colors">
                        {evt.title}
                      </h4>

                      <p className="text-xs text-slate-400 line-clamp-1">{evt.summary}</p>
                    </div>

                    {/* Proximity Distance Badge & Quick Actions */}
                    <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center w-full sm:w-auto gap-2 shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-800">
                      <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-xl bg-sky-500/15 text-sky-300 border border-sky-500/30">
                        {evt.distanceKm} km away
                      </span>

                      <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => onFocusGlobe(evt.id)}
                          title="View on 3D Globe"
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-sky-400 transition-colors"
                        >
                          <Globe2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onSelectEvent(evt)}
                          className="text-xs text-sky-400 hover:text-sky-300 font-medium flex items-center gap-0.5"
                        >
                          Inspect <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
