import React, { useState } from 'react';
import { User, UserRole } from '../types.js';
import {
  X,
  Radio,
  ShieldCheck,
  ShieldAlert,
  Lock,
  Mail,
  Key,
  User as UserIcon,
  Sparkles,
  ArrowRight,
  Eye,
  EyeOff,
  AlertTriangle,
  CheckCircle2,
  Terminal,
} from 'lucide-react';

interface AuthModalProps {
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onClose, onLoginSuccess }) => {
  const [activeTab, setActiveTab] = useState<'signin' | 'signup' | 'admin'>('signin');
  
  // Sign In / General fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Sign Up fields - Designation and Code Name ONLY
  const [codeName, setCodeName] = useState('');
  const [designation, setDesignation] = useState('Field Reporter');

  // Admin fields (clean, blank initial values)
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [showAdminPassword, setShowAdminPassword] = useState(false);

  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: email.trim(),
          password,
        }),
      });

      const data = await res.json();
      if (data.success && data.user) {
        onLoginSuccess(data.user);
        onClose();
      } else {
        setError(data.error || 'Authentication failed. Please verify your email and password.');
      }
    } catch (err) {
      setError('Network connection error. Unable to authenticate.');
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (email.trim().toLowerCase() === 'ayush@gmail.com') {
      setError('This email is reserved for the Administrator. Please use Admin Login.');
      return;
    }

    if (!codeName.trim()) {
      setError('Code name / callsign is required.');
      return;
    }

    if (!designation.trim()) {
      setError('Operational designation is required.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          codeName: codeName.trim(),
          designation: designation.trim(),
          email: email.trim(),
          password,
          role: 'field-reporter',
        }),
      });

      const data = await res.json();
      if (data.success && data.user) {
        onLoginSuccess(data.user);
        onClose();
      } else {
        setError(data.error || 'Registration failed. Please check inputs.');
      }
    } catch (err) {
      setError('Network error during registration.');
    } finally {
      setLoading(false);
    }
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: adminEmail.trim(),
          password: adminPassword,
        }),
      });

      const data = await res.json();
      if (data.success && data.user) {
        onLoginSuccess(data.user);
        onClose();
      } else {
        setError(data.error || 'Invalid Administrator credentials.');
      }
    } catch (err) {
      setError('Connection failed. Admin authentication rejected.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div
        id="auth-modal-container"
        className="relative w-full max-w-md bg-[#0d1017] border border-[#222736] rounded-2xl shadow-2xl overflow-hidden my-auto text-slate-100 p-6 space-y-5 font-sans"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#1c2230] pb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-400">
              <Radio className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-wide">
                Watchtower Global Intelligence
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                {activeTab === 'admin'
                  ? 'Chief Administrator Terminal'
                  : 'Operator Authentication & Clearance'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-[#161a24] hover:bg-[#202634] text-slate-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher: 3 explicit tabs */}
        <div className="grid grid-cols-3 gap-1 bg-[#07090e] p-1 rounded-xl border border-[#1b202d] text-xs font-mono">
          <button
            type="button"
            onClick={() => {
              setActiveTab('signin');
              setError(null);
            }}
            className={`py-2 rounded-lg transition-all font-semibold ${
              activeTab === 'signin'
                ? 'bg-amber-500 text-black shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('signup');
              setError(null);
            }}
            className={`py-2 rounded-lg transition-all font-semibold ${
              activeTab === 'signup'
                ? 'bg-amber-500 text-black shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Sign-Up
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('admin');
              setError(null);
            }}
            className={`py-2 rounded-lg transition-all font-semibold ${
              activeTab === 'admin'
                ? 'bg-red-600 text-white shadow'
                : 'text-slate-400 hover:text-red-400'
            }`}
          >
            Admin Login
          </button>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-700/60 text-rose-300 text-xs flex items-start gap-2 animate-in fade-in">
            <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {/* TAB 1: STANDARD SIGN IN */}
        {activeTab === 'signin' && (
          <form onSubmit={handleSignIn} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-300 font-mono font-semibold mb-1">
                OPERATOR EMAIL ADDRESS
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. echohawk@watchtower.org"
                  className="w-full px-3.5 py-2.5 bg-[#07090e] border border-[#1e2535] rounded-xl text-slate-100 focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-mono font-semibold mb-1">
                ACCESS PASSWORD / CLEARANCE KEY
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter secret password"
                  className="w-full px-3.5 py-2.5 bg-[#07090e] border border-[#1e2535] rounded-xl text-slate-100 focus:outline-none focus:border-amber-500 font-mono pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-200"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-black font-mono font-bold text-xs rounded-xl shadow-lg transition-all disabled:opacity-50"
            >
              {loading ? 'Authenticating...' : 'Sign In as Operator'}
            </button>

            {/* Quick Demo Credentials helper */}
            <div className="p-3 rounded-xl bg-[#080a10] border border-[#181e2b] space-y-1 text-[11px] font-mono text-slate-400">
              <span className="text-slate-300 font-semibold">Test Field Reporter Accounts:</span>
              <div className="flex flex-wrap gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setEmail('vigilantoasis@watchtower.org');
                    setPassword('Watchtower@2026');
                  }}
                  className="px-2 py-1 rounded bg-[#131722] hover:bg-[#1a2030] text-amber-300 border border-[#232b3d]"
                >
                  VigilantOasis (Veteran Reporter)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setEmail('echohawk@watchtower.org');
                    setPassword('Watchtower@2026');
                  }}
                  className="px-2 py-1 rounded bg-[#131722] hover:bg-[#1a2030] text-amber-300 border border-[#232b3d]"
                >
                  EchoHawk_92 (Rookie Reporter)
                </button>
              </div>
            </div>
          </form>
        )}

        {/* TAB 2: SIGN-UP (CODE NAME & DESIGNATION ONLY) */}
        {activeTab === 'signup' && (
          <form onSubmit={handleSignUp} className="space-y-3.5 text-xs">
            <div>
              <label className="block text-slate-300 font-mono font-semibold mb-1">
                CODE NAME / CALLSIGN
              </label>
              <input
                type="text"
                required
                value={codeName}
                onChange={(e) => setCodeName(e.target.value)}
                placeholder="e.g. EchoHawk_92, VigilantOasis, GhostWatcher"
                className="w-full px-3.5 py-2 bg-[#07090e] border border-[#1e2535] rounded-xl text-slate-100 focus:outline-none focus:border-amber-500 font-mono"
              />
              <p className="text-[10px] text-slate-400 mt-1 font-mono">
                Only your tactical code name appears on public intelligence logs and reports.
              </p>
            </div>

            <div>
              <label className="block text-slate-300 font-mono font-semibold mb-1">
                OPERATIONAL DESIGNATION
              </label>
              <input
                type="text"
                required
                value={designation}
                onChange={(e) => setDesignation(e.target.value)}
                placeholder="e.g. Field Reporter, Tactical Analyst, Observer"
                className="w-full px-3.5 py-2 bg-[#07090e] border border-[#1e2535] rounded-xl text-slate-100 focus:outline-none focus:border-amber-500 font-mono"
              />
              <p className="text-[10px] text-slate-400 mt-1 font-mono">
                Designation entered at registration will identify your role across all terminals.
              </p>
            </div>

            <div>
              <label className="block text-slate-300 font-mono font-semibold mb-1">
                OPERATOR EMAIL ADDRESS
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="e.g. operator@watchtower.io"
                className="w-full px-3.5 py-2 bg-[#07090e] border border-[#1e2535] rounded-xl text-slate-100 focus:outline-none focus:border-amber-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-mono font-semibold mb-1">
                ACCESS PASSWORD
              </label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Minimum 6 characters"
                className="w-full px-3.5 py-2 bg-[#07090e] border border-[#1e2535] rounded-xl text-slate-100 focus:outline-none focus:border-amber-500 font-mono"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-black font-mono font-bold text-xs rounded-xl shadow-lg transition-all disabled:opacity-50"
            >
              {loading ? 'Registering...' : 'Sign-Up as Operator'}
            </button>
          </form>
        )}

        {/* TAB 3: ADMIN LOGIN */}
        {activeTab === 'admin' && (
          <form onSubmit={handleAdminLogin} className="space-y-4 text-xs animate-in fade-in">
            <div className="p-3 rounded-xl bg-red-950/30 border border-red-500/50 space-y-1">
              <div className="flex items-center gap-1.5 text-red-400 font-mono font-bold text-[11px] uppercase">
                <ShieldAlert className="w-4 h-4" />
                <span>ADMIN LOGIN</span>
              </div>
              <p className="text-[11px] text-slate-300">
                Authorized access for System Administrator. Manage reports, review verifications, and moderate intelligence.
              </p>
            </div>

            <div>
              <label className="block text-slate-300 font-mono font-semibold mb-1 flex items-center justify-between">
                <span>ADMINISTRATOR EMAIL</span>
                <Lock className="w-3 h-3 text-red-400" />
              </label>
              <input
                type="email"
                required
                value={adminEmail}
                onChange={(e) => setAdminEmail(e.target.value)}
                placeholder="Enter administrator email"
                className="w-full px-3.5 py-2.5 bg-[#07090e] border border-[#262c3e] rounded-xl text-slate-100 focus:outline-none focus:border-red-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-mono font-semibold mb-1">
                ADMINISTRATOR PASSWORD
              </label>
              <div className="relative">
                <input
                  type={showAdminPassword ? 'text' : 'password'}
                  required
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  placeholder="Enter administrator password"
                  className="w-full px-3.5 py-2.5 bg-[#07090e] border border-[#262c3e] rounded-xl text-slate-100 focus:outline-none focus:border-red-500 font-mono pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowAdminPassword(!showAdminPassword)}
                  className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-200"
                >
                  {showAdminPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white font-mono font-bold text-xs rounded-xl shadow-lg transition-all shadow-red-950/50 disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <Terminal className="w-4 h-4" />
              <span>{loading ? 'Authenticating Admin...' : 'Admin Sign In'}</span>
            </button>
          </form>
        )}

        {/* Security / Admin Login Trigger at bottom of modal */}
        <div className="pt-2 border-t border-[#181d29] flex items-center justify-between text-[11px] font-mono text-slate-400">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>256-Bit Tactical Enclave</span>
          </div>

          <button
            type="button"
            onClick={() => {
              setError(null);
              setActiveTab(activeTab === 'admin' ? 'signin' : 'admin');
            }}
            className="flex items-center gap-1 text-slate-400 hover:text-red-400 transition-colors"
            title="Admin Login"
          >
            <Lock className="w-3 h-3 text-red-500" />
            <span>{activeTab === 'admin' ? 'Return to User Sign In' : 'Admin Login'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
