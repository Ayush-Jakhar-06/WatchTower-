import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import * as THREE from 'three';
import { GlobalEvent, CountryData } from '../types.js';
import { getCategoryMeta } from '../utils/categories.js';
import { getRealWorldGeoData, REAL_COUNTRIES_MAP, RealCountryInfo } from '../utils/geoData.js';
import {
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Play,
  Pause,
  MapPin,
  ExternalLink,
  Flame,
  Shield,
  Plane,
  Eye,
  Crosshair,
  Layers,
  Cloud,
  Navigation,
  Radio,
  Anchor,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Maximize2,
  Minimize2,
  PanelLeft,
  PanelRight,
  Monitor,
  Smartphone,
  Tablet,
  SlidersHorizontal,
  Target,
} from 'lucide-react';

interface Globe3DProps {
  events: GlobalEvent[];
  selectedEventId: string | null;
  onSelectEvent: (event: GlobalEvent) => void;
  onSelectCountry?: (country: CountryData) => void;
  focusedEventId?: string | null;
  focusedCountryId?: string | null;
  activeTheater?: string;
  onTheaterChange?: (theater: string) => void;
  leftPanelCollapsed?: boolean;
  rightPanelCollapsed?: boolean;
  onToggleLeftPanel?: () => void;
  onToggleRightPanel?: () => void;
  isGlobeFocusMode?: boolean;
  onToggleGlobeFocus?: () => void;
}

type MapMode = 'satellite' | 'hybrid' | 'night';

// Convert Lat/Lng to Vector3 on sphere of radius R
function latLngToVector3(lat: number, lng: number, radius: number): THREE.Vector3 {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lng + 180) * (Math.PI / 180);

  const x = -(radius * Math.sin(phi) * Math.cos(theta));
  const z = radius * Math.sin(phi) * Math.sin(theta);
  const y = radius * Math.cos(phi);

  return new THREE.Vector3(x, y, z);
}

// Convert 3D Vector3 on sphere back to Lat/Lng
function vector3ToLatLng(vec: THREE.Vector3, radius: number): { lat: number; lng: number } {
  const phi = Math.acos(Math.max(-1, Math.min(1, vec.y / radius)));
  const theta = Math.atan2(vec.z, -vec.x);
  const lat = 90 - (phi * 180) / Math.PI;
  let lng = (theta * 180) / Math.PI - 180;
  while (lng < -180) lng += 360;
  while (lng > 180) lng -= 360;
  return { lat, lng };
}

// Helper to convert Lng/Lat to Canvas X/Y coordinates
function geoToCanvas(lng: number, lat: number, width: number, height: number): [number, number] {
  const x = ((lng + 180) / 360) * width;
  const y = ((90 - lat) / 180) * height;
  return [x, y];
}

// Point in polygon test for accurate country hover raycasting
function isPointInPolygon(point: [number, number], vs: [number, number][]): boolean {
  const x = point[0], y = point[1];
  let inside = false;
  for (let i = 0, j = vs.length - 1; i < vs.length; j = i++) {
    const xi = vs[i][0], yi = vs[i][1];
    const xj = vs[j][0], yj = vs[j][1];
    const intersect = ((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
    if (intersect) inside = !inside;
  }
  return inside;
}

// Major Strategic Maritime Chokepoints & Waterways
const CHOKEPOINTS = [
  { id: 'hormuz', name: 'Strait of Hormuz', lat: 26.56, lng: 56.25, threat: 'CRITICAL', flow: '21M bpd Oil' },
  { id: 'mandeb', name: 'Bab-el-Mandeb', lat: 12.58, lng: 43.33, threat: 'HIGH RISK', flow: '12% Global Trade' },
  { id: 'taiwan', name: 'Taiwan Strait', lat: 24.2, lng: 119.5, threat: 'ELEVATED', flow: '50% Container Ships' },
  { id: 'malacca', name: 'Strait of Malacca', lat: 2.5, lng: 101.5, threat: 'MONITORED', flow: '100k Ships / Year' },
  { id: 'bosporus', name: 'Bosporus & Dardanelles', lat: 41.1, lng: 29.05, threat: 'STRATEGIC', flow: 'Montreux Regulated' },
  { id: 'suez', name: 'Suez Canal', lat: 30.58, lng: 32.55, threat: 'HIGH RISK', flow: 'Red Sea Gate' },
  { id: 'panama', name: 'Panama Canal', lat: 9.1, lng: -79.7, threat: 'MONITORED', flow: 'Americas Transit' },
  { id: 'giuk', name: 'GIUK Gap', lat: 62.0, lng: -15.0, threat: 'STRATEGIC', flow: 'NATO Sub Patrol' },
];

// Major Real World Urban Coordinates for Night Lights
const URBAN_LIGHTS = [
  { name: 'Tokyo', lat: 35.68, lng: 139.76, intensity: 1.0 },
  { name: 'Seoul', lat: 37.56, lng: 126.97, intensity: 0.95 },
  { name: 'Shanghai', lat: 31.23, lng: 121.47, intensity: 0.95 },
  { name: 'Beijing', lat: 39.9, lng: 116.4, intensity: 0.9 },
  { name: 'Guangzhou / HK', lat: 22.54, lng: 114.05, intensity: 1.0 },
  { name: 'Taipei', lat: 25.03, lng: 121.56, intensity: 0.9 },
  { name: 'Singapore', lat: 1.35, lng: 103.82, intensity: 0.95 },
  { name: 'Mumbai', lat: 19.07, lng: 72.87, intensity: 0.9 },
  { name: 'Delhi', lat: 28.61, lng: 77.2, intensity: 0.9 },
  { name: 'Dubai', lat: 25.2, lng: 55.27, intensity: 0.9 },
  { name: 'Riyadh', lat: 24.71, lng: 46.67, intensity: 0.85 },
  { name: 'Cairo / Nile', lat: 30.04, lng: 31.23, intensity: 0.9 },
  { name: 'London', lat: 51.5, lng: -0.12, intensity: 0.95 },
  { name: 'Paris', lat: 48.85, lng: 2.35, intensity: 0.9 },
  { name: 'Benelux / Ruhr', lat: 51.2, lng: 6.8, intensity: 0.95 },
  { name: 'Kyiv', lat: 50.45, lng: 30.52, intensity: 0.75 },
  { name: 'Moscow', lat: 55.75, lng: 37.61, intensity: 0.9 },
  { name: 'New York', lat: 40.71, lng: -74.0, intensity: 1.0 },
  { name: 'Chicago', lat: 41.87, lng: -87.62, intensity: 0.85 },
  { name: 'Los Angeles', lat: 34.05, lng: -118.24, intensity: 0.95 },
  { name: 'San Francisco', lat: 37.77, lng: -122.41, intensity: 0.9 },
  { name: 'São Paulo', lat: -23.55, lng: -46.63, intensity: 0.85 },
  { name: 'Sydney', lat: -33.86, lng: 151.2, intensity: 0.8 },
  { name: 'Johannesburg', lat: -26.2, lng: 28.04, intensity: 0.75 },
];

// Realistic Military Flight Patrol Routes with Aircraft Types and Headings
interface ReconFlight {
  id: string;
  name: string;
  type: string;
  callsign: string;
  speed: number;
  altitude: string;
  route: [number, number][]; // [lat, lng]
}

const CONFLICTLY_FLIGHTS: ReconFlight[] = [
  { id: 'f1', name: 'RQ-4B Global Hawk', type: 'ISR Drone', callsign: 'FORTE11', speed: 0.0004, altitude: 'FL520', route: [[43.5, 28.5], [44.2, 32.0], [43.8, 35.5], [42.5, 33.0], [42.0, 29.5], [43.5, 28.5]] },
  { id: 'f2', name: 'RC-135W Rivet Joint', type: 'SIGINT Recon', callsign: 'HOMER51', speed: 0.0005, altitude: 'FL340', route: [[56.5, 18.0], [58.0, 20.5], [59.5, 22.0], [58.5, 19.0], [56.5, 18.0]] },
  { id: 'f3', name: 'P-8A Poseidon', type: 'ASW / Maritime', callsign: 'MADFOX24', speed: 0.00045, altitude: 'FL260', route: [[33.5, 28.0], [34.2, 31.5], [33.8, 34.0], [32.5, 31.0], [33.5, 28.0]] },
  { id: 'f4', name: 'E-3A Sentry AWACS', type: 'Airborne Radar', callsign: 'NATO01', speed: 0.00035, altitude: 'FL310', route: [[51.5, 22.0], [52.8, 23.5], [53.5, 21.0], [52.0, 19.5], [51.5, 22.0]] },
  { id: 'f5', name: 'F-35A Lightning II', type: 'Stealth Fighter', callsign: 'VIPER11', speed: 0.00065, altitude: 'FL280', route: [[33.0, 35.5], [34.5, 36.2], [34.0, 37.0], [32.8, 36.0], [33.0, 35.5]] },
  { id: 'f6', name: 'MQ-9A Reaper', type: 'Tactical UAV', callsign: 'REAPER09', speed: 0.0003, altitude: 'FL240', route: [[13.0, 43.0], [14.5, 42.5], [15.5, 43.8], [14.0, 44.5], [13.0, 43.0]] },
  { id: 'f7', name: 'Eurofighter Typhoon', type: 'Air Superiority', callsign: 'TYPHOON3', speed: 0.0006, altitude: 'FL360', route: [[54.5, 5.0], [56.0, 7.5], [55.0, 9.0], [53.5, 6.5], [54.5, 5.0]] },
  { id: 'f8', name: 'P-8A Poseidon', type: 'Maritime Patrol', callsign: 'TRIDENT44', speed: 0.00045, altitude: 'FL250', route: [[22.0, 119.0], [21.0, 121.5], [23.0, 122.5], [24.0, 120.0], [22.0, 119.0]] },
  { id: 'f9', name: 'RC-135V Rivet Joint', type: 'ISR Electronic', callsign: 'COBRA77', speed: 0.0004, altitude: 'FL320', route: [[15.0, 112.0], [17.5, 114.5], [16.0, 117.0], [14.0, 114.0], [15.0, 112.0]] },
  { id: 'f10', name: 'MQ-4C Triton', type: 'High-Alt ISR', callsign: 'SCORE52', speed: 0.00035, altitude: 'FL550', route: [[26.0, 56.0], [27.5, 57.5], [26.5, 59.0], [25.0, 57.5], [26.0, 56.0]] },
  { id: 'f11', name: 'Mirage 2000D', type: 'Tactical Recon', callsign: 'DAGGER22', speed: 0.00055, altitude: 'FL290', route: [[15.0, -1.0], [17.0, 1.5], [16.0, 3.0], [14.5, 0.5], [15.0, -1.0]] },
  { id: 'f12', name: 'B-52H Stratofortress', type: 'Global Strike', callsign: 'MYTEE51', speed: 0.0005, altitude: 'FL410', route: [[68.0, 15.0], [71.0, 25.0], [72.0, 35.0], [69.0, 28.0], [68.0, 15.0]] }
];

// Helper to create sharp Aircraft Texture Sprite
function createAircraftSpriteTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 64;
  canvas.height = 64;
  const ctx = canvas.getContext('2d')!;

  ctx.clearRect(0, 0, 64, 64);

  // Draw sleek military airplane silhouette (pointed up towards Y-)
  ctx.save();
  ctx.translate(32, 32);

  // Subtle outer glow
  ctx.shadowColor = 'rgba(56, 189, 248, 0.9)';
  ctx.shadowBlur = 8;

  // Main fuselage & wings
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  // Nose
  ctx.moveTo(0, -22);
  // Right nose slope
  ctx.lineTo(3, -8);
  // Right wing tip
  ctx.lineTo(24, 6);
  ctx.lineTo(24, 10);
  ctx.lineTo(4, 7);
  // Right tail
  ctx.lineTo(4, 16);
  ctx.lineTo(11, 22);
  ctx.lineTo(9, 24);
  // Center exhaust
  ctx.lineTo(0, 20);
  // Left tail
  ctx.lineTo(-9, 24);
  ctx.lineTo(-11, 22);
  ctx.lineTo(-4, 16);
  // Left wing tip
  ctx.lineTo(-4, 7);
  ctx.lineTo(-24, 10);
  ctx.lineTo(-24, 6);
  // Left nose slope
  ctx.lineTo(-3, -8);
  ctx.closePath();
  ctx.fill();

  ctx.restore();

  const texture = new THREE.CanvasTexture(canvas);
  return texture;
}

// Helper to create Conflictly High-DPI Cluster Badges with Numbers (e.g. 12, 9, 8, etc.)
function createClusterBadgeTexture(count: number, isCritical: boolean): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  const cx = 64;
  const cy = 64;
  const rad = 50;

  // Shadow
  ctx.shadowColor = isCritical ? 'rgba(239, 68, 68, 0.9)' : 'rgba(245, 158, 11, 0.9)';
  ctx.shadowBlur = 14;

  // Outer gradient circle
  const grad = ctx.createRadialGradient(cx - 10, cy - 10, 5, cx, cy, rad);
  if (isCritical) {
    grad.addColorStop(0, '#ef4444');
    grad.addColorStop(0.7, '#b91c1c');
    grad.addColorStop(1, '#7f1d1d');
  } else {
    grad.addColorStop(0, '#fbbf24');
    grad.addColorStop(0.7, '#d97706');
    grad.addColorStop(1, '#92400e');
  }

  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(cx, cy, rad, 0, Math.PI * 2);
  ctx.fill();

  // Border ring
  ctx.strokeStyle = isCritical ? '#fca5a5' : '#fde68a';
  ctx.lineWidth = 4;
  ctx.stroke();

  // Reset shadow for crisp text
  ctx.shadowBlur = 0;

  // Number text
  ctx.font = 'bold 54px monospace';
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(count.toString(), cx, cy + 2);

  const texture = new THREE.CanvasTexture(canvas);
  return texture;
}

// Create Photorealistic Earth Texture matching Conflictly Aesthetic
function createRealityEarthTexture(
  mode: MapMode = 'hybrid',
  selectedCountryId?: string | null,
  showConflictShading: boolean = true
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 4096;
  canvas.height = 2048;
  const ctx = canvas.getContext('2d')!;

  const geoData = getRealWorldGeoData();

  // 1. Conflictly Signature Ocean Base (Dark Midnight Obsidian Slate)
  if (mode === 'night') {
    ctx.fillStyle = '#040508';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  } else {
    // True Conflictly Dark Ocean Gradient
    const oceanGrad = ctx.createLinearGradient(0, 0, 0, canvas.height);
    oceanGrad.addColorStop(0.0, '#090b11'); // Arctic
    oceanGrad.addColorStop(0.3, '#0b0e16');
    oceanGrad.addColorStop(0.5, '#0e121c'); // Mid-Atlantic / Pacific
    oceanGrad.addColorStop(0.7, '#0b0e16');
    oceanGrad.addColorStop(1.0, '#07090e'); // Antarctic
    ctx.fillStyle = oceanGrad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Subtle Bathymetry Coastal Relief (faint slate-blue rim around landmasses)
    ctx.strokeStyle = 'rgba(30, 41, 59, 0.35)';
    ctx.lineWidth = 10;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    geoData.coastlines.forEach((line) => {
      ctx.beginPath();
      line.forEach(([lng, lat], idx) => {
        const [px, py] = geoToCanvas(lng, lat, canvas.width, canvas.height);
        if (idx === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      });
      ctx.stroke();
    });
  }

  // 2. Faint Tactical Graticule
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.07)';
  ctx.lineWidth = 1.0;

  for (let lat = -80; lat <= 80; lat += 20) {
    const y = ((90 - lat) / 180) * canvas.height;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke();
  }
  for (let lon = -180; lon <= 180; lon += 30) {
    const x = ((lon + 180) / 360) * canvas.width;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke();
  }

  // 3. Draw All Real Countries & Landmasses with Conflictly Styling
  geoData.countries.forEach((country) => {
    const info = country.info;
    const isSelected = selectedCountryId === country.id || (info && (selectedCountryId === info.code2 || selectedCountryId === info.code3));
    const isActiveWar = info?.conflictStatus === 'active_war';
    const isHighTension = info?.conflictStatus === 'high_tension';
    const isElevated = info?.conflictStatus === 'elevated';

    // Conflictly Charcoal Landmass Base Color
    let baseLandColor = '#1e222e'; // Dark tactical charcoal

    const lat = info?.lat ?? 30;
    if (lat > 68 || lat < -65) {
      baseLandColor = '#2a3342'; // Polar tundra
    } else if (info?.theater === 'Middle East' || info?.theater === 'Africa') {
      baseLandColor = '#232836'; // Warm tactical slate
    }

    // Apply Conflict Shading (Signature Conflictly Crimson / Amber)
    if (isSelected) {
      ctx.fillStyle = 'rgba(239, 68, 68, 0.75)';
    } else if (showConflictShading && isActiveWar) {
      // Signature Conflictly Crimson Shading (Russia, Ukraine, Sudan, Sahel, Middle East)
      ctx.fillStyle = 'rgba(185, 28, 28, 0.48)';
    } else if (showConflictShading && isHighTension) {
      // Tactical Amber Glow (Taiwan, Iran, North Korea, etc.)
      ctx.fillStyle = 'rgba(217, 119, 6, 0.32)';
    } else if (showConflictShading && isElevated) {
      ctx.fillStyle = 'rgba(30, 41, 59, 0.65)';
    } else {
      ctx.fillStyle = baseLandColor;
    }

    // Draw Country Polygon
    country.coordinates.forEach((ring) => {
      ctx.beginPath();
      ring.forEach(([lon, lt], idx) => {
        const [px, py] = geoToCanvas(lon, lt, canvas.width, canvas.height);
        if (idx === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      });
      ctx.closePath();
      ctx.fill();
    });
  });

  // 4. Draw Mountain Ranges Topographical Relief (Himalayas, Alps, Rockies, Andes, Caucasus)
  const mountainRidges: [number, number][][] = [
    [[74, 35], [78, 32], [84, 29], [90, 28], [95, 29], [102, 32]],
    [[76, 36], [82, 34], [88, 33], [94, 34], [98, 36]],
    [[-70, 10], [-76, 2], [-78, -5], [-76, -15], [-69, -22], [-70, -33], [-72, -45], [-70, -54]],
    [[6, 45.5], [8, 46.5], [11, 47], [14, 46.5]],
    [[-122, 58], [-116, 52], [-112, 45], [-106, 38], [-104, 32]],
    [[40, 43.5], [44, 42.5], [48, 41.5]],
    [[60, 66], [59, 60], [58, 54]],
  ];

  ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
  ctx.lineWidth = 3.5;
  ctx.lineCap = 'round';
  mountainRidges.forEach((ridge) => {
    ctx.beginPath();
    ridge.forEach(([lng, lat], idx) => {
      const [px, py] = geoToCanvas(lng, lat, canvas.width, canvas.height);
      if (idx === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    });
    ctx.stroke();
  });

  // 5. Draw Sharp International Country Borders
  ctx.strokeStyle = 'rgba(148, 163, 184, 0.42)';
  ctx.lineWidth = 1.3;
  geoData.countryBorders.forEach((line) => {
    ctx.beginPath();
    line.forEach(([lng, lat], idx) => {
      const [px, py] = geoToCanvas(lng, lat, canvas.width, canvas.height);
      if (idx === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    });
    ctx.stroke();
  });

  // 6. Highlight Active Conflict & Tension Borders with Glowing Tactical Lines
  if (showConflictShading) {
    geoData.countries.forEach((country) => {
      const info = country.info;
      if (!info) return;

      const isActiveWar = info.conflictStatus === 'active_war';
      const isHighTension = info.conflictStatus === 'high_tension';

      if (isActiveWar || isHighTension) {
        ctx.strokeStyle = isActiveWar ? '#ef4444' : '#f59e0b';
        ctx.lineWidth = isActiveWar ? 2.6 : 2.0;
        ctx.shadowColor = isActiveWar ? '#ef4444' : '#f59e0b';
        ctx.shadowBlur = 7;

        country.coordinates.forEach((ring) => {
          ctx.beginPath();
          ring.forEach(([lon, lt], idx) => {
            const [px, py] = geoToCanvas(lon, lt, canvas.width, canvas.height);
            if (idx === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
          });
          ctx.closePath();
          ctx.stroke();
        });
        ctx.shadowBlur = 0; // reset shadow
      }
    });
  }

  // 7. Tactical Country Labels Directly on the Globe Surface (Matching Conflictly Style)
  const LABELED_COUNTRIES: Array<{ name: string; lat: number; lng: number; isWar?: boolean; isTension?: boolean }> = [
    { name: 'RUSSIA', lat: 58.0, lng: 55.0, isWar: true },
    { name: 'UKRAINE', lat: 49.0, lng: 31.5, isWar: true },
    { name: 'POLAND', lat: 52.0, lng: 19.5 },
    { name: 'GERMANY', lat: 51.2, lng: 10.4 },
    { name: 'FRANCE', lat: 46.5, lng: 2.5 },
    { name: 'SPAIN', lat: 40.5, lng: -3.7 },
    { name: 'SWEDEN', lat: 60.1, lng: 18.6 },
    { name: 'NORWAY', lat: 60.5, lng: 8.5 },
    { name: 'FINLAND', lat: 62.0, lng: 26.0 },
    { name: 'TURKEY', lat: 39.0, lng: 35.2 },
    { name: 'SAUDI ARABIA', lat: 24.0, lng: 45.0 },
    { name: 'IRAN', lat: 32.5, lng: 53.7, isTension: true },
    { name: 'IRAQ', lat: 33.2, lng: 43.7, isTension: true },
    { name: 'SYRIA', lat: 35.0, lng: 38.5, isWar: true },
    { name: 'ISRAEL', lat: 31.5, lng: 35.0, isWar: true },
    { name: 'LEBANON', lat: 33.9, lng: 35.9, isWar: true },
    { name: 'YEMEN', lat: 15.5, lng: 48.5, isWar: true },
    { name: 'SUDAN', lat: 14.5, lng: 30.5, isWar: true },
    { name: 'MALI', lat: 17.5, lng: -4.0, isWar: true },
    { name: 'NIGER', lat: 17.6, lng: 8.1, isWar: true },
    { name: 'BURKINA FASO', lat: 12.2, lng: -1.5, isWar: true },
    { name: 'NIGERIA', lat: 9.1, lng: 8.7, isTension: true },
    { name: 'LIBYA', lat: 26.3, lng: 17.2, isTension: true },
    { name: 'EGYPT', lat: 26.8, lng: 30.8, isTension: true },
    { name: 'ALGERIA', lat: 28.0, lng: 1.7 },
    { name: 'MOROCCO', lat: 31.8, lng: -7.1 },
    { name: 'KAZAKHSTAN', lat: 48.0, lng: 67.0 },
    { name: 'CHINA', lat: 35.8, lng: 104.2 },
    { name: 'TAIWAN', lat: 23.7, lng: 121.0, isTension: true },
    { name: 'JAPAN', lat: 36.2, lng: 138.2 },
    { name: 'SOUTH KOREA', lat: 36.0, lng: 127.8 },
    { name: 'INDIA', lat: 20.6, lng: 79.0 },
    { name: 'UNITED STATES', lat: 38.0, lng: -97.0 },
    { name: 'UNITED KINGDOM', lat: 54.5, lng: -3.0 },
    { name: 'BRAZIL', lat: -14.0, lng: -52.0 },
    { name: 'AUSTRALIA', lat: -25.0, lng: 134.0 },
  ];

  LABELED_COUNTRIES.forEach((c) => {
    const [px, py] = geoToCanvas(c.lng, c.lat, canvas.width, canvas.height);

    ctx.font = 'bold 15px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    if (c.isWar) {
      ctx.fillStyle = '#fca5a5'; // Soft glowing red for warzones
    } else if (c.isTension) {
      ctx.fillStyle = '#fde68a'; // Soft amber for tensions
    } else {
      ctx.fillStyle = 'rgba(226, 232, 240, 0.75)'; // Clean crisp white/slate
    }

    ctx.fillText(c.name, px, py);
  });

  // 8. Night City Lights
  if (mode === 'night' || mode === 'hybrid') {
    URBAN_LIGHTS.forEach((city) => {
      const [cx, cy] = geoToCanvas(city.lng, city.lat, canvas.width, canvas.height);
      const rad = 5 * city.intensity;

      const glowGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, rad * 2.5);
      glowGrad.addColorStop(0, 'rgba(253, 224, 71, 0.9)');
      glowGrad.addColorStop(0.4, 'rgba(245, 158, 11, 0.5)');
      glowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

      ctx.fillStyle = glowGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, rad * 2.5, 0, Math.PI * 2);
      ctx.fill();
    });
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  return texture;
}

// Generate Realistic Atmospheric Cloud Texture for 3D Parallax Layer
function createAtmosphericCloudTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 2048;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = 'rgba(0, 0, 0, 0)';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Soft atmospheric cloud bands with cyclones and tropical convergence zone (ITCZ)
  const numClouds = 90;
  for (let i = 0; i < numClouds; i++) {
    const cx = Math.random() * canvas.width;
    const cy = (Math.random() * 0.7 + 0.15) * canvas.height;
    const rx = Math.random() * 180 + 60;
    const ry = Math.random() * 50 + 20;

    const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, rx);
    grad.addColorStop(0, 'rgba(255, 255, 255, 0.55)');
    grad.addColorStop(0.4, 'rgba(255, 255, 255, 0.3)');
    grad.addColorStop(0.8, 'rgba(240, 245, 255, 0.1)');
    grad.addColorStop(1, 'rgba(255, 255, 255, 0)');

    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.ellipse(cx, cy, rx, ry, Math.random() * 0.4 - 0.2, 0, Math.PI * 2);
    ctx.fill();
  }

  // Cyclonic cloud spirals (North Atlantic & North Pacific storm tracks)
  const spirals = [
    { x: canvas.width * 0.42, y: canvas.height * 0.3 }, // North Atlantic
    { x: canvas.width * 0.82, y: canvas.height * 0.32 }, // North Pacific
    { x: canvas.width * 0.25, y: canvas.height * 0.75 }, // Southern Ocean
  ];

  spirals.forEach((sp) => {
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
    ctx.lineWidth = 12;
    ctx.beginPath();
    for (let a = 0; a < Math.PI * 4; a += 0.1) {
      const r = a * 16;
      const x = sp.x + r * Math.cos(a);
      const y = sp.y + (r * 0.6) * Math.sin(a);
      if (a === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  });

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  return texture;
}

export const Globe3D: React.FC<Globe3DProps> = ({
  events,
  selectedEventId,
  onSelectEvent,
  onSelectCountry,
  focusedEventId,
  focusedCountryId,
  activeTheater = 'GLOBAL',
  onTheaterChange,
  leftPanelCollapsed = false,
  rightPanelCollapsed = false,
  onToggleLeftPanel,
  onToggleRightPanel,
  isGlobeFocusMode = false,
  onToggleGlobeFocus,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);

  // States
  const [mapMode, setMapMode] = useState<MapMode>('hybrid');
  const [showClouds, setShowClouds] = useState<boolean>(true);
  const [showConflictShading, setShowConflictShading] = useState<boolean>(true);
  const [showChokepoints, setShowChokepoints] = useState<boolean>(true);
  const [showFlightTracks, setShowFlightTracks] = useState<boolean>(true);

  const [hoveredEvent, setHoveredEvent] = useState<GlobalEvent | null>(null);
  const [hoveredCountry, setHoveredCountry] = useState<RealCountryInfo | null>(null);
  const [hoveredChokepoint, setHoveredChokepoint] = useState<typeof CHOKEPOINTS[0] | null>(null);
  const [tooltipPos, setTooltipPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isAutoRotating, setIsAutoRotating] = useState<boolean>(true);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [viewportWidth, setViewportWidth] = useState<number>(window.innerWidth);

  // Three.js References
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const globeGroupRef = useRef<THREE.Group | null>(null);
  const markersGroupRef = useRef<THREE.Group | null>(null);
  const clustersGroupRef = useRef<THREE.Group | null>(null);
  const bordersGroupRef = useRef<THREE.Group | null>(null);
  const chokepointsGroupRef = useRef<THREE.Group | null>(null);
  const flightsGroupRef = useRef<THREE.Group | null>(null);
  const flightAircraftsRef = useRef<Array<{ mesh: THREE.Mesh; flight: ReconFlight; progress: number }>>([]);
  const earthMeshRef = useRef<THREE.Mesh | null>(null);
  const cloudsMeshRef = useRef<THREE.Mesh | null>(null);
  const pulseRingsRef = useRef<THREE.Mesh[]>([]);

  const isDraggingRef = useRef<boolean>(false);
  const previousMousePositionRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const touchStartDistRef = useRef<number | null>(null);
  const autoRotateRef = useRef<boolean>(true);
  autoRotateRef.current = isAutoRotating;

  // Browser Fullscreen State Detection & Controller
  const [isBrowserFullscreen, setIsBrowserFullscreen] = useState<boolean>(false);

  useEffect(() => {
    const handleFsChange = () => {
      setIsBrowserFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  const toggleBrowserFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      }
    }
  };

  const GLOBE_RADIUS = 100;

  // Initialize Three.js Scene
  useEffect(() => {
    if (!mountRef.current) return;

    const width = mountRef.current.clientWidth || window.innerWidth;
    const height = mountRef.current.clientHeight || window.innerHeight;

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 1, 2000);
    camera.position.z = 265;
    cameraRef.current = camera;

    // Renderer with ACES Filmic Tone Mapping for Realistic Google Earth Lighting
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    mountRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Hierarchy Groups
    const globeGroup = new THREE.Group();
    scene.add(globeGroup);
    globeGroupRef.current = globeGroup;

    const bordersGroup = new THREE.Group();
    globeGroup.add(bordersGroup);
    bordersGroupRef.current = bordersGroup;

    const chokepointsGroup = new THREE.Group();
    globeGroup.add(chokepointsGroup);
    chokepointsGroupRef.current = chokepointsGroup;

    const flightsGroup = new THREE.Group();
    globeGroup.add(flightsGroup);
    flightsGroupRef.current = flightsGroup;

    const clustersGroup = new THREE.Group();
    globeGroup.add(clustersGroup);
    clustersGroupRef.current = clustersGroup;

    const markersGroup = new THREE.Group();
    globeGroup.add(markersGroup);
    markersGroupRef.current = markersGroup;

    // Lighting (Sunlight simulation + soft ambient scatter)
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.1);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfff5ea, 1.6);
    sunLight.position.set(250, 180, 220);
    scene.add(sunLight);

    const rimLight = new THREE.DirectionalLight(0x38bdf8, 0.7);
    rimLight.position.set(-250, -100, -180);
    scene.add(rimLight);

    // 1. Earth Sphere with Reality Texture
    const earthTexture = createRealityEarthTexture(mapMode, focusedCountryId, showConflictShading);
    const sphereGeo = new THREE.SphereGeometry(GLOBE_RADIUS, 128, 128);
    const sphereMat = new THREE.MeshStandardMaterial({
      map: earthTexture,
      roughness: 0.55,
      metalness: 0.12,
      emissive: new THREE.Color(0x06080c),
      emissiveIntensity: 0.35,
    });
    const earthMesh = new THREE.Mesh(sphereGeo, sphereMat);
    (earthMesh as any).isEarth = true;
    globeGroup.add(earthMesh);
    earthMeshRef.current = earthMesh;

    // 2. Realistic 3D Vector Line Borders from Natural Earth 110m GeoData
    const geoData = getRealWorldGeoData();
    const borderPoints: THREE.Vector3[] = [];

    geoData.countryBorders.forEach((line) => {
      for (let i = 0; i < line.length - 1; i++) {
        const p1 = latLngToVector3(line[i][1], line[i][0], GLOBE_RADIUS + 0.25);
        const p2 = latLngToVector3(line[i + 1][1], line[i + 1][0], GLOBE_RADIUS + 0.25);
        borderPoints.push(p1, p2);
      }
    });

    const borderGeo = new THREE.BufferGeometry().setFromPoints(borderPoints);
    const borderMat = new THREE.LineBasicMaterial({
      color: 0x94a3b8,
      transparent: true,
      opacity: 0.65,
    });
    const borderLines = new THREE.LineSegments(borderGeo, borderMat);
    bordersGroup.add(borderLines);

    // 3. Realistic 3D Atmosphere Clouds Layer (Parallax rotating cloud sphere)
    const cloudTexture = createAtmosphericCloudTexture();
    const cloudGeo = new THREE.SphereGeometry(GLOBE_RADIUS * 1.009, 64, 64);
    const cloudMat = new THREE.MeshLambertMaterial({
      map: cloudTexture,
      transparent: true,
      opacity: 0.38,
      blending: THREE.NormalBlending,
      depthWrite: false,
    });
    const cloudsMesh = new THREE.Mesh(cloudGeo, cloudMat);
    globeGroup.add(cloudsMesh);
    cloudsMeshRef.current = cloudsMesh;

    // 4. Photorealistic Atmospheric Rayleigh Scattering Outer Halo (Conflictly Crisp Cyan-Blue Aerospace Rim)
    const glowGeo = new THREE.SphereGeometry(GLOBE_RADIUS * 1.035, 64, 64);
    const glowMat = new THREE.ShaderMaterial({
      vertexShader: `
        varying vec3 vNormal;
        void main() {
          vNormal = normalize(normalMatrix * normal);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec3 vNormal;
        void main() {
          float intensity = pow(0.72 - dot(vNormal, vec3(0, 0, 1.0)), 2.8);
          // Conflictly signature crisp cyan-blue aerospace rim halo
          vec3 atmosphereColor = mix(vec3(0.12, 0.62, 0.98), vec3(0.04, 0.32, 0.75), vNormal.y * 0.35 + 0.5);
          gl_FragColor = vec4(atmosphereColor, 1.0) * intensity * 1.6;
        }
      `,
      blending: THREE.AdditiveBlending,
      side: THREE.BackSide,
      transparent: true,
    });
    const glowMesh = new THREE.Mesh(glowGeo, glowMat);
    scene.add(glowMesh);

    // Initial Globe Orientation: Focus directly on Europe & Middle East axis (as in Conflictly screenshot)
    globeGroup.rotation.y = -0.6;
    globeGroup.rotation.x = 0.38;

    // 5. Deep Space Background Starfield
    const starsCount = 900;
    const starsGeo = new THREE.BufferGeometry();
    const starPositions = new Float32Array(starsCount * 3);
    for (let i = 0; i < starsCount * 3; i += 3) {
      starPositions[i] = (Math.random() - 0.5) * 1400;
      starPositions[i + 1] = (Math.random() - 0.5) * 1400;
      starPositions[i + 2] = (Math.random() - 0.5) * 1400;
    }
    starsGeo.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    const starsMat = new THREE.PointsMaterial({
      color: 0x94a3b8,
      size: 1.2,
      transparent: true,
      opacity: 0.55,
    });
    const starField = new THREE.Points(starsGeo, starsMat);
    scene.add(starField);

    // Animation Loop
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      if (autoRotateRef.current && globeGroupRef.current && !isDraggingRef.current) {
        globeGroupRef.current.rotation.y += 0.0014;
      }

      // Parallax cloud rotation slightly faster
      if (cloudsMeshRef.current) {
        cloudsMeshRef.current.rotation.y += 0.0003;
      }

      // Animate pulsing radar rings
      pulseRingsRef.current.forEach((ring) => {
        const scale = ring.scale.x + 0.015;
        if (scale > 2.4) {
          ring.scale.set(1, 1, 1);
          (ring.material as THREE.MeshBasicMaterial).opacity = 0.85;
        } else {
          ring.scale.set(scale, scale, 1);
          (ring.material as THREE.MeshBasicMaterial).opacity = 0.85 * (1 - (scale - 1) / 1.4);
        }
      });

      // Animate Live Tactical Aircraft Fleets
      flightAircraftsRef.current.forEach((item) => {
        item.progress = (item.progress + item.flight.speed) % 1.0;
        const n = item.flight.route.length;
        const rawIdx = item.progress * (n - 1);
        const idx = Math.floor(rawIdx);
        const nextIdx = (idx + 1) % n;
        const t = rawIdx - idx;

        const [lat1, lng1] = item.flight.route[idx];
        const [lat2, lng2] = item.flight.route[nextIdx];

        const curLat = lat1 + (lat2 - lat1) * t;
        const curLng = lng1 + (lng2 - lng1) * t;

        const curPos = latLngToVector3(curLat, curLng, GLOBE_RADIUS + 2.2);
        const nextPos = latLngToVector3(lat2, lng2, GLOBE_RADIUS + 2.2);
        const normal = curPos.clone().normalize();

        item.mesh.position.copy(curPos);
        item.mesh.lookAt(curPos.clone().add(normal));
        item.mesh.up.copy(nextPos.clone().sub(curPos).normalize());
      });

      renderer.render(scene, camera);
    };
    animate();

    // Responsive Resize Handler with ResizeObserver
    const handleResize = () => {
      if (!mountRef.current || !renderer || !camera) return;
      const w = mountRef.current.clientWidth || window.innerWidth;
      const h = mountRef.current.clientHeight || window.innerHeight;
      if (w === 0 || h === 0) return;

      setViewportWidth(w);
      camera.aspect = w / h;

      // Dynamically adapt base camera distance based on viewport width
      // Standard mobile (360px-390px) gets slightly higher distance for ideal framing
      if (w < 480) {
        if (camera.position.z < 290) camera.position.z = 290;
      } else if (w < 768) {
        if (camera.position.z < 275) camera.position.z = 275;
      }

      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    const resizeObserver = new ResizeObserver(() => {
      handleResize();
    });

    if (mountRef.current) {
      resizeObserver.observe(mountRef.current);
    }
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      window.removeEventListener('resize', handleResize);
      if (renderer.domElement && renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  // Update Earth Texture when mapMode or focus changes
  useEffect(() => {
    if (!earthMeshRef.current) return;
    const newTexture = createRealityEarthTexture(mapMode, focusedCountryId, showConflictShading);
    const mat = earthMeshRef.current.material as THREE.MeshStandardMaterial;
    mat.map = newTexture;
    mat.needsUpdate = true;
  }, [mapMode, focusedCountryId, showConflictShading]);

  // Update Cloud Visibility
  useEffect(() => {
    if (cloudsMeshRef.current) {
      cloudsMeshRef.current.visible = showClouds;
    }
  }, [showClouds]);

  // Render Strategic Chokepoints & Recon Flights
  useEffect(() => {
    const chokepointsGroup = chokepointsGroupRef.current;
    const flightsGroup = flightsGroupRef.current;
    if (!chokepointsGroup || !flightsGroup) return;

    while (chokepointsGroup.children.length > 0) chokepointsGroup.remove(chokepointsGroup.children[0]);
    while (flightsGroup.children.length > 0) flightsGroup.remove(flightsGroup.children[0]);

    if (showChokepoints) {
      CHOKEPOINTS.forEach((cp) => {
        const pos = latLngToVector3(cp.lat, cp.lng, GLOBE_RADIUS + 1.2);
        const normal = pos.clone().normalize();

        const cpObj = new THREE.Group();
        cpObj.position.copy(pos);
        cpObj.lookAt(pos.clone().add(normal));
        (cpObj as any).chokepointData = cp;

        const iconGeo = new THREE.RingGeometry(1.2, 2.2, 16);
        const iconMat = new THREE.MeshBasicMaterial({
          color: 0x0ea5e9,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.85,
        });
        const iconMesh = new THREE.Mesh(iconGeo, iconMat);
        cpObj.add(iconMesh);

        chokepointsGroup.add(cpObj);
      });
    }

    if (showFlightTracks) {
      const aircraftTexture = createAircraftSpriteTexture();

      CONFLICTLY_FLIGHTS.forEach((fl) => {
        // 1. Dashed flight patrol orbit
        const points: THREE.Vector3[] = [];
        fl.route.forEach(([lat, lng]) => {
          points.push(latLngToVector3(lat, lng, GLOBE_RADIUS + 2.0));
        });
        const lineGeo = new THREE.BufferGeometry().setFromPoints(points);
        const lineMat = new THREE.LineDashedMaterial({
          color: 0x38bdf8,
          dashSize: 2.5,
          gapSize: 1.5,
          transparent: true,
          opacity: 0.7,
        });
        const lineObj = new THREE.LineLoop(lineGeo, lineMat);
        lineObj.computeLineDistances();
        flightsGroup.add(lineObj);

        // 2. Active Military Aircraft Silhouette Mesh
        const planeGeo = new THREE.PlaneGeometry(3.6, 3.6);
        const planeMat = new THREE.MeshBasicMaterial({
          map: aircraftTexture,
          transparent: true,
          opacity: 0.95,
          side: THREE.DoubleSide,
          depthWrite: false,
        });
        const planeMesh = new THREE.Mesh(planeGeo, planeMat);

        const initialPos = latLngToVector3(fl.route[0][0], fl.route[0][1], GLOBE_RADIUS + 2.2);
        planeMesh.position.copy(initialPos);
        flightsGroup.add(planeMesh);

        flightAircraftsRef.current.push({
          mesh: planeMesh,
          flight: fl,
          progress: Math.random(), // Stagger initial flight positions
        });
      });
    }
  }, [showChokepoints, showFlightTracks]);

  // Update Event Markers and Cluster Badges
  useEffect(() => {
    const markersGroup = markersGroupRef.current;
    const clustersGroup = clustersGroupRef.current;
    if (!markersGroup || !clustersGroup) return;

    while (markersGroup.children.length > 0) markersGroup.remove(markersGroup.children[0]);
    while (clustersGroup.children.length > 0) clustersGroup.remove(clustersGroup.children[0]);
    pulseRingsRef.current = [];

    // 1. Render Conflict Tension Clusters with High-DPI Numbered Badges (Exact Conflictly Look)
    const clusterPositions = [
      { lat: 33.5, lng: 35.8, count: 12, label: 'MIDDLE EAST', isCritical: true },
      { lat: 51.5, lng: 36.2, count: 9, label: 'KURSK / DONBAS', isCritical: true },
      { lat: 14.5, lng: 31.0, count: 8, label: 'SUDAN', isCritical: true },
      { lat: 14.0, lng: 44.0, count: 7, label: 'RED SEA', isCritical: true },
      { lat: 23.5, lng: 121.0, count: 6, label: 'TAIWAN STRAIT', isCritical: false },
      { lat: 17.5, lng: -4.0, count: 4, label: 'SAHEL', isCritical: false },
    ];

    clusterPositions.forEach((cluster) => {
      const position = latLngToVector3(cluster.lat, cluster.lng, GLOBE_RADIUS + 1.8);
      const normal = position.clone().normalize();

      const clusterObj = new THREE.Group();
      clusterObj.position.copy(position);
      clusterObj.lookAt(position.clone().add(normal));

      // High-DPI Numbered Badge Plane
      const badgeTexture = createClusterBadgeTexture(cluster.count, cluster.isCritical);
      const badgeGeo = new THREE.PlaneGeometry(6.4, 6.4);
      const badgeMat = new THREE.MeshBasicMaterial({
        map: badgeTexture,
        transparent: true,
        opacity: 0.95,
        side: THREE.DoubleSide,
      });
      const badgeMesh = new THREE.Mesh(badgeGeo, badgeMat);
      clusterObj.add(badgeMesh);

      // Expanding Radar Pulse Ring
      const pulseGeo = new THREE.RingGeometry(3.6, 5.8, 24);
      const pulseMat = new THREE.MeshBasicMaterial({
        color: cluster.isCritical ? 0xef4444 : 0xf59e0b,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.85,
      });
      const pulseMesh = new THREE.Mesh(pulseGeo, pulseMat);
      pulseMesh.position.z = -0.1;
      clusterObj.add(pulseMesh);
      pulseRingsRef.current.push(pulseMesh);

      clustersGroup.add(clusterObj);
    });

    // 2. Render Individual Intel Markers
    events.forEach((evt) => {
      const meta = getCategoryMeta(evt.category);
      const position = latLngToVector3(evt.location.lat, evt.location.lng, GLOBE_RADIUS + 1.2);
      const normal = position.clone().normalize();

      const markerObj = new THREE.Group();
      markerObj.position.copy(position);
      markerObj.lookAt(position.clone().add(normal));
      (markerObj as any).eventData = evt;

      const isSelected = selectedEventId === evt.id;
      const isHot = evt.isHotAlert;

      const pinColor = new THREE.Color(isHot ? 0xef4444 : meta.accentHex);
      const pinGeo = new THREE.SphereGeometry(isSelected ? 3.0 : isHot ? 2.4 : 1.8, 16, 16);
      const pinMat = new THREE.MeshStandardMaterial({
        color: pinColor,
        emissive: pinColor,
        emissiveIntensity: isHot ? 1.0 : 0.6,
        roughness: 0.2,
      });
      const pinMesh = new THREE.Mesh(pinGeo, pinMat);
      markerObj.add(pinMesh);

      const stemGeo = new THREE.CylinderGeometry(0.3, 0.3, 3.5, 8);
      const stemMat = new THREE.MeshBasicMaterial({ color: pinColor });
      const stemMesh = new THREE.Mesh(stemGeo, stemMat);
      stemMesh.position.z = -1.8;
      stemMesh.rotation.x = Math.PI / 2;
      markerObj.add(stemMesh);

      markersGroup.add(markerObj);
    });
  }, [events, selectedEventId]);

  // Focus Camera to Event Coordinates or Theater
  useEffect(() => {
    if (!globeGroupRef.current || !cameraRef.current) return;
    const globe = globeGroupRef.current;

    if (focusedEventId) {
      const targetEvent = events.find((e) => e.id === focusedEventId);
      if (targetEvent) {
        const targetY = -(targetEvent.location.lng + 180) * (Math.PI / 180) + Math.PI;
        const targetX = (targetEvent.location.lat * Math.PI) / 180;
        globe.rotation.y = targetY;
        globe.rotation.x = targetX * 0.4;
        setIsAutoRotating(false);
        return;
      }
    }

    if (focusedCountryId) {
      const info = REAL_COUNTRIES_MAP[focusedCountryId] || Object.values(REAL_COUNTRIES_MAP).find(c => c.code2 === focusedCountryId || c.code3 === focusedCountryId);
      if (info) {
        const targetY = -(info.lng + 180) * (Math.PI / 180) + Math.PI;
        const targetX = (info.lat * Math.PI) / 180;
        globe.rotation.y = targetY;
        globe.rotation.x = targetX * 0.4;
        setIsAutoRotating(false);
        return;
      }
    }

    // Theater presets
    if (activeTheater === 'Europe') {
      globe.rotation.y = -(30 + 180) * (Math.PI / 180) + Math.PI;
      globe.rotation.x = 0.35;
      setIsAutoRotating(false);
    } else if (activeTheater === 'Middle East') {
      globe.rotation.y = -(45 + 180) * (Math.PI / 180) + Math.PI;
      globe.rotation.x = 0.25;
      setIsAutoRotating(false);
    } else if (activeTheater === 'Asia-Pacific') {
      globe.rotation.y = -(120 + 180) * (Math.PI / 180) + Math.PI;
      globe.rotation.x = 0.2;
      setIsAutoRotating(false);
    } else if (activeTheater === 'Africa') {
      globe.rotation.y = -(20 + 180) * (Math.PI / 180) + Math.PI;
      globe.rotation.x = 0.1;
      setIsAutoRotating(false);
    }
  }, [focusedEventId, focusedCountryId, activeTheater, events]);

  // Mouse & Touch Controls
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      isDraggingRef.current = true;
      previousMousePositionRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      touchStartDistRef.current = null;
    } else if (e.touches.length === 2) {
      isDraggingRef.current = false;
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      touchStartDistRef.current = dist;
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!mountRef.current || !cameraRef.current || !globeGroupRef.current) return;

    if (e.touches.length === 1 && isDraggingRef.current) {
      const deltaX = e.touches[0].clientX - previousMousePositionRef.current.x;
      const deltaY = e.touches[0].clientY - previousMousePositionRef.current.y;

      globeGroupRef.current.rotation.y += deltaX * 0.006;
      globeGroupRef.current.rotation.x += deltaY * 0.006;

      globeGroupRef.current.rotation.x = Math.max(
        -Math.PI / 3,
        Math.min(Math.PI / 3, globeGroupRef.current.rotation.x)
      );

      previousMousePositionRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    } else if (e.touches.length === 2 && touchStartDistRef.current !== null) {
      const newDist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      const delta = (touchStartDistRef.current - newDist) * 0.5;
      cameraRef.current.position.z = Math.max(140, Math.min(460, cameraRef.current.position.z + delta));
      setZoomLevel(Math.round((265 / cameraRef.current.position.z) * 100) / 100);
      touchStartDistRef.current = newDist;
    }
  };

  const handleTouchEnd = () => {
    isDraggingRef.current = false;
    touchStartDistRef.current = null;
  };

  const handleMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (!mountRef.current || !cameraRef.current || !markersGroupRef.current || !globeGroupRef.current) return;

      if (isDraggingRef.current) {
        const deltaX = e.clientX - previousMousePositionRef.current.x;
        const deltaY = e.clientY - previousMousePositionRef.current.y;

        globeGroupRef.current.rotation.y += deltaX * 0.005;
        globeGroupRef.current.rotation.x += deltaY * 0.005;

        globeGroupRef.current.rotation.x = Math.max(
          -Math.PI / 3,
          Math.min(Math.PI / 3, globeGroupRef.current.rotation.x)
        );

        previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
        return;
      }

      // Raycast for event pins and chokepoint interaction
      const rect = mountRef.current.getBoundingClientRect();
      const mouse = new THREE.Vector2(
        ((e.clientX - rect.left) / rect.width) * 2 - 1,
        -((e.clientY - rect.top) / rect.height) * 2 + 1
      );

      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(mouse, cameraRef.current);

      // Check event pins
      const pinIntersects = raycaster.intersectObjects(markersGroupRef.current.children, true);
      if (pinIntersects.length > 0) {
        let parent: THREE.Object3D | null = pinIntersects[0].object;
        while (parent && !(parent as any).eventData) {
          parent = parent.parent;
        }

        if (parent && (parent as any).eventData) {
          setHoveredEvent((parent as any).eventData);
          setHoveredCountry(null);
          setHoveredChokepoint(null);
          setTooltipPos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
          mountRef.current.style.cursor = 'pointer';
          return;
        }
      }

      // Check chokepoints
      if (chokepointsGroupRef.current) {
        const cpIntersects = raycaster.intersectObjects(chokepointsGroupRef.current.children, true);
        if (cpIntersects.length > 0) {
          let parent: THREE.Object3D | null = cpIntersects[0].object;
          while (parent && !(parent as any).chokepointData) parent = parent.parent;
          if (parent && (parent as any).chokepointData) {
            setHoveredChokepoint((parent as any).chokepointData);
            setHoveredEvent(null);
            setHoveredCountry(null);
            setTooltipPos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
            mountRef.current.style.cursor = 'pointer';
            return;
          }
        }
      }

      // Raycast on Earth sphere to detect hovered country
      if (earthMeshRef.current) {
        const earthIntersects = raycaster.intersectObject(earthMeshRef.current);
        if (earthIntersects.length > 0) {
          const point = earthIntersects[0].point;
          // Transform point to local globe coordinates
          const localPoint = globeGroupRef.current.worldToLocal(point.clone());
          const geo = vector3ToLatLng(localPoint, GLOBE_RADIUS);

          // Find matching real country in Natural Earth dataset
          const geoData = getRealWorldGeoData();
          let matchedCountry: RealCountryInfo | null = null;

          for (const c of geoData.countries) {
            if (!c.info) continue;
            for (const ring of c.coordinates) {
              if (isPointInPolygon([geo.lng, geo.lat], ring)) {
                matchedCountry = c.info;
                break;
              }
            }
            if (matchedCountry) break;
          }

          if (matchedCountry && (matchedCountry.conflictStatus === 'active_war' || matchedCountry.conflictStatus === 'high_tension' || matchedCountry.conflictStatus === 'elevated')) {
            setHoveredCountry(matchedCountry);
            setHoveredEvent(null);
            setHoveredChokepoint(null);
            setTooltipPos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
            mountRef.current.style.cursor = 'pointer';
            return;
          }
        }
      }

      setHoveredEvent(null);
      setHoveredCountry(null);
      setHoveredChokepoint(null);
      mountRef.current.style.cursor = isDraggingRef.current ? 'grabbing' : 'grab';
    },
    []
  );

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleClick = (e: React.MouseEvent) => {
    if (!mountRef.current || !cameraRef.current || !markersGroupRef.current) return;

    const rect = mountRef.current.getBoundingClientRect();
    const mouse = new THREE.Vector2(
      ((e.clientX - rect.left) / rect.width) * 2 - 1,
      -((e.clientY - rect.top) / rect.height) * 2 + 1
    );

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(mouse, cameraRef.current);

    const pinIntersects = raycaster.intersectObjects(markersGroupRef.current.children, true);
    if (pinIntersects.length > 0) {
      let parent: THREE.Object3D | null = pinIntersects[0].object;
      while (parent && !(parent as any).eventData) parent = parent.parent;

      if (parent && (parent as any).eventData) {
        onSelectEvent((parent as any).eventData);
        return;
      }
    }

    if (hoveredCountry && onSelectCountry) {
      onSelectCountry({
        id: hoveredCountry.code2,
        code: hoveredCountry.code3,
        name: hoveredCountry.name,
        flag: hoveredCountry.flag,
        lat: hoveredCountry.lat,
        lng: hoveredCountry.lng,
        conflictStatus: (hoveredCountry.conflictStatus as any) || 'elevated',
        tensionScore: hoveredCountry.tensionScore || 70,
        activeIncidents: hoveredCountry.activeIncidents || 3,
        threatSummary: hoveredCountry.threatSummary || 'Strategic monitoring active',
        theater: (hoveredCountry.theater as any) || 'Europe',
      });
    }
  };

  const handleWheel = (e: React.WheelEvent) => {
    if (!cameraRef.current) return;
    const newZ = cameraRef.current.position.z + e.deltaY * 0.15;
    cameraRef.current.position.z = Math.max(140, Math.min(460, newZ));
    setZoomLevel(Math.round((265 / cameraRef.current.position.z) * 100) / 100);
  };

  const resetCamera = () => {
    if (!cameraRef.current || !globeGroupRef.current) return;
    cameraRef.current.position.z = 265;
    globeGroupRef.current.rotation.set(0, 0, 0);
    setZoomLevel(1);
    setIsAutoRotating(true);
    if (onTheaterChange) onTheaterChange('GLOBAL');
  };

  const zoomIn = () => {
    if (!cameraRef.current) return;
    cameraRef.current.position.z = Math.max(140, cameraRef.current.position.z - 30);
    setZoomLevel(Math.round((265 / cameraRef.current.position.z) * 100) / 100);
  };

  const zoomOut = () => {
    if (!cameraRef.current) return;
    cameraRef.current.position.z = Math.min(460, cameraRef.current.position.z + 30);
    setZoomLevel(Math.round((265 / cameraRef.current.position.z) * 100) / 100);
  };

  return (
    <div
      ref={mountRef}
      id="watchtower-3d-globe"
      className="relative w-full h-full bg-[#06070a] overflow-hidden select-none cursor-grab active:cursor-grabbing touch-none"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onClick={handleClick}
      onWheel={handleWheel}
    >
      {/* Floating Left Dock Opener (Visible when Left Panel is Collapsed or in Fullscreen Globe) */}
      {leftPanelCollapsed && onToggleLeftPanel && (
        <div className="absolute top-1/2 -translate-y-1/2 left-3 z-20">
          <button
            onClick={onToggleLeftPanel}
            className="group flex items-center gap-2 px-3 py-2 rounded-r-lg rounded-l-md bg-[#101218]/95 backdrop-blur-xl border border-red-500/40 text-slate-200 hover:text-white hover:bg-red-950/80 shadow-2xl transition-all duration-200 hover:scale-105"
            title="Expand Intel Feed"
          >
            <Radio className="w-4 h-4 text-red-500 animate-pulse" />
            <span className="font-mono font-bold text-xs tracking-wider">INTEL FEED</span>
            <ChevronRight className="w-4 h-4 text-red-400 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>
      )}

      {/* Floating Right Dock Opener (Visible when Right Panel is Collapsed or in Fullscreen Globe) */}
      {rightPanelCollapsed && onToggleRightPanel && (
        <div className="absolute top-1/2 -translate-y-1/2 right-3 z-20">
          <button
            onClick={onToggleRightPanel}
            className="group flex items-center gap-2 px-3 py-2 rounded-l-lg rounded-r-md bg-[#101218]/95 backdrop-blur-xl border border-sky-500/40 text-slate-200 hover:text-white hover:bg-sky-950/80 shadow-2xl transition-all duration-200 hover:scale-105"
            title="Expand Defense Markets & Predictions"
          >
            <ChevronLeft className="w-4 h-4 text-sky-400 group-hover:-translate-x-0.5 transition-transform" />
            <span className="font-mono font-bold text-xs tracking-wider">MARKETS & INTEL</span>
            <Target className="w-4 h-4 text-sky-400" />
          </button>
        </div>
      )}

      {/* Top Left Controls: Focus Mode & Fullscreen */}
      <div className="absolute top-4 left-4 z-10 flex flex-wrap items-center gap-2">
        {/* Focus Globe Mode / Side Panels Toggle Button */}
        {onToggleGlobeFocus && (
          <button
            onClick={onToggleGlobeFocus}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded text-[11px] font-mono font-semibold backdrop-blur-md border shadow-xl transition-all ${
              isGlobeFocusMode
                ? 'bg-amber-600/90 text-white border-amber-400 shadow-amber-900/40'
                : 'bg-[#101218]/90 text-slate-300 hover:text-white border-[#262a36] hover:bg-[#1c202b]'
            }`}
            title={isGlobeFocusMode ? 'Restore side panels' : 'Maximize 3D Globe (Hide side panels)'}
          >
            {isGlobeFocusMode ? (
              <>
                <Minimize2 className="w-3.5 h-3.5 text-white" />
                <span className="hidden sm:inline">RESTORE PANELS</span>
              </>
            ) : (
              <>
                <Maximize2 className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">FOCUS GLOBE</span>
              </>
            )}
          </button>
        )}

        {/* Native Browser Fullscreen Toggle Button */}
        <button
          onClick={toggleBrowserFullscreen}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded text-[11px] font-mono font-semibold backdrop-blur-md border shadow-xl transition-all ${
            isBrowserFullscreen
              ? 'bg-sky-600/90 text-white border-sky-400 shadow-sky-900/40'
              : 'bg-[#101218]/90 text-slate-300 hover:text-white border-[#262a36] hover:bg-[#1c202b]'
          }`}
          title={isBrowserFullscreen ? 'Exit Full Screen' : 'Enter Full Screen (F11)'}
        >
          {isBrowserFullscreen ? (
            <>
              <Minimize2 className="w-3.5 h-3.5 text-white" />
              <span className="hidden sm:inline">EXIT FULLSCREEN</span>
            </>
          ) : (
            <>
              <Maximize2 className="w-3.5 h-3.5 text-sky-400" />
              <span className="hidden sm:inline">FULLSCREEN</span>
            </>
          )}
        </button>
      </div>

      {/* Top Right Map Style & Layer Switcher (Google Earth / Google Maps / Night Ops) */}
      <div className="absolute top-4 right-4 z-10 flex flex-col items-end gap-2">
        {/* Mode Selector */}
        <div className="flex items-center gap-1 bg-[#101218]/90 backdrop-blur-md border border-[#262a36] p-1 rounded-lg shadow-xl">
          <button
            onClick={() => setMapMode('hybrid')}
            className={`px-2.5 py-1 text-[11px] font-mono font-semibold rounded flex items-center gap-1 transition-all ${
              mapMode === 'hybrid'
                ? 'bg-sky-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#1a1d26]'
            }`}
          >
            <Layers className="w-3 h-3" />
            HYBRID
          </button>
          <button
            onClick={() => setMapMode('satellite')}
            className={`px-2.5 py-1 text-[11px] font-mono font-semibold rounded flex items-center gap-1 transition-all ${
              mapMode === 'satellite'
                ? 'bg-sky-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#1a1d26]'
            }`}
          >
            <Eye className="w-3 h-3" />
            SATELLITE
          </button>
          <button
            onClick={() => setMapMode('night')}
            className={`px-2.5 py-1 text-[11px] font-mono font-semibold rounded flex items-center gap-1 transition-all ${
              mapMode === 'night'
                ? 'bg-sky-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#1a1d26]'
            }`}
          >
            <Radio className="w-3 h-3" />
            NIGHT OPS
          </button>
        </div>

        {/* Tactical Layer Toggles */}
        <div className="flex items-center gap-1 bg-[#101218]/90 backdrop-blur-md border border-[#262a36] px-2 py-1 rounded-lg text-[10px] font-mono text-slate-300 shadow-xl">
          <button
            onClick={() => setShowClouds(!showClouds)}
            className={`px-1.5 py-0.5 rounded flex items-center gap-1 transition-all ${
              showClouds ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30' : 'text-slate-500 hover:text-slate-300'
            }`}
            title="Atmospheric Cloud Cover"
          >
            <Cloud className="w-3 h-3" />
            Clouds
          </button>
          <button
            onClick={() => setShowConflictShading(!showConflictShading)}
            className={`px-1.5 py-0.5 rounded flex items-center gap-1 transition-all ${
              showConflictShading ? 'bg-red-500/20 text-red-300 border border-red-500/30' : 'text-slate-500 hover:text-slate-300'
            }`}
            title="Active Conflict Heatmaps"
          >
            <Flame className="w-3 h-3" />
            Warzones
          </button>
          <button
            onClick={() => setShowChokepoints(!showChokepoints)}
            className={`px-1.5 py-0.5 rounded flex items-center gap-1 transition-all ${
              showChokepoints ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-500 hover:text-slate-300'
            }`}
            title="Maritime Chokepoints"
          >
            <Anchor className="w-3 h-3" />
            Chokepoints
          </button>
          <button
            onClick={() => setShowFlightTracks(!showFlightTracks)}
            className={`px-1.5 py-0.5 rounded flex items-center gap-1 transition-all ${
              showFlightTracks ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'text-slate-500 hover:text-slate-300'
            }`}
            title="Military Reconnaissance Flights"
          >
            <Plane className="w-3 h-3" />
            ISR Air
          </button>
        </div>
      </div>

      {/* Floating Bottom Right Orbit Controls */}
      <div className="absolute bottom-11 right-4 z-20 flex items-center gap-1 bg-[#101218]/90 backdrop-blur-md border border-[#262a36] p-1.5 rounded-lg shadow-2xl">
        <button
          onClick={() => setIsAutoRotating(!isAutoRotating)}
          title={isAutoRotating ? 'Pause Orbit' : 'Auto Orbit'}
          className={`p-1.5 rounded text-xs transition-all ${
            isAutoRotating
              ? 'bg-red-500/20 text-red-300 border border-red-500/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-[#1a1d26]'
          }`}
        >
          {isAutoRotating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
        </button>

        <div className="h-4 w-px bg-[#262a36]" />

        <button
          onClick={zoomIn}
          title="Zoom In"
          className="p-1.5 rounded text-slate-300 hover:text-white hover:bg-[#1a1d26] transition-colors"
        >
          <ZoomIn className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={zoomOut}
          title="Zoom Out"
          className="p-1.5 rounded text-slate-300 hover:text-white hover:bg-[#1a1d26] transition-colors"
        >
          <ZoomOut className="w-3.5 h-3.5" />
        </button>

        <div className="h-4 w-px bg-[#262a36]" />

        <button
          onClick={resetCamera}
          title="Reset Globe View"
          className="p-1.5 rounded text-slate-300 hover:text-white hover:bg-[#1a1d26] transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Bottom Center Tactical Telemetry Bar (Docked flush to the bottom of the screen) */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 z-20 flex items-center gap-3 px-4 sm:px-5 py-2 rounded-t-lg rounded-b-none bg-[#0a0c12]/95 backdrop-blur-md border-t border-x border-b-0 border-[#232734] text-[11px] font-mono text-slate-200 shadow-[0_-4px_20px_rgba(0,0,0,0.6)]">
        <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
          <span>📈 25</span>
          <span className="text-[10px] text-emerald-300">-1.0%</span>
        </div>
        <div className="h-3.5 w-px bg-[#262a36]" />
        <div className="flex items-center gap-2">
          <span className="text-red-400 font-bold">19 active</span>
          <span className="text-amber-400 font-bold">39 tensions</span>
        </div>
        <div className="h-3.5 w-px bg-[#262a36]" />
        <div className="flex items-center gap-1.5 text-slate-400">
          <Plane className="w-3 h-3 text-sky-400" />
          <span>284 ISR Flights</span>
        </div>
        <ChevronUp className="w-3.5 h-3.5 text-slate-500 hover:text-slate-300 cursor-pointer ml-0.5" />
      </div>

      {/* Hover Tooltip for Real Country Sitrep */}
      {hoveredCountry && (
        <div
          className="absolute z-20 pointer-events-none transform -translate-x-1/2 -translate-y-full mb-3"
          style={{ left: tooltipPos.x, top: tooltipPos.y - 12 }}
        >
          <div className="w-72 p-3.5 rounded-lg bg-[#101218]/95 backdrop-blur-xl border border-red-500/40 shadow-2xl text-slate-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between gap-2 mb-1.5">
              <span className="text-[12px] font-mono font-bold text-white flex items-center gap-1.5">
                <span className="text-base">{hoveredCountry.flag}</span> {hoveredCountry.name.toUpperCase()} ({hoveredCountry.code3})
              </span>
              <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                hoveredCountry.conflictStatus === 'active_war' ? 'bg-red-600 text-white' : 'bg-amber-600 text-white'
              }`}>
                {hoveredCountry.conflictStatus === 'active_war' ? 'WAR ZONE' : 'HIGH TENSION'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 my-2 py-1.5 px-2 bg-[#090b10] rounded border border-[#1e2330] text-[10px] font-mono">
              <div>
                <span className="text-slate-400 block">Tension Score</span>
                <span className="text-red-400 font-bold text-xs">{hoveredCountry.tensionScore ?? 85}/100</span>
              </div>
              <div>
                <span className="text-slate-400 block">Active Incidents</span>
                <span className="text-amber-400 font-bold text-xs">{hoveredCountry.activeIncidents ?? 5} events</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed mb-2">
              {hoveredCountry.threatSummary || 'Active defense surveillance in progress.'}
            </p>

            <div className="flex items-center justify-between text-[10px] text-red-400 pt-1.5 border-t border-[#1e222d] font-mono font-semibold">
              <span>Click country to inspect SITREP</span>
              <ExternalLink className="w-3 h-3" />
            </div>
          </div>
        </div>
      )}

      {/* Hover Tooltip for Maritime Chokepoints */}
      {hoveredChokepoint && (
        <div
          className="absolute z-20 pointer-events-none transform -translate-x-1/2 -translate-y-full mb-3"
          style={{ left: tooltipPos.x, top: tooltipPos.y - 12 }}
        >
          <div className="w-64 p-3 rounded-lg bg-[#101218]/95 backdrop-blur-xl border border-sky-500/40 shadow-2xl text-slate-100">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-white flex items-center gap-1">
                <Anchor className="w-3.5 h-3.5 text-sky-400" />
                {hoveredChokepoint.name}
              </span>
              <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 border border-sky-500/30">
                {hoveredChokepoint.threat}
              </span>
            </div>
            <p className="text-[11px] text-slate-300 font-mono">
              Transit flow: {hoveredChokepoint.flow}
            </p>
          </div>
        </div>
      )}

      {/* Interactive Hover Card for Events */}
      {hoveredEvent && (
        <div
          className="absolute z-20 pointer-events-none transform -translate-x-1/2 -translate-y-full mb-3"
          style={{ left: tooltipPos.x, top: tooltipPos.y - 12 }}
        >
          <div className="w-72 p-3.5 rounded-lg bg-[#101218]/95 backdrop-blur-xl border border-[#2d3342] shadow-2xl text-slate-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between gap-2 mb-1.5">
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/30 uppercase tracking-wider">
                {hoveredEvent.countryFlag || '🌐'} {hoveredEvent.category}
              </span>
              {hoveredEvent.isHotAlert && (
                <span className="flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-red-600 text-white font-mono">
                  <Flame className="w-3 h-3" />
                  HIGH
                </span>
              )}
            </div>

            <h4 className="text-xs font-bold text-white line-clamp-2 mb-1 leading-snug">
              {hoveredEvent.title}
            </h4>

            <p className="text-[11px] text-slate-300 line-clamp-2 mb-2 leading-relaxed">
              {hoveredEvent.summary}
            </p>

            <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1.5 border-t border-[#1e222d] font-mono">
              <span className="flex items-center gap-1">
                <MapPin className="w-3 h-3 text-red-400" />
                {hoveredEvent.location.city}, {hoveredEvent.location.country}
              </span>
              <span className="text-red-400 font-semibold flex items-center gap-0.5">
                Click to inspect <ExternalLink className="w-2.5 h-2.5" />
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
