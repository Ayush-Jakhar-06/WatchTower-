import React, { useState, useEffect } from 'react';
import { GlobalEvent, User, AuditLogEntry } from '../types.js';
import { getCategoryMeta, getSeverityBadge, getTrustTierBadge } from '../utils/categories.js';
import {
  ShieldCheck,
  ShieldAlert,
  Users,
  History,
  CheckCircle2,
  Ban,
  AlertTriangle,
  Flame,
  Sparkles,
  Search,
  ExternalLink,
  ChevronRight,
  Award,
  RefreshCw,
  Mail,
  User as UserIcon,
  UserCheck,
  Trash2,
} from 'lucide-react';

interface AdminPanelProps {
  currentUser: User | null;
  onSelectEvent: (event: GlobalEvent) => void;
  onRefreshData: () => void;
}

interface AdminReporterItem {
  id: string;
  codeName?: string;
  designation?: string;
  realName: string;
  realEmail: string;
  createdAt: string;
  profile?: {
    anonymousId: string;
    pseudonym: string;
    trustScore: number;
    tier: 'Rookie' | 'Veteran' | 'Virtuoso';
    approvedReportsCount: number;
    falseReportsCount: number;
    totalSubmitted: number;
    joinedDate: string;
  };
  scoreHistories?: any[];
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  currentUser,
  onSelectEvent,
  onRefreshData,
}) => {
  const [adminTab, setAdminTab] = useState<'moderation' | 'reporters' | 'audit'>('moderation');
  const [events, setEvents] = useState<GlobalEvent[]>([]);
  const [reporters, setReporters] = useState<AdminReporterItem[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [loading, setLoading] = useState<boolean>(false);
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);

  // Fetch admin data
  const loadAdminData = async () => {
    if (!currentUser || currentUser.role !== 'admin') return;
    setLoading(true);
    try {
      // 1. All events including pending / ai_checked
      const eventsRes = await fetch('/api/events', {
        headers: { Authorization: `Bearer ${currentUser.id}` },
      });
      if (eventsRes.ok) {
        const eventsData = await eventsRes.json();
        if (eventsData.success && Array.isArray(eventsData.events)) {
          setEvents(eventsData.events);
        }
      }

      // 2. Field Reporters Directory
      const reportersRes = await fetch('/api/admin/reporters', {
        headers: { Authorization: `Bearer ${currentUser.id}` },
      });
      if (reportersRes.ok) {
        const reportersData = await reportersRes.json();
        if (reportersData.success && Array.isArray(reportersData.reporters)) {
          setReporters(reportersData.reporters);
        }
      }

      // 3. Audit Logs
      const auditRes = await fetch('/api/admin/audit-logs', {
        headers: { Authorization: `Bearer ${currentUser.id}` },
      });
      if (auditRes.ok) {
        const auditData = await auditRes.json();
        if (auditData.success && Array.isArray(auditData.auditLogs)) {
          setAuditLogs(auditData.auditLogs);
        }
      }
    } catch (err) {
      console.error('Failed to load admin data', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAdminData();
  }, [currentUser]);

  // Handle Admin Moderation Action
  const handleModerate = async (
    eventId: string,
    action: 'approve' | 'reject' | 'mark_false',
    reason?: string
  ) => {
    if (!currentUser) return;
    try {
      const res = await fetch(`/api/admin/events/${eventId}/moderate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${currentUser.id}`,
        },
        body: JSON.stringify({ action, reason }),
      });
      const data = await res.json();
      if (data.success) {
        setActionSuccessMsg(
          action === 'approve'
            ? 'Report approved and published to 3D Globe (+10 Trust milestone evaluated).'
            : action === 'mark_false'
            ? 'Report flagged as Confirmed False & Rejected. -25 Trust Score penalty deducted.'
            : 'Report rejected.'
        );
        setTimeout(() => setActionSuccessMsg(null), 4000);
        loadAdminData();
        onRefreshData();
      }
    } catch (err) {
      console.error('Moderation action failed', err);
    }
  };

  // Toggle Hot Alert
  const handleToggleHot = async (eventId: string) => {
    if (!currentUser) return;
    try {
      const res = await fetch(`/api/admin/events/${eventId}/toggle-hot`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${currentUser.id}`,
        },
      });
      const data = await res.json();
      if (data.success) {
        loadAdminData();
        onRefreshData();
      }
    } catch (err) {
      console.error('Toggle hot failed', err);
    }
  };

  // Permanently delete report
  const handleDelete = async (eventId: string) => {
    if (!currentUser) return;
    if (!window.confirm('Are you sure you want to permanently delete this report? This action cannot be undone.')) return;
    try {
      const res = await fetch(`/api/admin/events/${eventId}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${currentUser.id}`,
        },
      });
      const data = await res.json();
      if (data.success) {
        setActionSuccessMsg('Report permanently purged from intelligence network.');
        setTimeout(() => setActionSuccessMsg(null), 4000);
        loadAdminData();
        onRefreshData();
      }
    } catch (err) {
      console.error('Delete event failed', err);
    }
  };

  const filteredEvents = events.filter((e) => {
    if (statusFilter === 'all') return true;
    if (statusFilter === 'rejected') {
      // In the admin dashboard, "rejected" also includes reports marked as false
      return e.status === 'rejected' || e.status === 'confirmed_false';
    }
    return e.status === statusFilter;
  });

  const pendingCount = events.filter((e) => e.status === 'ai_checked' || e.status === 'under_review' || e.status === 'submitted').length;
  const publishedCount = events.filter((e) => e.status === 'published' || (e.status as string) === 'approved').length;
  const rejectedCount = events.filter((e) => e.status === 'rejected' || e.status === 'confirmed_false').length;
  const falseCount = events.filter((e) => e.status === 'confirmed_false').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-slate-900/90 border border-purple-500/40 backdrop-blur-xl shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-purple-400">
            <ShieldCheck className="w-5 h-5" />
            <span className="text-xs font-mono font-bold uppercase tracking-wider">
              ADMINISTRATIVE CONTROL & MODERATION CENTER
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white">
            Moderation Queue & Reporter Trust Governance
          </h2>
          <p className="text-xs text-slate-300">
            Admin privilege active: Verified reporter real identities unlocked, trust score penalties, and audit trails.
          </p>
        </div>

        <button
          onClick={loadAdminData}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-all shrink-0"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Data</span>
        </button>
      </div>

      {actionSuccessMsg && (
        <div className="p-4 rounded-2xl bg-emerald-950/80 border border-emerald-500/60 text-emerald-200 text-xs flex items-center gap-2 shadow-lg animate-in fade-in duration-150">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{actionSuccessMsg}</span>
        </div>
      )}

      {/* Admin Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setAdminTab('moderation')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
            adminTab === 'moderation'
              ? 'bg-purple-500/20 text-purple-200 border border-purple-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <ShieldAlert className="w-4 h-4 text-purple-400" />
          <span>Moderation Queue</span>
          {pendingCount > 0 && (
            <span className="px-2 py-0.5 rounded-full bg-purple-600 text-white text-[10px] font-bold">
              {pendingCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setAdminTab('reporters')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
            adminTab === 'reporters'
              ? 'bg-purple-500/20 text-purple-200 border border-purple-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <Users className="w-4 h-4 text-purple-400" />
          <span>Field Reporter Directory ({reporters.length})</span>
        </button>

        <button
          onClick={() => setAdminTab('audit')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
            adminTab === 'audit'
              ? 'bg-purple-500/20 text-purple-200 border border-purple-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <History className="w-4 h-4 text-purple-400" />
          <span>System Audit Log ({auditLogs.length})</span>
        </button>
      </div>

      {/* TAB 1: MODERATION QUEUE */}
      {adminTab === 'moderation' && (
        <div className="space-y-4">
          {/* Filter sub-bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/60 p-3 rounded-2xl border border-slate-800">
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="text-slate-400 font-mono">Filter Status:</span>
              {[
                { id: 'all', label: `All (${events.length})` },
                { id: 'ai_checked', label: `Pending Review (${pendingCount})` },
                { id: 'published', label: `Published (${publishedCount})` },
                { id: 'rejected', label: `Rejected & False (${rejectedCount})` },
                { id: 'confirmed_false', label: `Confirmed False (${falseCount})` },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setStatusFilter(tab.id)}
                  className={`px-3 py-1 rounded-lg font-mono text-xs transition-all ${
                    statusFilter === tab.id
                      ? 'bg-purple-500/30 text-purple-200 border border-purple-500/60 font-bold'
                      : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <span className="text-xs font-mono text-slate-400">
              Showing {filteredEvents.length} items
            </span>
          </div>

          {filteredEvents.length === 0 ? (
            <div className="p-12 text-center bg-slate-900/60 border border-slate-800 rounded-3xl text-slate-400 text-xs">
              No reports matching status filter "{statusFilter}".
            </div>
          ) : (
            <div className="space-y-4">
              {filteredEvents.map((evt) => {
                const meta = getCategoryMeta(evt.category);
                const CategoryIcon = meta.icon;
                const sev = getSeverityBadge(evt.severity);
                const isPending = evt.status === 'ai_checked' || evt.status === 'under_review' || evt.status === 'submitted';

                return (
                  <div
                    key={evt.id}
                    className={`p-5 rounded-2xl border transition-all ${
                      isPending
                        ? 'bg-slate-900/95 border-purple-500/60 shadow-xl shadow-purple-950/30'
                        : 'bg-slate-900/70 border-slate-800'
                    }`}
                  >
                    <div className="flex flex-col lg:flex-row items-start justify-between gap-4">
                      {/* Left: Event Details */}
                      <div className="space-y-2 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span
                            className={`flex items-center gap-1 text-xs font-semibold px-2.5 py-0.5 rounded-lg border ${meta.bgColor} ${meta.color} ${meta.borderColor}`}
                          >
                            <CategoryIcon className="w-3.5 h-3.5" />
                            {evt.category}
                          </span>
                          <span className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded-md ${sev.className}`}>
                            {sev.label}
                          </span>
                          <span
                            className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded uppercase flex items-center gap-1 ${
                              evt.status === 'published'
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                : evt.status === 'confirmed_false'
                                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                                : evt.status === 'rejected'
                                ? 'bg-slate-800 text-slate-400 border border-slate-700'
                                : 'bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse'
                            }`}
                          >
                            {evt.status === 'confirmed_false' ? (
                              <>
                                <AlertTriangle className="w-3 h-3 text-rose-400" />
                                STATUS: REJECTED (CONFIRMED FALSE)
                              </>
                            ) : evt.status === 'rejected' ? (
                              <>
                                <Ban className="w-3 h-3 text-amber-400" />
                                STATUS: REJECTED
                              </>
                            ) : (
                              `STATUS: ${evt.status.replace('_', ' ')}`
                            )}
                          </span>
                          {evt.isHotAlert && (
                            <span className="flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/40">
                              <Flame className="w-3 h-3" /> HOT ALERT
                            </span>
                          )}
                        </div>

                        <h3 className="text-base font-bold text-white">{evt.title}</h3>
                        <p className="text-xs text-slate-300 leading-relaxed">{evt.description}</p>

                        <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-1 font-mono">
                          <span>
                            Location: <strong className="text-slate-200">{evt.location.city}, {evt.location.country}</strong> ({evt.location.lat.toFixed(2)}°, {evt.location.lng.toFixed(2)}°)
                          </span>
                          <span>
                            Event Time: {new Date(evt.eventDate).toLocaleDateString()}
                          </span>
                        </div>

                        {/* If Rejected or Confirmed False, highlight rejection reason */}
                        {(evt.status === 'confirmed_false' || evt.status === 'rejected') && (
                          <div className="p-3 rounded-xl bg-rose-950/30 border border-rose-800/40 text-xs space-y-1 mt-2">
                            <div className="flex items-center gap-1.5 text-rose-300 font-bold font-mono">
                              <Ban className="w-4 h-4 text-rose-400" />
                              <span>
                                {evt.status === 'confirmed_false'
                                  ? 'REPORT REJECTED — MARKED CONFIRMED FALSE (-25 TRUST PENALTY)'
                                  : 'REPORT REJECTED BY MODERATION'}
                              </span>
                            </div>
                            {evt.rejectionReason && (
                              <p className="text-slate-300 text-xs font-mono">
                                Audit Note: {evt.rejectionReason}
                              </p>
                            )}
                          </div>
                        )}

                        {/* Admin-Only Reporter Info (Privacy Guarantee) */}
                        <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-500/30 text-xs space-y-1 mt-2">
                          <p className="text-purple-300 font-semibold flex items-center gap-1.5">
                            <UserCheck className="w-4 h-4" /> Reporter Identity (Admin Confidential Access):
                          </p>
                          <p className="text-slate-300">
                            Public Pseudonym: <strong className="text-white">{evt.anonymousReporter.pseudonym}</strong> ({evt.anonymousReporter.anonymousId}) • {evt.anonymousReporter.tier} Tier
                          </p>
                          {evt.reporterId && (
                            <p className="text-slate-400 text-[11px] font-mono">
                              Internal Account Ref: {evt.reporterId}
                            </p>
                          )}
                        </div>

                        {/* AI Precheck Assessment Box */}
                        {evt.aiAnalysis && (
                          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1">
                            <div className="flex items-center justify-between text-sky-400 font-mono font-semibold">
                              <span className="flex items-center gap-1">
                                <Sparkles className="w-3.5 h-3.5" /> AI Pre-Check Audit
                              </span>
                              <span>Risk: {evt.aiAnalysis.riskLevel.toUpperCase()}</span>
                            </div>
                            <p className="text-slate-300 text-xs italic">
                              "{evt.aiAnalysis.rawAiAssessment}"
                            </p>
                          </div>
                        )}
                      </div>

                      {/* Right: Moderation Actions */}
                      <div className="flex flex-col gap-2 shrink-0 w-full lg:w-52 pt-2 lg:pt-0">
                        <button
                          onClick={() => onSelectEvent(evt)}
                          className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1 transition-all"
                        >
                          <ExternalLink className="w-3.5 h-3.5" /> Inspect Full Event
                        </button>

                        {evt.status !== 'published' && (
                          <button
                            onClick={() => handleModerate(evt.id, 'approve')}
                            className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md flex items-center justify-center gap-1.5 transition-all"
                          >
                            <CheckCircle2 className="w-4 h-4" /> Approve & Publish
                          </button>
                        )}

                        <button
                          onClick={() => handleToggleHot(evt.id)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border transition-all ${
                            evt.isHotAlert
                              ? 'bg-red-500/20 text-red-300 border-red-500/50'
                              : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border-slate-700'
                          }`}
                        >
                          <Flame className="w-3.5 h-3.5" />
                          {evt.isHotAlert ? 'Demote Hot' : 'Set Hot Alert'}
                        </button>

                        <button
                          onClick={() => handleModerate(evt.id, 'reject')}
                          className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 flex items-center justify-center gap-1.5 transition-all"
                        >
                          <Ban className="w-3.5 h-3.5 text-amber-400" /> Reject
                        </button>

                        <button
                          onClick={() => handleModerate(evt.id, 'mark_false', 'Investigative audit found fabricated information.')}
                          className="px-3 py-1.5 rounded-xl bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 text-xs font-bold border border-rose-700/60 flex items-center justify-center gap-1.5 transition-all"
                          title="Mark this report as false, set status to rejected, and deduct 25 trust score"
                        >
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-400" /> Mark False & Reject (-25)
                        </button>

                        <button
                          onClick={() => handleDelete(evt.id)}
                          className="px-3 py-1.5 rounded-xl bg-red-950/70 hover:bg-red-900/90 text-red-300 text-xs font-bold border border-red-700/70 flex items-center justify-center gap-1.5 transition-all ml-auto"
                          title="Permanently remove report from registry"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-red-400" /> Delete
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: FIELD REPORTER DIRECTORY & TRUST SCORES */}
      {adminTab === 'reporters' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 space-y-1">
            <p className="font-semibold text-white">Reporter Trust Scoring Logic:</p>
            <p>
              • <strong>+10 Trust Score</strong> awarded automatically for every 3 approved, verified field reports.
            </p>
            <p>
              • <strong>-25 Trust Score</strong> penalty deducted for any report confirmed false or fabricated (Min 0, Max 200).
            </p>
            <p>
              • <strong>Tiers:</strong> Rookie (0 - 50) • Veteran (51 - 170) • Virtuoso (171 - 200).
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {reporters.map((rep) => {
              const tier = rep.profile?.tier || 'Rookie';
              const tierMeta = getTrustTierBadge(tier);
              const score = rep.profile?.trustScore || 0;

              return (
                <div
                  key={rep.id}
                  className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-lg space-y-3"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="text-sm font-bold text-white">
                        {rep.codeName || rep.profile?.pseudonym || rep.realName}
                      </h4>
                      <p className="text-xs text-amber-400 font-mono font-medium">
                        {rep.designation || 'Field Reporter'}
                      </p>
                      <p className="text-xs text-slate-400 flex items-center gap-1 font-mono mt-0.5">
                        <Mail className="w-3 h-3 text-slate-500" /> {rep.realEmail}
                      </p>
                    </div>
                    <span className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded border ${tierMeta.className}`}>
                      {tier}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2 text-xs">
                    <div className="flex justify-between items-center text-slate-300">
                      <span>Public Pseudonym:</span>
                      <span className="font-mono font-bold text-sky-400">{rep.profile?.pseudonym}</span>
                    </div>
                    <div className="flex justify-between items-center text-slate-300">
                      <span>Anonymous ID:</span>
                      <span className="font-mono text-slate-400">{rep.profile?.anonymousId}</span>
                    </div>
                    <div className="flex justify-between items-center pt-1 border-t border-slate-800">
                      <span className="font-semibold text-slate-200">Trust Score (0-200):</span>
                      <span className="font-mono font-bold text-base text-purple-300">{score} / 200</span>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className="bg-purple-500 h-full transition-all duration-500"
                        style={{ width: `${Math.min(100, (score / 200) * 100)}%` }}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono">
                    <div className="p-2 rounded-lg bg-slate-800/60 border border-slate-700/50">
                      <span className="text-slate-400 text-[10px]">Submitted</span>
                      <p className="font-bold text-white">{rep.profile?.totalSubmitted || 0}</p>
                    </div>
                    <div className="p-2 rounded-lg bg-emerald-950/40 border border-emerald-700/40">
                      <span className="text-emerald-400 text-[10px]">Approved</span>
                      <p className="font-bold text-emerald-300">{rep.profile?.approvedReportsCount || 0}</p>
                    </div>
                    <div className="p-2 rounded-lg bg-rose-950/40 border border-rose-700/40">
                      <span className="text-rose-400 text-[10px]">Rejected (False)</span>
                      <p className="font-bold text-rose-300">
                        {rep.profile?.rejectedReportsCount || 0}
                        {rep.profile?.falseReportsCount ? ` (${rep.profile.falseReportsCount} false)` : ''}
                      </p>
                    </div>
                  </div>

                  {rep.scoreHistories && rep.scoreHistories.length > 0 && (
                    <div className="pt-2 border-t border-slate-800 text-[11px] space-y-1">
                      <p className="text-slate-400 font-mono font-semibold">Latest Trust Audit Event:</p>
                      <p className="text-slate-300 text-[10px] leading-relaxed">
                        {rep.scoreHistories[0].reason} ({rep.scoreHistories[0].changeAmount > 0 ? `+${rep.scoreHistories[0].changeAmount}` : rep.scoreHistories[0].changeAmount})
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: SYSTEM AUDIT LOG */}
      {adminTab === 'audit' && (
        <div className="space-y-3">
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs font-mono text-slate-300">
            System actions, moderation approvals, trust awards, and penalty events are immutably logged for oversight.
          </div>

          <div className="space-y-2">
            {auditLogs.map((log) => (
              <div
                key={log.id}
                className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-purple-300 uppercase px-2 py-0.5 rounded bg-purple-950 border border-purple-700/60 text-[10px]">
                      {log.action}
                    </span>
                    <span className="text-slate-400 text-[11px] font-mono">
                      By {log.actorName || log.actorRole}
                    </span>
                    {log.scoreChange !== undefined && (
                      <span
                        className={`font-mono font-bold text-[10px] px-1.5 py-0.2 rounded ${
                          log.scoreChange > 0
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-rose-500/20 text-rose-300'
                        }`}
                      >
                        {log.scoreChange > 0 ? `+${log.scoreChange}` : log.scoreChange} TRUST
                      </span>
                    )}
                  </div>
                  <p className="text-slate-300 font-sans">{log.reason}</p>
                </div>

                <span className="text-[11px] font-mono text-slate-500 shrink-0">
                  {new Date(log.timestamp).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
