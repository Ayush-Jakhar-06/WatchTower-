import React, { useState } from 'react';
import {
  Search,
  Flame,
  Radio,
  PlusCircle,
  ShieldCheck,
  User as UserIcon,
  ChevronDown,
  Navigation,
  Compass,
  AlertOctagon,
  Activity,
  Lock,
  Globe,
  TrendingUp,
  Target,
  Sparkles,
  Volume2,
  VolumeX,
  Monitor,
  Tablet,
  Smartphone,
  PanelLeft,
  PanelRight,
  Maximize2,
  LogOut,
} from 'lucide-react';
import { User, GlobalEvent, UserRole } from '../types.js';
import { LIVE_TICKER_ITEMS } from '../data/predictionsAndMarkets.js';

interface HeaderProps {
  currentUser: User | null;
  onSwitchUser?: (user: User | null) => void;
  onOpenAuthModal: () => void;
  onOpenProfilePanel?: () => void;
  onSignOut?: () => void;
  activeTab: 'globe' | 'feed' | 'radar' | 'predictions' | 'admin';
  setActiveTab: (tab: 'globe' | 'feed' | 'radar' | 'predictions' | 'admin') => void;
  onOpenSubmitModal: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  hotEvents: GlobalEvent[];
  onSelectEvent: (event: GlobalEvent) => void;
  soundEnabled?: boolean;
  onToggleSound?: () => void;
  resolutionPreset?: 'auto' | '1440' | '768' | '390';
  onChangeResolutionPreset?: (preset: 'auto' | '1440' | '768' | '390') => void;
  leftPanelCollapsed?: boolean;
  rightPanelCollapsed?: boolean;
  onToggleLeftPanel?: () => void;
  onToggleRightPanel?: () => void;
}

export const PRESET_USERS: { label: string; role: UserRole; user: User | null; description: string }[] = [
  {
    label: 'Guest Access',
    role: 'guest',
    user: null,
    description: 'Explore public 3D globe & verified events',
  },
  {
    label: 'Observer_44 (Community User)',
    role: 'user',
    user: {
      id: 'user-normal-1',
      name: 'Observer_44',
      codeName: 'Observer_44',
      designation: 'Community User',
      email: 'observer44@watchtower.io',
      role: 'user',
      createdAt: '2026-02-12T11:00:00.000Z',
    },
    description: 'Can vote on trust scores & view nearby radar',
  },
  {
    label: 'EchoHawk_92 (Rookie Reporter)',
    role: 'field-reporter',
    user: {
      id: 'user-reporter-1',
      name: 'EchoHawk_92',
      codeName: 'EchoHawk_92',
      designation: 'Rookie Reporter',
      email: 'echohawk@watchtower.org',
      role: 'field-reporter',
      createdAt: '2026-02-01T10:30:00.000Z',
      reporterProfile: {
        anonymousId: 'REP-7429',
        pseudonym: 'EchoHawk_92',
        trustScore: 40,
        tier: 'Rookie',
        approvedReportsCount: 2,
        falseReportsCount: 0,
        totalSubmitted: 3,
        joinedDate: '2026-02-01T10:30:00.000Z',
      },
    },
    description: 'Trust Score 40 (Rookie) • Submits structured reports',
  },
  {
    label: 'VigilantOasis (Veteran Reporter)',
    role: 'field-reporter',
    user: {
      id: 'user-reporter-2',
      name: 'VigilantOasis',
      codeName: 'VigilantOasis',
      designation: 'Veteran Reporter',
      email: 'vigilantoasis@watchtower.org',
      role: 'field-reporter',
      createdAt: '2026-01-15T14:20:00.000Z',
      reporterProfile: {
        anonymousId: 'REP-3104',
        pseudonym: 'VigilantOasis',
        trustScore: 120,
        tier: 'Veteran',
        approvedReportsCount: 12,
        falseReportsCount: 0,
        totalSubmitted: 14,
        joinedDate: '2026-01-15T14:20:00.000Z',
      },
    },
    description: 'Trust Score 120 (Veteran) • 12 approved reports',
  },
  {
    label: 'GeoSentinel (Virtuoso Reporter)',
    role: 'field-reporter',
    user: {
      id: 'user-reporter-3',
      name: 'GeoSentinel',
      codeName: 'GeoSentinel',
      designation: 'Virtuoso Reporter',
      email: 'geosentinel@fieldnet.io',
      role: 'field-reporter',
      createdAt: '2025-11-20T09:15:00.000Z',
      reporterProfile: {
        anonymousId: 'REP-9901',
        pseudonym: 'GeoSentinel',
        trustScore: 185,
        tier: 'Virtuoso',
        approvedReportsCount: 24,
        falseReportsCount: 1,
        totalSubmitted: 26,
        joinedDate: '2025-11-20T09:15:00.000Z',
      },
    },
    description: 'Trust Score 185 (Virtuoso) • Fast-track reporting',
  },
  {
    label: 'Command_Lead (Chief Director)',
    role: 'admin',
    user: {
      id: 'user-admin-ayush',
      name: 'Command_Lead',
      codeName: 'Command_Lead',
      designation: 'Chief Director',
      email: 'Ayush@gmail.com',
      role: 'admin',
      createdAt: '2026-01-01T08:00:00.000Z',
    },
    description: 'Full moderation, reporter identities & penalty audit',
  },
];

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onSwitchUser,
  onOpenAuthModal,
  onOpenProfilePanel,
  onSignOut,
  activeTab,
  setActiveTab,
  onOpenSubmitModal,
  searchQuery,
  setSearchQuery,
  hotEvents,
  onSelectEvent,
  soundEnabled = true,
  onToggleSound,
  resolutionPreset = 'auto',
  onChangeResolutionPreset,
  leftPanelCollapsed = false,
  rightPanelCollapsed = false,
  onToggleLeftPanel,
  onToggleRightPanel,
}) => {
  // Combine hot events with live ticker items for real-time scrolling from right to left
  const tickerItems = React.useMemo(() => {
    const fromEvents = (hotEvents || []).slice(0, 5).map((evt) => ({
      id: evt.id,
      flag: evt.location.country === 'India' ? '🇮🇳' : evt.location.country === 'United States' ? '🇺🇸' : '🌍',
      text: `${evt.location.city}: ${evt.title}`,
      timeAgo: 'Live',
      isUrgent: evt.isHotAlert || evt.severity === 'critical',
      eventRef: evt,
    }));
    return [...fromEvents, ...LIVE_TICKER_ITEMS];
  }, [hotEvents]);

  return (
    <header className="sticky top-0 z-40 w-full bg-[#090b0e] border-b border-[#1b1e27] shadow-2xl select-none">
      {/* Top LATEST News Marquee Bar (Horizontal Auto-Scrolling Right to Left) */}
      <div className="bg-[#050608] border-b border-[#171a23] h-7 px-3 flex items-center gap-3 text-xs overflow-hidden">
        {/* Red LATEST Badge */}
        <div className="flex items-center gap-1.5 px-2.5 py-0.5 bg-[#e52e2e] text-white font-mono font-black text-[10px] tracking-wider uppercase shrink-0 rounded-none shadow-sm z-10">
          <Flame className="w-3 h-3 text-white fill-white animate-pulse" />
          LATEST
        </div>

        {/* Continuous Horizontal Auto-Scrolling Moving Ticker from Right to Left */}
        <div className="overflow-hidden flex-1 relative">
          <div className="ticker-marquee-track flex items-center gap-6 py-0.5 text-[11px] font-mono whitespace-nowrap">
            {[...tickerItems, ...tickerItems].map((item, idx) => (
              <div
                key={`${item.id}-${idx}`}
                onClick={() => {
                  if (item.eventRef && onSelectEvent) {
                    onSelectEvent(item.eventRef);
                  }
                }}
                className={`flex items-center gap-2 text-slate-300 shrink-0 ${
                  item.eventRef ? 'cursor-pointer hover:text-amber-300 transition-colors' : ''
                }`}
              >
                {item.flag && <span>{item.flag}</span>}
                <span className={`font-semibold ${item.isUrgent ? 'text-[#ff4d4d]' : 'text-slate-200'}`}>
                  {item.text}
                </span>
                <span className="text-slate-400 text-[10px]">{item.timeAgo}</span>
                <span className="text-slate-600">•</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Command Center Header Bar */}
      <div className="px-4 py-2 flex items-center justify-between gap-3">
        {/* Left Brand: Radar Icon + WATCHTOWER */}
        <div className="flex items-center gap-3 shrink-0">
          <div
            onClick={() => setActiveTab('globe')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            {/* Custom Glowing Radar Icon */}
            <div className="relative w-8 h-8 rounded-full bg-red-950/70 border border-red-600/80 flex items-center justify-center shadow-[0_0_15px_rgba(239,68,68,0.35)] group-hover:scale-105 transition-all">
              <div className="absolute inset-0 rounded-full border border-red-500/40 animate-ping opacity-75" />
              <Activity className="w-4 h-4 text-red-500 animate-pulse" />
            </div>

            <div className="flex flex-col">
              <span className="text-lg font-black tracking-widest text-white uppercase font-sans">
                WATCH<span className="text-red-500">TOWER</span>
              </span>
            </div>
          </div>

          {/* Quick Panel Toggle Buttons */}
          {activeTab === 'globe' && (
            <div className="hidden sm:flex items-center gap-1 bg-[#13161f] border border-[#222735] p-0.5 rounded-md">
              {onToggleLeftPanel && (
                <button
                  onClick={onToggleLeftPanel}
                  title={leftPanelCollapsed ? "Expand Intel Feed" : "Collapse Intel Feed"}
                  className={`p-1.5 rounded transition-all text-xs flex items-center gap-1 ${
                    !leftPanelCollapsed
                      ? 'bg-red-500/20 text-red-300 border border-red-500/40'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <PanelLeft className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-mono font-semibold hidden md:inline">INTEL</span>
                </button>
              )}
              {onToggleRightPanel && (
                <button
                  onClick={onToggleRightPanel}
                  title={rightPanelCollapsed ? "Expand Markets Panel" : "Collapse Markets Panel"}
                  className={`p-1.5 rounded transition-all text-xs flex items-center gap-1 ${
                    !rightPanelCollapsed
                      ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span className="text-[10px] font-mono font-semibold hidden md:inline">MARKETS</span>
                  <PanelRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* Center / Navigation Links + Resolution Switcher */}
        <div className="flex items-center gap-2 font-mono text-xs">
          <div className="hidden md:flex items-center gap-1">
            <button
              onClick={() => setActiveTab('globe')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded transition-all ${
                activeTab === 'globe'
                  ? 'bg-[#181b24] text-white border border-[#2a3040] shadow-md font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#12151d]'
              }`}
            >
              <Globe className="w-3.5 h-3.5 text-sky-400" />
              <span>LIVE 3D</span>
            </button>

            <button
              onClick={() => setActiveTab('predictions')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded transition-all ${
                activeTab === 'predictions'
                  ? 'bg-[#181b24] text-white border border-[#2a3040] shadow-md font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#12151d]'
              }`}
            >
              <Target className="w-3.5 h-3.5 text-red-400" />
              <span>PREDICTIONS</span>
            </button>

            <button
              onClick={() => setActiveTab('radar')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded transition-all ${
                activeTab === 'radar'
                  ? 'bg-[#181b24] text-white border border-[#2a3040] shadow-md font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#12151d]'
              }`}
            >
              <Compass className="w-3.5 h-3.5 text-amber-400" />
              <span>RADAR</span>
            </button>

            {currentUser?.role === 'admin' && (
              <button
                onClick={() => setActiveTab('admin')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded transition-all ${
                  activeTab === 'admin'
                    ? 'bg-red-950/60 text-red-300 border border-red-700/80 shadow-md font-bold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#12151d]'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5 text-red-400" />
                <span>ADMIN</span>
              </button>
            )}
          </div>

          {/* Device Resolution Mode Selector Preset (1440px / 768px / 390px / Auto) */}
          {onChangeResolutionPreset && (
            <div className="hidden lg:flex items-center gap-1 bg-[#101218] border border-[#222735] px-1.5 py-1 rounded-md text-[10px]">
              <span className="text-slate-400 font-mono mr-1">RES:</span>
              <button
                onClick={() => onChangeResolutionPreset('auto')}
                className={`px-1.5 py-0.5 rounded transition-all flex items-center gap-1 ${
                  resolutionPreset === 'auto'
                    ? 'bg-red-600 text-white font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Device Native Auto"
              >
                AUTO
              </button>
              <button
                onClick={() => onChangeResolutionPreset('1440')}
                className={`px-1.5 py-0.5 rounded transition-all flex items-center gap-1 ${
                  resolutionPreset === '1440'
                    ? 'bg-sky-600 text-white font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Standard 1440px Desktop"
              >
                <Monitor className="w-3 h-3" />
                1440
              </button>
              <button
                onClick={() => onChangeResolutionPreset('768')}
                className={`px-1.5 py-0.5 rounded transition-all flex items-center gap-1 ${
                  resolutionPreset === '768'
                    ? 'bg-sky-600 text-white font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Standard 768px Tablet"
              >
                <Tablet className="w-3 h-3" />
                768
              </button>
              <button
                onClick={() => onChangeResolutionPreset('390')}
                className={`px-1.5 py-0.5 rounded transition-all flex items-center gap-1 ${
                  resolutionPreset === '390'
                    ? 'bg-sky-600 text-white font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Standard 360-390px Mobile"
              >
                <Smartphone className="w-3 h-3" />
                390
              </button>
            </div>
          )}
        </div>

        {/* Right Actions: Submit Dispatch, Profile Panel / Sign In, Sign Out */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Submit Report / Dispatch Button */}
          <button
            id="btn-header-dispatch-report"
            onClick={onOpenSubmitModal}
            title="Dispatch breaking field report"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-black font-mono font-bold text-xs shadow-lg transition-all"
          >
            <PlusCircle className="w-3.5 h-3.5 text-black" />
            <span className="hidden sm:inline">DISPATCH REPORT</span>
            <span className="sm:hidden">SUBMIT</span>
          </button>

          {/* User Account / Profile Panel Trigger or Guest Sign In */}
          {!currentUser ? (
            <div className="flex items-center gap-2">
              <span className="hidden xl:inline text-[10px] font-mono px-2 py-1 rounded bg-[#10141d] text-slate-400 border border-[#1e2535]">
                GUEST (VIEW ONLY)
              </span>

              <button
                onClick={onOpenAuthModal}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#161a24] hover:bg-[#202634] border border-[#2b3347] text-slate-200 hover:text-white text-xs font-mono font-semibold transition-all"
              >
                <UserIcon className="w-3.5 h-3.5 text-amber-400" />
                <span>SIGN IN / SIGN-UP</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-1.5">
              {/* Clickable Profile Trigger (Opens User / Reporter Dashboard) */}
              <button
                id="btn-user-profile-dossier"
                onClick={onOpenProfilePanel}
                title="Click to open your Field Reporter / User Dashboard"
                className="flex items-center gap-2 px-3 py-1.5 rounded bg-[#13161f] hover:bg-[#1a1f2b] border border-[#262c3e] hover:border-amber-500/50 text-xs font-mono text-slate-200 transition-all group shadow-sm"
              >
                {currentUser.role === 'admin' ? (
                  <ShieldCheck className="w-3.5 h-3.5 text-red-400" />
                ) : currentUser.role === 'field-reporter' ? (
                  <Radio className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                ) : (
                  <UserIcon className="w-3.5 h-3.5 text-sky-400" />
                )}

                <span className="font-semibold text-white group-hover:text-amber-300 transition-colors max-w-[130px] sm:max-w-[180px] truncate">
                  {currentUser.codeName || currentUser.reporterProfile?.pseudonym || currentUser.name}
                </span>

                <span
                  className={`text-[9px] font-mono font-bold px-1.5 py-0.2 rounded uppercase ${
                    currentUser.role === 'admin'
                      ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                      : currentUser.role === 'field-reporter'
                      ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      : 'bg-sky-500/20 text-sky-400 border border-sky-500/30'
                  }`}
                >
                  {currentUser.designation || (currentUser.role === 'admin'
                    ? 'CHIEF DIRECTOR'
                    : currentUser.role === 'field-reporter'
                    ? `${currentUser.reporterProfile?.tier || 'ROOKIE'}: ${currentUser.reporterProfile?.trustScore || 0}`
                    : 'OBSERVER')}
                </span>

                <span className="hidden sm:inline-block text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30 group-hover:bg-amber-500/20 transition-all">
                  DASHBOARD
                </span>
              </button>
            </div>
          )}

          {/* Activity Pulse Wave Icon */}
          <div className="w-8 h-8 rounded bg-[#13161f] border border-[#222735] flex items-center justify-center text-red-500">
            <Activity className="w-4 h-4 text-red-500" />
          </div>
        </div>
      </div>
    </header>
  );
};
