import React, { useState } from 'react';
import {
  Target,
  TrendingUp,
  ChevronRight,
  ExternalLink,
  DollarSign,
  Vote,
  Sparkles,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  Shield,
  CheckCircle2,
  Maximize2,
  Minimize2,
  PanelRightClose,
} from 'lucide-react';
import { PredictionMarketItem, MarketAsset, User } from '../types.js';
import { INITIAL_PREDICTIONS, INITIAL_MARKETS } from '../data/predictionsAndMarkets.js';

interface PredictionsAndMarketsPanelProps {
  currentUser?: User | null;
  onOpenAuthModal?: () => void;
  onSelectCountry?: (countryCode: string) => void;
  panelState?: 'standard' | 'expanded' | 'collapsed';
  onToggleExpand?: () => void;
  onCollapse?: () => void;
}

export const PredictionsAndMarketsPanel: React.FC<PredictionsAndMarketsPanelProps> = ({
  currentUser,
  onOpenAuthModal,
  onSelectCountry,
  panelState = 'standard',
  onToggleExpand,
  onCollapse,
}) => {
  const [predictions, setPredictions] = useState<PredictionMarketItem[]>(INITIAL_PREDICTIONS);
  const [votedItems, setVotedItems] = useState<{ [id: string]: 'yes' | 'no' }>({});
  const [activeMarketTab, setActiveMarketTab] = useState<'all' | 'defense' | 'commodities'>('all');

  const handleVote = (id: string, choice: 'yes' | 'no') => {
    if (!currentUser) {
      if (onOpenAuthModal) {
        onOpenAuthModal();
      }
      return;
    }

    if (votedItems[id]) return;

    setPredictions((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        const total = item.totalVotes + 1;
        let newYes = item.yesPercentage;
        if (choice === 'yes') {
          newYes = Math.round(((item.yesPercentage * item.totalVotes) / 100 + 1) / total * 1000) / 10;
        } else {
          newYes = Math.round(((item.yesPercentage * item.totalVotes) / 100) / total * 1000) / 10;
        }
        return {
          ...item,
          totalVotes: total,
          yesPercentage: newYes,
          noPercentage: Math.round((100 - newYes) * 10) / 10,
        };
      })
    );

    setVotedItems((prev) => ({ ...prev, [id]: choice }));
  };

  const filteredMarkets = INITIAL_MARKETS.filter((m) => {
    if (activeMarketTab === 'defense') return m.type === 'defense_stock';
    if (activeMarketTab === 'commodities') return m.type === 'commodity';
    return true;
  });

  return (
    <div className="w-full h-full flex flex-col bg-[#0b0d12] border-l border-[#1a1d26] text-slate-200 select-none overflow-hidden font-mono">
      {/* Top Header Bar */}
      <div className="px-3.5 py-2.5 bg-[#08090d] border-b border-[#171922] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Target className="w-4 h-4 text-red-500" />
          <span className="font-bold text-xs tracking-wider text-white uppercase font-mono truncate">
            MARKETS & PREDICTIONS
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setActiveMarketTab(activeMarketTab === 'all' ? 'defense' : 'all')}
            className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#131620] border border-[#222736] text-[10px] text-slate-300 hover:text-white transition-colors"
          >
            <span>{activeMarketTab === 'all' ? 'ALL' : activeMarketTab.toUpperCase()}</span>
            <ChevronRight className="w-2.5 h-2.5 text-red-400" />
          </button>

          {/* Expand / Restore Width Toggle */}
          {onToggleExpand && (
            <button
              onClick={onToggleExpand}
              className={`p-1.5 rounded border transition-colors ${
                panelState === 'expanded'
                  ? 'bg-sky-950/60 text-sky-300 border-sky-700/60'
                  : 'bg-[#151822] text-slate-400 hover:text-white border-[#262b3a]'
              }`}
              title={panelState === 'expanded' ? 'Reduce to standard width' : 'Expand panel width'}
            >
              {panelState === 'expanded' ? (
                <Minimize2 className="w-3.5 h-3.5" />
              ) : (
                <Maximize2 className="w-3.5 h-3.5" />
              )}
            </button>
          )}

          {/* Collapse Panel Button */}
          {onCollapse && (
            <button
              onClick={onCollapse}
              className="p-1.5 rounded bg-[#151822] border border-[#262b3a] text-slate-400 hover:text-red-400 hover:border-red-800/60 transition-colors"
              title="Collapse Markets (Give Globe More Space)"
            >
              <PanelRightClose className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Scrollable Container */}
      <div className="flex-1 overflow-y-auto p-3 space-y-4 no-scrollbar text-xs">
        {/* Active Geopolitical Predictions */}
        <div className="space-y-3">
          {predictions.map((pred) => (
            <div
              key={pred.id}
              className="p-3 rounded-md bg-[#0f1118] border border-[#1e222e] hover:border-[#2f3647] transition-all space-y-2.5 shadow-md"
            >
              {/* Category & Votes Header */}
              <div className="flex items-center justify-between text-[10px] text-slate-400">
                <div className="flex items-center gap-2">
                  <span className="px-1.5 py-0.5 rounded bg-red-950/60 border border-red-800 text-red-400 font-bold">
                    {pred.category}
                  </span>
                  <span>{pred.totalVotes} votes</span>
                </div>
                <span className="text-slate-400 font-semibold">{pred.closingDateText}</span>
              </div>

              {/* Title */}
              <h4 className="text-xs font-semibold text-slate-100 leading-snug">
                {pred.title}
              </h4>

              {/* Conflictly Probability Bar */}
              <div className="space-y-1">
                <div className="h-3.5 w-full bg-[#161922] rounded-none overflow-hidden flex border border-[#252a39]">
                  {/* Yes portion (Red / Coral) */}
                  <div
                    style={{ width: `${pred.yesPercentage}%` }}
                    className="h-full bg-gradient-to-r from-red-600 to-red-500 transition-all duration-500 flex items-center px-1"
                  />
                  {/* No portion (Dark Slate) */}
                  <div
                    style={{ width: `${pred.noPercentage}%` }}
                    className="h-full bg-[#1b202c] transition-all duration-500"
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] font-bold">
                  <span className="text-red-400">{pred.yesPercentage}% YES</span>
                  <span className="text-slate-400">{pred.noPercentage}% NO</span>
                </div>
              </div>

              {/* Interactive Quick Vote Buttons */}
              <div className="flex items-center gap-2 pt-1 border-t border-[#171923]">
                <button
                  disabled={!!votedItems[pred.id]}
                  onClick={() => handleVote(pred.id, 'yes')}
                  className={`flex-1 py-1 px-2 rounded text-[10px] font-bold transition-all flex items-center justify-center gap-1 ${
                    votedItems[pred.id] === 'yes'
                      ? 'bg-red-600 text-white'
                      : 'bg-red-950/40 hover:bg-red-900/60 text-red-300 border border-red-800/60'
                  }`}
                >
                  {votedItems[pred.id] === 'yes' && <CheckCircle2 className="w-3 h-3" />}
                  VOTE YES
                </button>

                <button
                  disabled={!!votedItems[pred.id]}
                  onClick={() => handleVote(pred.id, 'no')}
                  className={`flex-1 py-1 px-2 rounded text-[10px] font-bold transition-all flex items-center justify-center gap-1 ${
                    votedItems[pred.id] === 'no'
                      ? 'bg-slate-700 text-white'
                      : 'bg-[#141720] hover:bg-[#1c202d] text-slate-300 border border-[#252b3b]'
                  }`}
                >
                  {votedItems[pred.id] === 'no' && <CheckCircle2 className="w-3 h-3" />}
                  VOTE NO
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Defense Stocks Section Header (Matching Screenshot) */}
        <div className="pt-2">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300 uppercase">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              <span>DEFENSE ASSETS & MARKETS</span>
            </div>
            <span className="text-[10px] text-slate-400">REALTIME</span>
          </div>

          {/* Defense Assets List */}
          <div className="space-y-1.5">
            {filteredMarkets.map((asset) => (
              <div
                key={asset.symbol}
                className="px-3 py-2 rounded bg-[#0f1118] border border-[#1b1f2b] hover:border-[#2b3245] flex items-center justify-between transition-all group"
              >
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white text-[11px] group-hover:text-red-400 transition-colors">
                    {asset.name}
                  </span>
                  <span className="px-1 py-0.2 rounded bg-[#161a24] text-[9px] text-slate-400 border border-[#252b3a]">
                    {asset.region}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <span className="font-bold text-slate-200 text-[11px]">
                    {asset.currency}
                    {asset.price}
                  </span>
                  <span
                    className={`text-[10px] font-bold flex items-center ${
                      asset.changePercent >= 0 ? 'text-emerald-400' : 'text-red-400'
                    }`}
                  >
                    {asset.changePercent >= 0 ? '+' : ''}
                    {asset.changePercent}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
