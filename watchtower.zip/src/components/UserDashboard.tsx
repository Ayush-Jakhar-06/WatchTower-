import React, { useState, useEffect } from 'react';
import {
  X,
  ShieldCheck,
  ShieldAlert,
  Award,
  TrendingUp,
  ThumbsUp,
  ThumbsDown,
  CheckCircle2,
  AlertTriangle,
  Clock,
  MapPin,
  FileText,
  PlusCircle,
  LogOut,
  Radio,
  ChevronRight,
  BarChart3,
  Globe2,
  ExternalLink,
  Info,
} from 'lucide-react';
import { User, GlobalEvent } from '../types.js';
import { getCategoryMeta, getTrustTierBadge } from '../utils/categories.js';
import { TrustScoreGauge } from './TrustScoreGauge.js';

interface UserDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  events: GlobalEvent[];
  onSelectEvent?: (event: GlobalEvent) => void;
  onOpenSubmitModal?: () => void;
  onSignOut: () => void;
  onOpenAuthModal?: () => void;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  isOpen,
  onClose,
  currentUser,
  events,
  onSelectEvent,
  onOpenSubmitModal,
  onSignOut,
  onOpenAuthModal,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'approved' | 'rejected' | 'pending' | 'all'>('approved');
  const [remoteReports, setRemoteReports] = useState<GlobalEvent[] | null>(null);
  const [loadingReports, setLoadingReports] = useState(false);

  // Fetch author reports from dedicated API endpoint on open
  useEffect(() => {
    if (isOpen && currentUser) {
      setLoadingReports(true);
      fetch('/api/reporter/my-reports', {
        headers: {
          Authorization: `Bearer ${currentUser.id}`,
        },
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.success && Array.isArray(data.events)) {
            setRemoteReports(data.events);
          }
        })
        .catch((err) => {
          console.warn('Could not fetch remote reports:', err);
        })
        .finally(() => {
          setLoadingReports(false);
        });
    }
  }, [isOpen, currentUser]);

  if (!isOpen || !currentUser) return null;

  const profile = currentUser.reporterProfile;
  const isReporter = currentUser.role === 'field-reporter';
  const isAdmin = currentUser.role === 'admin';

  // Merge reports from remote endpoint and events props
  const userEvents: GlobalEvent[] = remoteReports !== null
    ? remoteReports
    : events.filter((e) => e.reporterId === currentUser.id);

  // Separate approved, rejected, and pending reports
  const approvedReports = userEvents.filter(
    (e) => e.status === 'published' || (e.status as string) === 'approved'
  );
  const rejectedReports = userEvents.filter(
    (e) => e.status === 'rejected' || e.status === 'confirmed_false'
  );
  const pendingReports = userEvents.filter(
    (e) => e.status === 'ai_checked' || e.status === 'under_review' || e.status === 'submitted'
  );

  // Trust score: starts at 0 for all new registering / sign-in users/reporters
  const trustScore = profile ? profile.trustScore : isAdmin ? 200 : 0;
  const tier = profile ? profile.tier : isAdmin ? 'Virtuoso' : 'Rookie';
  const tierInfo = getTrustTierBadge(tier);

  // Progress toward next tier calculation
  let nextTierName = 'Veteran';
  let nextTierScore = 51;
  let remainingPoints = Math.max(0, 51 - trustScore);

  if (trustScore <= 50) {
    nextTierName = 'Veteran';
    nextTierScore = 51;
    remainingPoints = Math.max(0, 51 - trustScore);
  } else if (trustScore <= 170) {
    nextTierName = 'Virtuoso';
    nextTierScore = 171;
    remainingPoints = Math.max(0, 171 - trustScore);
  } else {
    nextTierName = 'Maximum Clearance';
    nextTierScore = 200;
    remainingPoints = 0;
  }

  // Filtered reports according to active tab
  const displayedReports = (() => {
    switch (activeSubTab) {
      case 'approved':
        return approvedReports;
      case 'rejected':
        return rejectedReports;
      case 'pending':
        return pendingReports;
      case 'all':
      default:
        return userEvents;
    }
  })();

  const totalUpvotes = userEvents.reduce((acc, e) => acc + (e.trustMetrics?.upvotes || 0), 0);
  const totalDownvotes = userEvents.reduce((acc, e) => acc + (e.trustMetrics?.downvotes || 0), 0);

  return (
    <div
      id="user-dashboard-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
    >
      <div
        id="user-dashboard-modal"
        className="relative w-full max-w-4xl bg-[#090c12] border border-[#1f2638] rounded-2xl shadow-2xl overflow-hidden my-auto text-slate-100 max-h-[94vh] flex flex-col font-sans"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header Bar */}
        <div className="px-6 py-4 border-b border-[#181f2f] bg-[#06080d] flex items-center justify-between sticky top-0 z-20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-red-600 flex items-center justify-center text-white font-mono font-bold shadow-lg shadow-amber-950/40 border border-amber-500/40">
              {isAdmin ? 'ADM' : isReporter ? 'REP' : 'USR'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-wide">
                  {currentUser.codeName || profile?.pseudonym || currentUser.name}
                </h2>
                <span
                  className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border uppercase tracking-wider ${
                    isAdmin
                      ? 'bg-red-500/20 text-red-400 border-red-500/40'
                      : isReporter
                      ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                      : 'bg-sky-500/20 text-sky-400 border-sky-500/40'
                  }`}
                >
                  {currentUser.designation || (isAdmin ? 'CHIEF DIRECTOR' : isReporter ? 'FIELD REPORTER' : 'COMMUNITY OBSERVER')}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono">
                Operator ID: <span className="text-slate-200 font-semibold">{profile ? profile.anonymousId : currentUser.id.slice(0, 12)}</span> • Field Dossier & Intelligence Dashboard
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onOpenSubmitModal && (
              <button
                onClick={() => {
                  onClose();
                  onOpenSubmitModal();
                }}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-lg text-xs font-mono font-semibold transition-all shadow-sm"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>Dispatch Intel</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-[#141824] hover:bg-[#1d2334] text-slate-400 hover:text-white transition-all border border-[#232b3d]"
              title="Close Dashboard"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Dashboard Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6 flex-1">
          {/* SECTION 1: TRUST SCORE GAUGE CHART & TIER STATUS */}
          <div className="p-5 rounded-2xl bg-[#0d111a] border border-[#1d2436] shadow-lg relative overflow-hidden">
            <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
              {/* Left Column: Gauge Chart */}
              <div className="flex flex-col items-center justify-center p-2">
                <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-slate-300 uppercase mb-1">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>OPERATOR TRUST SCORE GAUGE</span>
                </div>
                <TrustScoreGauge score={trustScore} tier={tier} />
              </div>

              {/* Right Column: Score Breakdown & Rules */}
              <div className="flex-1 w-full space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#1b2234] pb-3">
                  <div>
                    <h3 className="text-sm font-bold text-white font-mono">
                      Credibility Level: <span className="text-amber-400">{tier} Clearance</span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      All new registering and sign-in users start at 0 Trust Score. Earn credibility through corroborated field reporting.
                    </p>
                  </div>

                  {remainingPoints > 0 ? (
                    <div className="text-left sm:text-right font-mono text-xs">
                      <span className="text-slate-400">Next Clearance: </span>
                      <strong className="text-amber-400">{nextTierName}</strong>
                      <div className="text-[11px] text-slate-400">
                        {remainingPoints} points needed
                      </div>
                    </div>
                  ) : (
                    <div className="text-xs font-mono text-emerald-400 font-bold px-2.5 py-1 rounded bg-emerald-950/40 border border-emerald-800/50">
                      MAX TIER REACHED
                    </div>
                  )}
                </div>

                {/* Progress Track */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] font-mono text-slate-400">
                    <span>Rookie (0-50 pts)</span>
                    <span>Veteran (51-170 pts)</span>
                    <span>Virtuoso (171-200 pts)</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-[#151a27] border border-[#222a3d] overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-red-500 via-amber-500 to-emerald-400 transition-all duration-700"
                      style={{ width: `${Math.min(100, Math.max(3, (trustScore / 200) * 100))}%` }}
                    />
                  </div>
                </div>

                {/* Scoring Rules Matrix */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1 text-xs font-mono">
                  <div className="p-2.5 rounded-xl bg-[#070a10] border border-[#182030] flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <div>
                      <div className="font-semibold text-slate-200">+10 Trust Bonus</div>
                      <div className="text-[10px] text-slate-400">Every 3 approved reports</div>
                    </div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#070a10] border border-[#182030] flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                    <div>
                      <div className="font-semibold text-slate-200">-25 False Penalty</div>
                      <div className="text-[10px] text-slate-400">Fabricated intelligence</div>
                    </div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#070a10] border border-[#182030] flex items-center gap-2">
                    <ThumbsUp className="w-4 h-4 text-sky-400 shrink-0" />
                    <div>
                      <div className="font-semibold text-slate-200">Peer Consensus</div>
                      <div className="text-[10px] text-slate-400">Community votes boost reach</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* SECTION 2: HIGH-LEVEL STATS GRID */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {/* Approved Reports Card */}
            <div
              onClick={() => setActiveSubTab('approved')}
              className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                activeSubTab === 'approved'
                  ? 'bg-emerald-950/30 border-emerald-500/60 shadow-lg shadow-emerald-950/30'
                  : 'bg-[#0d111a] hover:bg-[#121824] border-[#1e2638]'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono font-bold text-emerald-400 uppercase">
                  APPROVED
                </span>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-black font-mono text-white mt-1">
                {approvedReports.length}
              </div>
              <p className="text-[10px] text-slate-400 mt-0.5">Verified & active on grid</p>
            </div>

            {/* Rejected Reports Card */}
            <div
              onClick={() => setActiveSubTab('rejected')}
              className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                activeSubTab === 'rejected'
                  ? 'bg-rose-950/30 border-rose-500/60 shadow-lg shadow-rose-950/30'
                  : 'bg-[#0d111a] hover:bg-[#121824] border-[#1e2638]'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono font-bold text-rose-400 uppercase">
                  REJECTED
                </span>
                <AlertTriangle className="w-4 h-4 text-rose-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-black font-mono text-white mt-1">
                {rejectedReports.length}
              </div>
              <p className="text-[10px] text-slate-400 mt-0.5">Unsubstantiated or denied</p>
            </div>

            {/* Pending Reports Card */}
            <div
              onClick={() => setActiveSubTab('pending')}
              className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                activeSubTab === 'pending'
                  ? 'bg-amber-950/30 border-amber-500/60 shadow-lg shadow-amber-950/30'
                  : 'bg-[#0d111a] hover:bg-[#121824] border-[#1e2638]'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono font-bold text-amber-400 uppercase">
                  PENDING REVIEW
                </span>
                <Clock className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-black font-mono text-white mt-1">
                {pendingReports.length}
              </div>
              <p className="text-[10px] text-slate-400 mt-0.5">Under moderation</p>
            </div>

            {/* Total Dispatches Card */}
            <div
              onClick={() => setActiveSubTab('all')}
              className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                activeSubTab === 'all'
                  ? 'bg-sky-950/30 border-sky-500/60 shadow-lg shadow-sky-950/30'
                  : 'bg-[#0d111a] hover:bg-[#121824] border-[#1e2638]'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono font-bold text-sky-400 uppercase">
                  TOTAL SUBMISSIONS
                </span>
                <FileText className="w-4 h-4 text-sky-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-black font-mono text-white mt-1">
                {userEvents.length}
              </div>
              <p className="text-[10px] text-slate-400 mt-0.5">
                +{totalUpvotes} community upvotes
              </p>
            </div>
          </div>

          {/* SECTION 3: TABBED REPORT EXPLORER */}
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#1b2234] pb-3">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-amber-400" />
                <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">
                  FIELD DISPATCH ARCHIVE
                </h3>
              </div>

              {/* Sub Navigation Tabs */}
              <div className="flex items-center gap-1 bg-[#06080d] p-1 rounded-xl border border-[#1b2234] text-xs font-mono">
                <button
                  id="tab-approved-reports"
                  onClick={() => setActiveSubTab('approved')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                    activeSubTab === 'approved'
                      ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Approved ({approvedReports.length})</span>
                </button>

                <button
                  id="tab-rejected-reports"
                  onClick={() => setActiveSubTab('rejected')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                    activeSubTab === 'rejected'
                      ? 'bg-rose-500/20 text-rose-300 font-bold border border-rose-500/40 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                  <span>Rejected ({rejectedReports.length})</span>
                </button>

                <button
                  id="tab-pending-reports"
                  onClick={() => setActiveSubTab('pending')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                    activeSubTab === 'pending'
                      ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>Pending ({pendingReports.length})</span>
                </button>

                <button
                  id="tab-all-reports"
                  onClick={() => setActiveSubTab('all')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                    activeSubTab === 'all'
                      ? 'bg-sky-500/20 text-sky-300 font-bold border border-sky-500/40 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span>All ({userEvents.length})</span>
                </button>
              </div>
            </div>

            {/* Content List */}
            {displayedReports.length === 0 ? (
              <div className="p-8 rounded-2xl bg-[#0a0e16] border border-[#192131] text-center space-y-3">
                {activeSubTab === 'approved' ? (
                  <>
                    <div className="w-12 h-12 rounded-full bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-center mx-auto text-emerald-400">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-semibold text-white">No Approved Reports Yet</h4>
                      <p className="text-xs text-slate-400 max-w-md mx-auto">
                        You have not had any reports approved yet. Submit verified intelligence to gain credibility and increase your Trust Score.
                      </p>
                    </div>
                  </>
                ) : activeSubTab === 'rejected' ? (
                  <>
                    <div className="w-12 h-12 rounded-full bg-emerald-950/30 border border-emerald-500/30 flex items-center justify-center mx-auto text-emerald-400">
                      <ShieldCheck className="w-6 h-6" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-semibold text-emerald-300">Clean Verification Record</h4>
                      <p className="text-xs text-slate-400 max-w-md mx-auto">
                        No rejected or false reports found for this operator account. Keep submitting accurate, corroborated field reports to maintain your record!
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="w-12 h-12 rounded-full bg-[#141a27] flex items-center justify-center mx-auto text-slate-500">
                      <FileText className="w-6 h-6" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-semibold text-slate-300">No Reports in this Section</h4>
                      <p className="text-xs text-slate-400 max-w-md mx-auto">
                        No dispatches found matching the selected filter.
                      </p>
                    </div>
                  </>
                )}

                {onOpenSubmitModal && (
                  <div className="pt-2">
                    <button
                      onClick={() => {
                        onClose();
                        onOpenSubmitModal();
                      }}
                      className="inline-flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-black font-mono font-bold text-xs rounded-xl shadow-lg transition-all"
                    >
                      <PlusCircle className="w-4 h-4 text-black" />
                      <span>Dispatch New Field Report</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-2.5">
                {displayedReports.map((item) => {
                  const meta = getCategoryMeta(item.category);
                  const CategoryIcon = meta.icon;
                  const itemVotes = item.trustMetrics?.upvotes || 0;
                  const itemDevotes = item.trustMetrics?.downvotes || 0;
                  const itemNet = itemVotes - itemDevotes;
                  const isItemRejected = item.status === 'rejected' || item.status === 'confirmed_false';

                  return (
                    <div
                      key={item.id}
                      className={`p-4 rounded-xl border transition-all ${
                        isItemRejected
                          ? 'bg-[#120e14] border-rose-900/40 hover:border-rose-700/60'
                          : 'bg-[#0d111a] hover:bg-[#121824] border-[#1e2638] hover:border-amber-500/40'
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                        <div className="space-y-2 flex-1 min-w-0">
                          {/* Badges Row */}
                          <div className="flex flex-wrap items-center gap-2">
                            <span
                              className={`flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-semibold border ${meta.bgColor} ${meta.color} ${meta.borderColor}`}
                            >
                              <CategoryIcon className="w-3 h-3" />
                              {item.category}
                            </span>

                            {/* Status Badge */}
                            <span
                              className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase font-bold ${
                                item.status === 'published'
                                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                                  : item.status === 'confirmed_false'
                                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                                  : item.status === 'rejected'
                                  ? 'bg-rose-950/40 text-rose-300 border-rose-800/50'
                                  : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                              }`}
                            >
                              {item.status === 'published'
                                ? 'APPROVED & VERIFIED'
                                : item.status === 'confirmed_false'
                                ? 'REJECTED (CONFIRMED FALSE)'
                                : item.status === 'rejected'
                                ? 'REJECTED'
                                : 'PENDING REVIEW'}
                            </span>

                            <span className="text-[10px] font-mono text-slate-400">
                              {new Date(item.eventDate || item.createdAt).toLocaleDateString(undefined, {
                                month: 'short',
                                day: 'numeric',
                                year: 'numeric',
                              })}
                            </span>
                          </div>

                          {/* Title */}
                          <h4 className="text-sm font-bold text-white leading-snug">
                            {item.title}
                          </h4>

                          {/* Location & Sources */}
                          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 font-mono">
                            <div className="flex items-center gap-1 text-slate-300">
                              <MapPin className="w-3.5 h-3.5 text-sky-400" />
                              <span>
                                {item.location.city}, {item.location.country}
                              </span>
                            </div>

                            {item.severity && (
                              <span className="text-[10px] uppercase font-bold text-amber-400">
                                • {item.severity} severity
                              </span>
                            )}
                          </div>

                          {/* Rejection Reason Box (Specially emphasized for rejected reports) */}
                          {isItemRejected && (
                            <div className="p-3 rounded-lg bg-rose-950/30 border border-rose-800/50 text-xs font-mono space-y-1">
                              <div className="flex items-center gap-1.5 text-rose-400 font-bold">
                                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                                <span>REJECTION AUDIT REASON:</span>
                              </div>
                              <p className="text-rose-200/90 text-xs pl-5">
                                {item.rejectionReason || 'Report did not pass corroboration standards or lacked verifiable satellite/ground evidence.'}
                              </p>
                            </div>
                          )}
                        </div>

                        {/* Right Action Column */}
                        <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#192131]">
                          {/* Story Rating */}
                          <div className="px-2.5 py-1 rounded bg-[#06080d] border border-[#1b2234] text-right font-mono text-[11px]">
                            <div className="text-[9px] text-slate-400">RATING</div>
                            <div className="flex items-center gap-1.5">
                              <span className="text-emerald-400 flex items-center gap-0.5">
                                <ThumbsUp className="w-3 h-3" />
                                {itemVotes}
                              </span>
                              <span className="text-rose-400 flex items-center gap-0.5">
                                <ThumbsDown className="w-3 h-3" />
                                {itemDevotes}
                              </span>
                            </div>
                          </div>

                          {/* Locate Button */}
                          {onSelectEvent && item.status === 'published' && (
                            <button
                              onClick={() => {
                                onClose();
                                onSelectEvent(item);
                              }}
                              className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#141926] hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 border border-[#232b3d] hover:border-amber-500/40 text-[11px] font-mono transition-all"
                            >
                              <Globe2 className="w-3 h-3 text-amber-400" />
                              <span>Locate</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Tactical Bottom Action Bar (With Prominent Sign Out Button Shifted Here) */}
        <div className="px-6 py-4 border-t border-[#181f2f] bg-[#06080d] flex flex-col sm:flex-row items-center justify-between gap-3 sticky bottom-0 z-20">
          <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>
              Signed in as <strong className="text-white">{currentUser.codeName || currentUser.name}</strong> ({currentUser.designation || 'Operator'})
            </span>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-[#121622] hover:bg-[#1b2234] text-slate-300 hover:text-white rounded-xl text-xs font-mono font-semibold border border-[#222b3d] transition-all"
            >
              Close Dashboard
            </button>

            {/* Shifted Sign-Out Button: Prominent at bottom of Dashboard */}
            <button
              id="btn-dashboard-sign-out"
              onClick={() => {
                onClose();
                onSignOut();
              }}
              title="Sign Out of Session"
              className="flex items-center justify-center gap-2 px-5 py-2 bg-gradient-to-r from-red-950 to-rose-950 hover:from-red-900 hover:to-rose-900 text-red-200 hover:text-white border border-red-700/60 hover:border-red-500 rounded-xl text-xs font-mono font-bold transition-all shadow-lg shadow-red-950/40"
            >
              <LogOut className="w-4 h-4 text-red-400" />
              <span>SIGN OUT</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
