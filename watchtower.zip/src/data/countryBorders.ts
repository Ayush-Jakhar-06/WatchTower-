import { CountryData } from '../types.js';

// World Country Geopolitical & Tension Boundary Dataset
export const COUNTRIES_DATA: CountryData[] = [
  {
    id: 'UA',
    code: 'UKR',
    name: 'Ukraine',
    flag: '🇺🇦',
    lat: 48.3794,
    lng: 31.1656,
    conflictStatus: 'active_war',
    tensionScore: 98,
    activeIncidents: 14,
    threatSummary: 'Full-scale frontline kinetic engagements across Donbas & Kharkiv axes; ongoing long-range infrastructure air defense operations.',
    theater: 'Europe',
    polygonRings: [
      [
        [22.1, 48.4], [24.0, 50.5], [26.0, 51.5], [31.0, 52.0], [33.5, 52.3],
        [37.0, 50.0], [39.0, 49.5], [40.0, 48.0], [38.0, 46.5], [35.0, 45.0],
        [33.5, 46.0], [31.5, 46.5], [29.5, 45.5], [28.0, 46.0], [24.0, 47.8],
        [22.1, 48.4]
      ]
    ]
  },
  {
    id: 'RU',
    code: 'RUS',
    name: 'Russia',
    flag: '🇷🇺',
    lat: 61.524,
    lng: 105.3188,
    conflictStatus: 'active_war',
    tensionScore: 95,
    activeIncidents: 9,
    threatSummary: 'Strategic missile deployments, border oblast drone interdictions, active military mobilization and high sanctions pressure.',
    theater: 'Europe',
    polygonRings: [
      [
        [30.0, 59.5], [40.0, 67.0], [60.0, 68.0], [90.0, 74.0], [130.0, 72.0],
        [170.0, 66.0], [180.0, 60.0], [160.0, 53.0], [135.0, 45.0], [120.0, 50.0],
        [90.0, 51.0], [60.0, 52.0], [45.0, 50.0], [38.0, 55.0], [30.0, 59.5]
      ]
    ]
  },
  {
    id: 'LB',
    code: 'LBN',
    name: 'Lebanon',
    flag: '🇱🇧',
    lat: 33.8547,
    lng: 35.8623,
    conflictStatus: 'active_war',
    tensionScore: 94,
    activeIncidents: 12,
    threatSummary: 'IDF conducting targeted cross-border kinetic strikes; Hezbollah rocket salvos and intense skirmishes along the Blue Line.',
    theater: 'Middle East',
    polygonRings: [
      [
        [35.1, 33.1], [35.3, 33.6], [35.8, 34.4], [36.3, 34.6],
        [36.4, 34.0], [35.9, 33.4], [35.5, 33.1], [35.1, 33.1]
      ]
    ]
  },
  {
    id: 'IL',
    code: 'ISR',
    name: 'Israel',
    flag: '🇮🇱',
    lat: 31.0461,
    lng: 34.8516,
    conflictStatus: 'active_war',
    tensionScore: 96,
    activeIncidents: 11,
    threatSummary: 'Multi-front defensive alert with Iron Dome interceptors active against northern rockets and southern drone swarms.',
    theater: 'Middle East',
    polygonRings: [
      [
        [34.3, 31.3], [34.5, 31.8], [35.0, 33.0], [35.6, 33.2],
        [35.6, 32.7], [35.5, 31.5], [35.0, 29.5], [34.8, 29.5],
        [34.3, 31.3]
      ]
    ]
  },
  {
    id: 'YE',
    code: 'YEM',
    name: 'Yemen / Red Sea',
    flag: '🇾🇪',
    lat: 15.5527,
    lng: 48.5164,
    conflictStatus: 'active_war',
    tensionScore: 92,
    activeIncidents: 7,
    threatSummary: 'Houthi ballistic anti-ship missiles and unmanned aerial drone harassment against commercial tankers in Bab-el-Mandeb Strait.',
    theater: 'Middle East',
    polygonRings: [
      [
        [42.8, 16.5], [44.5, 17.5], [48.0, 18.0], [53.0, 16.5],
        [52.0, 14.5], [48.5, 14.0], [45.0, 12.8], [43.5, 12.6],
        [42.8, 16.5]
      ]
    ]
  },
  {
    id: 'SD',
    code: 'SDN',
    name: 'Sudan',
    flag: '🇸🇩',
    lat: 12.8628,
    lng: 30.2176,
    conflictStatus: 'active_war',
    tensionScore: 91,
    activeIncidents: 8,
    threatSummary: 'Protracted clash between SAF and RSF paramilitary forces over Khartoum and Darfur provinces; catastrophic humanitarian displacement.',
    theater: 'Africa',
    polygonRings: [
      [
        [22.0, 19.5], [25.0, 22.0], [33.0, 22.0], [37.0, 18.0],
        [38.5, 15.5], [34.0, 11.5], [31.5, 9.5], [27.0, 9.5],
        [23.5, 13.0], [22.0, 19.5]
      ]
    ]
  },
  {
    id: 'TW',
    code: 'TWN',
    name: 'Taiwan',
    flag: '🇹🇼',
    lat: 23.6978,
    lng: 120.9605,
    conflictStatus: 'high_tension',
    tensionScore: 86,
    activeIncidents: 6,
    threatSummary: 'Continuous PLA naval circumnavigation drills, ADIZ incursions, and elevated electronic warfare reconnaissance in the Strait.',
    theater: 'Asia-Pacific',
    polygonRings: [
      [
        [120.0, 25.3], [121.5, 25.3], [122.0, 24.5], [121.5, 22.0],
        [120.7, 22.0], [120.0, 23.5], [120.0, 25.3]
      ]
    ]
  },
  {
    id: 'IR',
    code: 'IRN',
    name: 'Iran',
    flag: '🇮🇷',
    lat: 32.4279,
    lng: 53.688,
    conflictStatus: 'high_tension',
    tensionScore: 89,
    activeIncidents: 5,
    threatSummary: 'Uranium enrichment threshold capabilities, regional proxy network logistics, and naval alerts across the Strait of Hormuz.',
    theater: 'Middle East',
    polygonRings: [
      [
        [45.0, 38.5], [48.0, 39.5], [54.0, 37.5], [60.0, 37.0],
        [61.5, 31.0], [62.0, 25.0], [57.0, 26.0], [50.0, 30.0],
        [47.0, 33.0], [45.0, 38.5]
      ]
    ]
  },
  {
    id: 'KP',
    code: 'PRK',
    name: 'North Korea',
    flag: '🇰🇵',
    lat: 40.3399,
    lng: 127.5101,
    conflictStatus: 'high_tension',
    tensionScore: 88,
    activeIncidents: 6,
    threatSummary: 'Troop and missile engineering deployments to eastern front lines; tactical nuclear ICBM testing across Sea of Japan.',
    theater: 'Asia-Pacific',
    polygonRings: [
      [
        [124.3, 40.0], [126.0, 42.0], [130.5, 42.5], [129.5, 40.5],
        [128.0, 38.5], [126.0, 38.0], [124.5, 38.5], [124.3, 40.0]
      ]
    ]
  },
  {
    id: 'SY',
    code: 'SYR',
    name: 'Syria',
    flag: '🇸🇾',
    lat: 34.8021,
    lng: 38.9968,
    conflictStatus: 'active_war',
    tensionScore: 87,
    activeIncidents: 5,
    threatSummary: 'Airstrikes targeting weapons transit corridors; contested northern borders and irregular skirmishes.',
    theater: 'Middle East',
    polygonRings: [
      [
        [36.0, 35.8], [37.0, 36.8], [42.0, 37.2], [42.3, 36.0],
        [39.0, 33.5], [37.0, 32.5], [36.0, 33.0], [36.0, 35.8]
      ]
    ]
  },
  {
    id: 'ML',
    code: 'MLI',
    name: 'Mali & Sahel',
    flag: '🇲🇱',
    lat: 17.5707,
    lng: -3.9962,
    conflictStatus: 'high_tension',
    tensionScore: 83,
    activeIncidents: 4,
    threatSummary: 'Insurgent attacks along central corridors; withdrawal of western peacekeeping detachments and private military contractor deployments.',
    theater: 'Africa',
    polygonRings: [
      [
        [-11.5, 14.5], [-9.0, 17.0], [-5.0, 24.5], [3.5, 20.0],
        [4.0, 15.0], [0.0, 15.0], [-4.0, 11.0], [-7.5, 11.5],
        [-11.5, 14.5]
      ]
    ]
  },
  {
    id: 'MM',
    code: 'MMR',
    name: 'Myanmar',
    flag: '🇲🇲',
    lat: 21.9162,
    lng: 95.956,
    conflictStatus: 'active_war',
    tensionScore: 85,
    activeIncidents: 4,
    threatSummary: 'Nationwide civil conflict between military junta and Three Brotherhood Alliance resistance forces controlling border trade gates.',
    theater: 'Asia-Pacific',
    polygonRings: [
      [
        [93.0, 22.0], [97.5, 28.0], [99.0, 23.0], [101.0, 21.0],
        [98.5, 15.0], [98.5, 10.0], [96.0, 16.5], [94.0, 19.5],
        [93.0, 22.0]
      ]
    ]
  },
  {
    id: 'US',
    code: 'USA',
    name: 'United States',
    flag: '🇺🇸',
    lat: 37.0902,
    lng: -95.7129,
    conflictStatus: 'elevated',
    tensionScore: 45,
    activeIncidents: 4,
    threatSummary: 'Strategic deterrence posture, critical defense logistics surges to Europe & INDOPACOM allies, cyber threat readiness.',
    theater: 'Americas',
    polygonRings: [
      [
        [-124.5, 48.5], [-95.0, 49.0], [-71.0, 45.0], [-67.0, 44.5],
        [-75.0, 35.0], [-80.5, 25.5], [-90.0, 29.5], [-97.5, 26.0],
        [-117.0, 32.5], [-124.0, 40.0], [-124.5, 48.5]
      ]
    ]
  },
  {
    id: 'DE',
    code: 'DEU',
    name: 'Germany',
    flag: '🇩🇪',
    lat: 51.1657,
    lng: 10.4515,
    conflictStatus: 'elevated',
    tensionScore: 52,
    activeIncidents: 3,
    threatSummary: 'Disrupted foreign assassination plot against defense contractor executives; critical infrastructure hybrid sabotage alerts.',
    theater: 'Europe',
    polygonRings: [
      [
        [6.0, 50.5], [7.0, 53.5], [10.0, 54.5], [14.0, 54.0],
        [15.0, 51.0], [13.0, 48.5], [9.0, 47.5], [6.5, 49.5],
        [6.0, 50.5]
      ]
    ]
  },
  {
    id: 'PL',
    code: 'POL',
    name: 'Poland',
    flag: '🇵🇱',
    lat: 51.9194,
    lng: 19.1451,
    conflictStatus: 'elevated',
    tensionScore: 68,
    activeIncidents: 3,
    threatSummary: 'Eastern border fortification (Shield-East initiative); Suwalki Gap rapid response deterrence against hybrid incursions.',
    theater: 'Europe',
    polygonRings: [
      [
        [14.5, 53.5], [18.5, 54.8], [23.0, 54.0], [24.0, 51.5],
        [22.5, 49.5], [19.0, 49.5], [15.0, 51.0], [14.5, 53.5]
      ]
    ]
  },
  {
    id: 'CN',
    code: 'CHN',
    name: 'China',
    flag: '🇨🇳',
    lat: 35.8617,
    lng: 104.1954,
    conflictStatus: 'elevated',
    tensionScore: 74,
    activeIncidents: 5,
    threatSummary: 'South China Sea maritime confrontation patrols, naval expansion, and dual-use supply chain leverage.',
    theater: 'Asia-Pacific',
    polygonRings: [
      [
        [75.0, 37.0], [80.0, 45.0], [90.0, 48.0], [115.0, 48.0],
        [130.0, 47.0], [122.0, 39.0], [121.0, 31.0], [118.0, 24.0],
        [110.0, 20.0], [100.0, 21.5], [90.0, 27.5], [80.0, 31.0],
        [75.0, 37.0]
      ]
    ]
  },
  {
    id: 'IN',
    code: 'IND',
    name: 'India',
    flag: '🇮🇳',
    lat: 20.5937,
    lng: 78.9629,
    conflictStatus: 'elevated',
    tensionScore: 58,
    activeIncidents: 4,
    threatSummary: 'Himalayan LAC boundary surveillance; Indian Ocean naval security and anti-piracy escort coordination.',
    theater: 'Asia-Pacific',
    polygonRings: [
      [
        [68.5, 23.5], [72.0, 31.0], [75.0, 36.5], [79.0, 35.5],
        [88.0, 27.5], [96.0, 28.0], [93.0, 22.0], [88.5, 22.0],
        [80.0, 13.0], [77.5, 8.0], [73.5, 15.0], [68.5, 23.5]
      ]
    ]
  },
  {
    id: 'GB',
    code: 'GBR',
    name: 'United Kingdom',
    flag: '🇬🇧',
    lat: 55.3781,
    lng: -3.436,
    conflictStatus: 'monitored',
    tensionScore: 35,
    activeIncidents: 2,
    threatSummary: 'Royal Navy North Atlantic subsea cable patrol operations; ongoing joint military aid packages.',
    theater: 'Europe',
    polygonRings: [
      [
        [-5.5, 50.0], [-1.0, 50.5], [1.5, 52.5], [0.0, 54.5],
        [-2.0, 58.5], [-5.0, 58.5], [-6.0, 55.0], [-4.5, 52.0],
        [-5.5, 50.0]
      ]
    ]
  },
  {
    id: 'FR',
    code: 'FRA',
    name: 'France',
    flag: '🇫🇷',
    lat: 46.2276,
    lng: 2.2137,
    conflictStatus: 'monitored',
    tensionScore: 38,
    activeIncidents: 2,
    threatSummary: 'Strategic autonomous nuclear deterrence posture; European rapid intervention force leadership.',
    theater: 'Europe',
    polygonRings: [
      [
        [-4.5, 48.5], [0.0, 49.5], [2.5, 51.0], [7.5, 49.0],
        [7.0, 44.0], [3.0, 42.5], [-1.5, 43.5], [-1.0, 46.0],
        [-4.5, 48.5]
      ]
    ]
  },
  {
    id: 'JP',
    code: 'JPN',
    name: 'Japan',
    flag: '🇯🇵',
    lat: 36.2048,
    lng: 138.2529,
    conflictStatus: 'elevated',
    tensionScore: 62,
    activeIncidents: 3,
    threatSummary: 'Southwestern Nansei islands missile battery reinforcement; Aegis ballistic missile defense tracking.',
    theater: 'Asia-Pacific',
    polygonRings: [
      [
        [130.0, 31.5], [133.0, 34.0], [137.0, 35.0], [141.0, 38.5],
        [145.0, 44.0], [141.0, 45.0], [139.0, 41.0], [136.0, 36.5],
        [130.0, 31.5]
      ]
    ]
  },
  {
    id: 'KR',
    code: 'KOR',
    name: 'South Korea',
    flag: '🇰🇷',
    lat: 35.9078,
    lng: 127.7669,
    conflictStatus: 'elevated',
    tensionScore: 72,
    activeIncidents: 3,
    threatSummary: 'DMZ surveillance on highest alert level; joint combined arms readiness exercises with US Forces Korea.',
    theater: 'Asia-Pacific',
    polygonRings: [
      [
        [126.0, 37.8], [128.5, 38.5], [129.5, 36.0], [129.0, 35.0],
        [126.5, 34.5], [126.0, 36.5], [126.0, 37.8]
      ]
    ]
  }
];

// Helper to look up country by code or name
export function findCountryData(query: string): CountryData | undefined {
  if (!query) return undefined;
  const q = query.toLowerCase();
  return COUNTRIES_DATA.find(
    (c) =>
      c.name.toLowerCase() === q ||
      c.code.toLowerCase() === q ||
      c.id.toLowerCase() === q
  );
}

// Get all active tension / conflict countries
export function getActiveConflictCountries(): CountryData[] {
  return COUNTRIES_DATA.filter((c) => c.conflictStatus === 'active_war' || c.conflictStatus === 'high_tension');
}
