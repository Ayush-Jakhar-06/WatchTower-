import React, { useState, useEffect, useMemo } from 'react';
import { GlobalEvent, User, CountryData } from './types.js';
import { INITIAL_EVENTS } from './data/initialEvents.js';
import { Header, PRESET_USERS } from './components/Header.js';
import { Globe3D } from './components/Globe3D.js';
import { IntelFeedPanel } from './components/IntelFeedPanel.js';
import { PredictionsAndMarketsPanel } from './components/PredictionsAndMarketsPanel.js';
import { EventCard } from './components/EventCard.js';
import { EventDetailModal } from './components/EventDetailModal.js';
import { StructuredSubmitModal } from './components/StructuredSubmitModal.js';
import { NearbyRadar } from './components/NearbyRadar.js';
import { AdminPanel } from './components/AdminPanel.js';
import { AuthModal } from './components/AuthModal.js';
import { ReporterProfilePanel } from './components/ReporterProfilePanel.js';
import {
  Globe,
  Radio,
  Flame,
  PlusCircle,
  ShieldCheck,
  Search,
  Sparkles,
  LayoutGrid,
  Maximize2,
  Minimize2,
  RefreshCw,
  Compass,
  AlertCircle,
  Activity,
  Layers,
  Target,
  FileText,
  Lock,
} from 'lucide-react';

export default function App() {
  // Current user / Persona (defaults to null for Guest view; persists on sign-in)
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('watchtower_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('watchtower_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('watchtower_user');
    }
  }, [currentUser]);

  const [events, setEvents] = useState<GlobalEvent[]>(() =>
    INITIAL_EVENTS.filter((e) => e.status === 'published')
  );
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // View state
  const [activeTab, setActiveTab] = useState<'globe' | 'feed' | 'radar' | 'predictions' | 'admin'>('globe');
  const [activeTheater, setActiveTheater] = useState<string>('GLOBAL');
  const [selectedEvent, setSelectedEvent] = useState<GlobalEvent | null>(null);
  const [focusedEventId, setFocusedEventId] = useState<string | null>(null);
  const [focusedCountryId, setFocusedCountryId] = useState<string | null>(null);

  // Expandable & Reducible Panel Layout States
  const [leftPanelState, setLeftPanelState] = useState<'standard' | 'expanded' | 'collapsed'>('standard');
  const [rightPanelState, setRightPanelState] = useState<'standard' | 'expanded' | 'collapsed'>('standard');
  const [resolutionPreset, setResolutionPreset] = useState<'auto' | '1440' | '768' | '390'>('auto');
  const [mobileDrawer, setMobileDrawer] = useState<'none' | 'intel' | 'markets'>('none');

  // Feed Filter state
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedFeedFilter, setSelectedFeedFilter] = useState<'ALL' | 'PULSE' | 'NEWS' | 'HIGH' | 'RADAR'>('ALL');

  // Modals
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [isProfilePanelOpen, setIsProfilePanelOpen] = useState<boolean>(false);

  // Panel state helpers
  const isGlobeFocusMode = leftPanelState === 'collapsed' && rightPanelState === 'collapsed';

  const handleToggleLeftExpand = () => {
    setLeftPanelState((prev) => (prev === 'expanded' ? 'standard' : 'expanded'));
  };

  const handleCollapseLeft = () => {
    setLeftPanelState('collapsed');
  };

  const handleToggleLeftPanel = () => {
    setLeftPanelState((prev) => (prev === 'collapsed' ? 'standard' : 'collapsed'));
  };

  const handleToggleRightExpand = () => {
    setRightPanelState((prev) => (prev === 'expanded' ? 'standard' : 'expanded'));
  };

  const handleCollapseRight = () => {
    setRightPanelState('collapsed');
  };

  const handleToggleRightPanel = () => {
    setRightPanelState((prev) => (prev === 'collapsed' ? 'standard' : 'collapsed'));
  };

  const handleToggleGlobeFocus = () => {
    if (isGlobeFocusMode) {
      setLeftPanelState('standard');
      setRightPanelState('standard');
    } else {
      setLeftPanelState('collapsed');
      setRightPanelState('collapsed');
    }
  };

  // Load events
  const fetchEvents = async () => {
    try {
      setLoading(true);
      const headers: Record<string, string> = {};
      if (currentUser) {
        headers['Authorization'] = `Bearer ${currentUser.id}`;
      }
      const res = await fetch('/api/events', { headers });
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }
      const data = await res.json();
      if (data.success && Array.isArray(data.events)) {
        setEvents(data.events);
        setError(null);
      }
    } catch (err) {
      console.warn('API notice (hydrating with local conflict intelligence feed):', err);
      setEvents((prev) => (prev.length > 0 ? prev : INITIAL_EVENTS));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEvents();
  }, [currentUser]);

  // Hot alerts list
  const hotEvents = useMemo(() => {
    return events.filter((e) => e.isHotAlert);
  }, [events]);

  // Handle community trust voting
  const handleVote = async (eventId: string, type: 'up' | 'down') => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return;
    }

    try {
      const res = await fetch(`/api/events/${eventId}/vote`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${currentUser.id}`,
        },
        body: JSON.stringify({ voteType: type, type }),
      });
      const data = await res.json();
      if (data.success && data.trustMetrics) {
        setEvents((prev) =>
          prev.map((e) => (e.id === eventId ? { ...e, trustMetrics: data.trustMetrics } : e))
        );
        if (selectedEvent && selectedEvent.id === eventId) {
          setSelectedEvent((prev) =>
            prev ? { ...prev, trustMetrics: data.trustMetrics } : null
          );
        }
      }
    } catch (err) {
      console.error('Vote failed', err);
    }
  };

  // Handle Admin Moderation Action
  const handleAdminModerate = async (
    eventId: string,
    action: 'approve' | 'reject' | 'mark_false',
    reason?: string
  ) => {
    if (!currentUser || currentUser.role !== 'admin') return;
    try {
      const res = await fetch(`/api/admin/events/${eventId}/moderate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${currentUser.id}`,
        },
        body: JSON.stringify({ action, reason }),
      });
      const data = await res.json();
      if (data.success) {
        fetchEvents();
      }
    } catch (err) {
      console.error('Moderation failed', err);
    }
  };

  // Handle Admin Toggle Hot
  const handleAdminToggleHot = async (eventId: string) => {
    if (!currentUser || currentUser.role !== 'admin') return;
    try {
      const res = await fetch(`/api/admin/events/${eventId}/toggle-hot`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${currentUser.id}`,
        },
      });
      const data = await res.json();
      if (data.success) {
        fetchEvents();
      }
    } catch (err) {
      console.error('Toggle hot failed', err);
    }
  };

  // Handle Admin Permanent Deletion of Report
  const handleAdminDelete = async (eventId: string) => {
    if (!currentUser || currentUser.role !== 'admin') return;
    try {
      const res = await fetch(`/api/admin/events/${eventId}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${currentUser.id}`,
        },
      });
      const data = await res.json();
      if (data.success) {
        setEvents((prev) => prev.filter((e) => e.id !== eventId));
        if (selectedEvent && selectedEvent.id === eventId) {
          setSelectedEvent(null);
        }
      }
    } catch (err) {
      console.error('Delete event failed', err);
    }
  };

  // Focus event on 3D globe
  const handleFocusGlobe = (eventId: string) => {
    setFocusedEventId(eventId);
    if (activeTab !== 'globe') {
      setActiveTab('globe');
    }
    const found = events.find((e) => e.id === eventId);
    if (found) {
      setSelectedEvent(found);
    }
  };

  // Resolution container class helper
  const getResolutionContainerClass = () => {
    switch (resolutionPreset) {
      case '1440':
        return 'max-w-[1440px] mx-auto w-full border-x border-[#1a1e29] shadow-2xl';
      case '768':
        return 'max-w-[768px] mx-auto w-full border-x border-[#1a1e29] shadow-2xl';
      case '390':
        return 'max-w-[390px] mx-auto w-full border-x border-[#1a1e29] shadow-2xl';
      case 'auto':
      default:
        return 'w-full';
    }
  };

  return (
    <div className="h-screen w-full bg-[#07080b] text-slate-100 flex flex-col font-sans selection:bg-red-600 selection:text-white antialiased overflow-hidden">
      {/* Universal Header with Latest News Ticker */}
      <div className="shrink-0">
        <Header
          currentUser={currentUser}
          onSwitchUser={setCurrentUser}
          onOpenAuthModal={() => setIsAuthModalOpen(true)}
          onOpenProfilePanel={() => setIsProfilePanelOpen(true)}
          onSignOut={() => {
            setCurrentUser(null);
            if (activeTab === 'admin') setActiveTab('globe');
          }}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          onOpenSubmitModal={() => {
            if (!currentUser) {
              setIsAuthModalOpen(true);
              return;
            }
            setIsSubmitModalOpen(true);
          }}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          hotEvents={hotEvents}
          onSelectEvent={(evt) => {
            setSelectedEvent(evt);
            setFocusedEventId(evt.id);
          }}
          resolutionPreset={resolutionPreset}
          onChangeResolutionPreset={setResolutionPreset}
          leftPanelCollapsed={leftPanelState === 'collapsed'}
          rightPanelCollapsed={rightPanelState === 'collapsed'}
          onToggleLeftPanel={handleToggleLeftPanel}
          onToggleRightPanel={handleToggleRightPanel}
        />
      </div>

      {/* Main Command Center Layout with Adaptive Device Resolution Container */}
      <div className={`flex-1 min-h-0 flex flex-col overflow-hidden transition-all duration-300 ${getResolutionContainerClass()}`}>
        <main className={`flex-1 min-h-0 flex flex-col relative ${activeTab === 'globe' ? 'overflow-hidden' : 'overflow-y-auto'}`}>
          {/* TAB 1: WAR ROOM EXPANDABLE / REDUCIBLE 3D GLOBE LAYOUT */}
          {activeTab === 'globe' && (
            <div className="flex-1 min-h-0 w-full h-full flex overflow-hidden relative">
              {/* Left Panel: Intel Feed (Expandable, Reducible, Collapsible) */}
              {leftPanelState !== 'collapsed' && (
                <div
                  className={`h-full overflow-hidden transition-all duration-300 ease-in-out shrink-0 border-r border-[#1a1e29] ${
                    leftPanelState === 'expanded'
                      ? 'w-[480px] xl:w-[540px]'
                      : 'w-[320px] md:w-[340px] lg:w-[360px]'
                  } hidden md:flex`}
                >
                  <IntelFeedPanel
                    events={events}
                    selectedEventId={selectedEvent?.id || null}
                    currentUser={currentUser}
                    onSelectEvent={(evt) => {
                      setSelectedEvent(evt);
                      setFocusedEventId(evt.id);
                    }}
                    onFocusGlobe={(id) => handleFocusGlobe(id)}
                    onVote={(id, type) => handleVote(id, type)}
                    onRefresh={fetchEvents}
                    loading={loading}
                    searchQuery={searchQuery}
                    setSearchQuery={setSearchQuery}
                    selectedFilter={selectedFeedFilter}
                    setSelectedFilter={setSelectedFeedFilter}
                    onOpenRadar={() => setActiveTab('radar')}
                    panelState={leftPanelState}
                    onToggleExpand={handleToggleLeftExpand}
                    onCollapse={handleCollapseLeft}
                  />
                </div>
              )}

              {/* Center Stage: 3D Globe with Realistic Boundaries and War Zones */}
              <div className="flex-1 h-full min-w-0 relative bg-[#07080b] flex flex-col overflow-hidden">
                <Globe3D
                  events={events}
                  selectedEventId={selectedEvent?.id || null}
                  onSelectEvent={(evt) => setSelectedEvent(evt)}
                  onSelectCountry={(country) => {
                    setFocusedCountryId(country.code);
                  }}
                  focusedEventId={focusedEventId}
                  focusedCountryId={focusedCountryId}
                  activeTheater={activeTheater}
                  onTheaterChange={setActiveTheater}
                  leftPanelCollapsed={leftPanelState === 'collapsed'}
                  rightPanelCollapsed={rightPanelState === 'collapsed'}
                  onToggleLeftPanel={handleToggleLeftPanel}
                  onToggleRightPanel={handleToggleRightPanel}
                  isGlobeFocusMode={isGlobeFocusMode}
                  onToggleGlobeFocus={handleToggleGlobeFocus}
                />
              </div>

              {/* Right Panel: Predictions & Defense Markets (Expandable, Reducible, Collapsible) */}
              {rightPanelState !== 'collapsed' && (
                <div
                  className={`h-full overflow-hidden transition-all duration-300 ease-in-out shrink-0 border-l border-[#1a1e29] ${
                    rightPanelState === 'expanded'
                      ? 'w-[460px] xl:w-[500px]'
                      : 'w-[320px] lg:w-[340px] xl:w-[360px]'
                  } hidden lg:flex`}
                >
                  <PredictionsAndMarketsPanel
                    currentUser={currentUser}
                    onOpenAuthModal={() => setIsAuthModalOpen(true)}
                    onSelectCountry={(code) => setFocusedCountryId(code)}
                    panelState={rightPanelState}
                    onToggleExpand={handleToggleRightExpand}
                    onCollapse={handleCollapseRight}
                  />
                </div>
              )}

              {/* Mobile Quick Drawer Access Bar (for 360px - 768px screens) */}
              <div className="md:hidden absolute bottom-12 left-4 right-4 z-30 flex items-center justify-between gap-2 p-1.5 rounded-xl bg-[#0e1017]/95 backdrop-blur-xl border border-[#262a36] shadow-2xl">
                <button
                  onClick={() => setMobileDrawer(mobileDrawer === 'intel' ? 'none' : 'intel')}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-mono font-bold transition-all ${
                    mobileDrawer === 'intel'
                      ? 'bg-red-600 text-white shadow-lg'
                      : 'bg-[#181b24] text-slate-200 hover:text-white'
                  }`}
                >
                  <Radio className="w-3.5 h-3.5 text-red-400" />
                  <span>INTEL ({events.length})</span>
                </button>
                <button
                  onClick={() => setMobileDrawer(mobileDrawer === 'markets' ? 'none' : 'markets')}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-mono font-bold transition-all ${
                    mobileDrawer === 'markets'
                      ? 'bg-sky-600 text-white shadow-lg'
                      : 'bg-[#181b24] text-slate-200 hover:text-white'
                  }`}
                >
                  <Target className="w-3.5 h-3.5 text-sky-400" />
                  <span>MARKETS</span>
                </button>
              </div>

              {/* Mobile Drawer Bottom Sheet Overlay */}
              {mobileDrawer !== 'none' && (
                <div className="md:hidden fixed inset-x-0 bottom-0 z-40 h-[75vh] bg-[#0c0e14] border-t-2 border-red-600/80 rounded-t-2xl shadow-2xl flex flex-col animate-in slide-in-from-bottom duration-200">
                  <div className="flex items-center justify-between px-4 py-2.5 border-b border-[#1f2330] bg-[#10121a]">
                    <div className="w-10 h-1 bg-slate-600 rounded-full mx-auto absolute left-1/2 -translate-x-1/2 top-2" />
                    <span className="font-mono font-bold text-xs text-white uppercase mt-1">
                      {mobileDrawer === 'intel' ? 'Live Intel Feed' : 'Defense Markets & Predictions'}
                    </span>
                    <button
                      onClick={() => setMobileDrawer('none')}
                      className="px-2.5 py-1 rounded bg-[#1e222e] text-slate-300 font-mono text-[11px] hover:text-white"
                    >
                      CLOSE
                    </button>
                  </div>
                  <div className="flex-1 overflow-hidden p-2">
                    {mobileDrawer === 'intel' ? (
                      <IntelFeedPanel
                        events={events}
                        selectedEventId={selectedEvent?.id || null}
                        currentUser={currentUser}
                        onSelectEvent={(evt) => {
                          setSelectedEvent(evt);
                          setFocusedEventId(evt.id);
                          setMobileDrawer('none');
                        }}
                        onFocusGlobe={(id) => {
                          handleFocusGlobe(id);
                          setMobileDrawer('none');
                        }}
                        onVote={(id, type) => handleVote(id, type)}
                        onRefresh={fetchEvents}
                        loading={loading}
                        searchQuery={searchQuery}
                        setSearchQuery={setSearchQuery}
                        selectedFilter={selectedFeedFilter}
                        setSelectedFilter={setSelectedFeedFilter}
                        onOpenRadar={() => {
                          setActiveTab('radar');
                          setMobileDrawer('none');
                        }}
                      />
                    ) : (
                      <PredictionsAndMarketsPanel
                        currentUser={currentUser}
                        onOpenAuthModal={() => {
                          setMobileDrawer('none');
                          setIsAuthModalOpen(true);
                        }}
                        onSelectCountry={(code) => {
                          setFocusedCountryId(code);
                          setMobileDrawer('none');
                        }}
                      />
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: FULL INTEL FEED */}
          {activeTab === 'feed' && (
            <div className="flex-1 max-w-5xl mx-auto w-full px-4 sm:px-6 py-6 space-y-4">
              <IntelFeedPanel
                events={events}
                selectedEventId={selectedEvent?.id || null}
                currentUser={currentUser}
                onSelectEvent={(evt) => setSelectedEvent(evt)}
                onFocusGlobe={(id) => handleFocusGlobe(id)}
                onVote={(id, type) => handleVote(id, type)}
                onRefresh={fetchEvents}
                loading={loading}
                searchQuery={searchQuery}
                setSearchQuery={setSearchQuery}
                selectedFilter={selectedFeedFilter}
                setSelectedFilter={setSelectedFeedFilter}
              />
            </div>
          )}

          {/* TAB 3: DEDICATED PREDICTIONS & MARKETS VIEW */}
          {activeTab === 'predictions' && (
            <div className="flex-1 max-w-4xl mx-auto w-full p-4 sm:p-6">
              <PredictionsAndMarketsPanel
                currentUser={currentUser}
                onOpenAuthModal={() => setIsAuthModalOpen(true)}
              />
            </div>
          )}

          {/* TAB 4: NEARBY GEOSPATIAL RADAR */}
          {activeTab === 'radar' && (
            <NearbyRadar
              events={events}
              currentUser={currentUser}
              onSelectEvent={(evt) => setSelectedEvent(evt)}
              onFocusGlobe={(id) => handleFocusGlobe(id)}
            />
          )}

          {/* TAB 5: ADMIN CONTROL & MODERATION */}
          {activeTab === 'admin' && currentUser?.role === 'admin' && (
            <AdminPanel
              currentUser={currentUser}
              onSelectEvent={(evt) => setSelectedEvent(evt)}
              onRefreshData={fetchEvents}
            />
          )}
        </main>
      </div>

      {/* Event Detail Inspector Modal */}
      {selectedEvent && (
        <EventDetailModal
          event={selectedEvent}
          onClose={() => setSelectedEvent(null)}
          currentUser={currentUser}
          onVote={(id, type) => handleVote(id, type)}
          onFocusGlobe={(id) => handleFocusGlobe(id)}
          onAdminModerate={
            currentUser?.role === 'admin'
              ? (id, action, reason) => handleAdminModerate(id, action, reason)
              : undefined
          }
          onAdminToggleHot={
            currentUser?.role === 'admin'
              ? (id) => handleAdminToggleHot(id)
              : undefined
          }
          onAdminDelete={
            currentUser?.role === 'admin'
              ? (id) => handleAdminDelete(id)
              : undefined
          }
        />
      )}

      {/* Structured Field Report Submission Modal */}
      {isSubmitModalOpen && (
        <StructuredSubmitModal
          currentUser={currentUser}
          onClose={() => setIsSubmitModalOpen(false)}
          onSubmitSuccess={() => {
            fetchEvents();
            setActiveTab('globe');
          }}
          onUserCreated={(createdUser) => {
            setCurrentUser(createdUser);
          }}
        />
      )}

      {/* Auth / Account Modal */}
      {isAuthModalOpen && (
        <AuthModal
          onClose={() => setIsAuthModalOpen(false)}
          onLoginSuccess={(user) => {
            setCurrentUser(user);
            fetchEvents();
          }}
        />
      )}

      {/* Field Reporter / User Dashboard */}
      {isProfilePanelOpen && (
        <ReporterProfilePanel
          isOpen={isProfilePanelOpen}
          currentUser={currentUser}
          events={events}
          onClose={() => setIsProfilePanelOpen(false)}
          onSignOut={() => {
            setCurrentUser(null);
            setIsProfilePanelOpen(false);
            if (activeTab === 'admin') setActiveTab('globe');
          }}
          onSelectEvent={(evt) => {
            setSelectedEvent(evt);
            setFocusedEventId(evt.id);
            setIsProfilePanelOpen(false);
          }}
          onOpenSubmitModal={() => {
            setIsProfilePanelOpen(false);
            setIsSubmitModalOpen(true);
          }}
          onOpenAuthModal={() => {
            setIsProfilePanelOpen(false);
            setIsAuthModalOpen(true);
          }}
        />
      )}
    </div>
  );
}
