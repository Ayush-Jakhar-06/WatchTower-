import * as topojson from 'topojson-client';
import countriesData from 'world-atlas/countries-110m.json';
import landData from 'world-atlas/land-110m.json';
import { CountryData } from '../types.js';

// Mapping ISO 3166-1 numeric IDs to ISO Alpha-2, Alpha-3, Name, Flag, and Conflict Data
export interface RealCountryInfo {
  numericId: string;
  code2: string;
  code3: string;
  name: string;
  flag: string;
  lat: number;
  lng: number;
  conflictStatus?: 'active_war' | 'high_tension' | 'elevated' | 'monitored' | 'stable';
  tensionScore?: number;
  activeIncidents?: number;
  threatSummary?: string;
  theater?: string;
}

export const REAL_COUNTRIES_MAP: Record<string, RealCountryInfo> = {
  '804': {
    numericId: '804',
    code2: 'UA',
    code3: 'UKR',
    name: 'Ukraine',
    flag: '🇺🇦',
    lat: 48.3794,
    lng: 31.1656,
    conflictStatus: 'active_war',
    tensionScore: 98,
    activeIncidents: 14,
    threatSummary: 'Full-scale frontline kinetic engagements across Donbas & Kharkiv axes; ongoing long-range infrastructure air defense operations.',
    theater: 'Europe'
  },
  '643': {
    numericId: '643',
    code2: 'RU',
    code3: 'RUS',
    name: 'Russia',
    flag: '🇷🇺',
    lat: 61.524,
    lng: 105.3188,
    conflictStatus: 'active_war',
    tensionScore: 95,
    activeIncidents: 9,
    threatSummary: 'Strategic missile deployments, border oblast drone interdictions, active military mobilization and high sanctions pressure.',
    theater: 'Europe'
  },
  '422': {
    numericId: '422',
    code2: 'LB',
    code3: 'LBN',
    name: 'Lebanon',
    flag: '🇱🇧',
    lat: 33.8547,
    lng: 35.8623,
    conflictStatus: 'active_war',
    tensionScore: 94,
    activeIncidents: 12,
    threatSummary: 'IDF conducting targeted cross-border kinetic strikes; Hezbollah rocket salvos and intense skirmishes along the Blue Line.',
    theater: 'Middle East'
  },
  '376': {
    numericId: '376',
    code2: 'IL',
    code3: 'ISR',
    name: 'Israel',
    flag: '🇮🇱',
    lat: 31.0461,
    lng: 34.8516,
    conflictStatus: 'active_war',
    tensionScore: 96,
    activeIncidents: 11,
    threatSummary: 'Multi-front defensive alert with Iron Dome interceptors active against northern rockets and southern drone swarms.',
    theater: 'Middle East'
  },
  '887': {
    numericId: '887',
    code2: 'YE',
    code3: 'YEM',
    name: 'Yemen',
    flag: '🇾🇪',
    lat: 15.5527,
    lng: 48.5164,
    conflictStatus: 'active_war',
    tensionScore: 92,
    activeIncidents: 7,
    threatSummary: 'Houthi ballistic anti-ship missiles and unmanned aerial drone harassment against commercial tankers in Bab-el-Mandeb Strait.',
    theater: 'Middle East'
  },
  '729': {
    numericId: '729',
    code2: 'SD',
    code3: 'SDN',
    name: 'Sudan',
    flag: '🇸🇩',
    lat: 12.8628,
    lng: 30.2176,
    conflictStatus: 'active_war',
    tensionScore: 91,
    activeIncidents: 8,
    threatSummary: 'Protracted clash between SAF and RSF paramilitary forces over Khartoum and Darfur provinces; catastrophic humanitarian displacement.',
    theater: 'Africa'
  },
  '158': {
    numericId: '158',
    code2: 'TW',
    code3: 'TWN',
    name: 'Taiwan',
    flag: '🇹🇼',
    lat: 23.6978,
    lng: 120.9605,
    conflictStatus: 'high_tension',
    tensionScore: 86,
    activeIncidents: 6,
    threatSummary: 'Continuous PLA naval circumnavigation drills, ADIZ incursions, and elevated electronic warfare reconnaissance in the Strait.',
    theater: 'Asia-Pacific'
  },
  '364': {
    numericId: '364',
    code2: 'IR',
    code3: 'IRN',
    name: 'Iran',
    flag: '🇮🇷',
    lat: 32.4279,
    lng: 53.688,
    conflictStatus: 'high_tension',
    tensionScore: 89,
    activeIncidents: 5,
    threatSummary: 'Uranium enrichment threshold capabilities, regional proxy network logistics, and naval alerts across the Strait of Hormuz.',
    theater: 'Middle East'
  },
  '408': {
    numericId: '408',
    code2: 'KP',
    code3: 'PRK',
    name: 'North Korea',
    flag: '🇰🇵',
    lat: 40.3399,
    lng: 127.5101,
    conflictStatus: 'high_tension',
    tensionScore: 88,
    activeIncidents: 6,
    threatSummary: 'Troop and missile engineering deployments to eastern front lines; tactical nuclear ICBM testing across Sea of Japan.',
    theater: 'Asia-Pacific'
  },
  '760': {
    numericId: '760',
    code2: 'SY',
    code3: 'SYR',
    name: 'Syria',
    flag: '🇸🇾',
    lat: 34.8021,
    lng: 38.9968,
    conflictStatus: 'active_war',
    tensionScore: 87,
    activeIncidents: 5,
    threatSummary: 'Airstrikes targeting weapons transit corridors; contested northern borders and irregular skirmishes.',
    theater: 'Middle East'
  },
  '466': {
    numericId: '466',
    code2: 'ML',
    code3: 'MLI',
    name: 'Mali & Sahel',
    flag: '🇲🇱',
    lat: 17.5707,
    lng: -3.9962,
    conflictStatus: 'high_tension',
    tensionScore: 83,
    activeIncidents: 4,
    threatSummary: 'Insurgent attacks along central corridors; withdrawal of western peacekeeping detachments and private military contractor deployments.',
    theater: 'Africa'
  },
  '104': {
    numericId: '104',
    code2: 'MM',
    code3: 'MMR',
    name: 'Myanmar',
    flag: '🇲🇲',
    lat: 21.9162,
    lng: 95.956,
    conflictStatus: 'active_war',
    tensionScore: 85,
    activeIncidents: 4,
    threatSummary: 'Nationwide civil conflict between military junta and Three Brotherhood Alliance resistance forces controlling border trade gates.',
    theater: 'Asia-Pacific'
  },
  '840': {
    numericId: '840',
    code2: 'US',
    code3: 'USA',
    name: 'United States',
    flag: '🇺🇸',
    lat: 37.0902,
    lng: -95.7129,
    conflictStatus: 'elevated',
    tensionScore: 45,
    activeIncidents: 4,
    threatSummary: 'Strategic deterrence posture, critical defense logistics surges to Europe & INDOPACOM allies, cyber threat readiness.',
    theater: 'Americas'
  },
  '276': {
    numericId: '276',
    code2: 'DE',
    code3: 'DEU',
    name: 'Germany',
    flag: '🇩🇪',
    lat: 51.1657,
    lng: 10.4515,
    conflictStatus: 'elevated',
    tensionScore: 52,
    activeIncidents: 3,
    threatSummary: 'Disrupted foreign assassination plot against defense contractor executives; critical infrastructure hybrid sabotage alerts.',
    theater: 'Europe'
  },
  '616': {
    numericId: '616',
    code2: 'PL',
    code3: 'POL',
    name: 'Poland',
    flag: '🇵🇱',
    lat: 51.9194,
    lng: 19.1451,
    conflictStatus: 'elevated',
    tensionScore: 68,
    activeIncidents: 3,
    threatSummary: 'Eastern border fortification (Shield-East initiative); Suwalki Gap rapid response deterrence against hybrid incursions.',
    theater: 'Europe'
  },
  '156': {
    numericId: '156',
    code2: 'CN',
    code3: 'CHN',
    name: 'China',
    flag: '🇨🇳',
    lat: 35.8617,
    lng: 104.1954,
    conflictStatus: 'elevated',
    tensionScore: 74,
    activeIncidents: 5,
    threatSummary: 'South China Sea maritime confrontation patrols, naval expansion, and dual-use supply chain leverage.',
    theater: 'Asia-Pacific'
  },
  '356': {
    numericId: '356',
    code2: 'IN',
    code3: 'IND',
    name: 'India',
    flag: '🇮🇳',
    lat: 20.5937,
    lng: 78.9629,
    conflictStatus: 'elevated',
    tensionScore: 58,
    activeIncidents: 4,
    threatSummary: 'Himalayan LAC boundary surveillance; Indian Ocean naval security and anti-piracy escort coordination.',
    theater: 'Asia-Pacific'
  },
  '826': {
    numericId: '826',
    code2: 'GB',
    code3: 'GBR',
    name: 'United Kingdom',
    flag: '🇬🇧',
    lat: 55.3781,
    lng: -3.436,
    conflictStatus: 'monitored',
    tensionScore: 35,
    activeIncidents: 2,
    threatSummary: 'Royal Navy North Atlantic subsea cable patrol operations; ongoing joint military aid packages.',
    theater: 'Europe'
  },
  '250': {
    numericId: '250',
    code2: 'FR',
    code3: 'FRA',
    name: 'France',
    flag: '🇫🇷',
    lat: 46.2276,
    lng: 2.2137,
    conflictStatus: 'monitored',
    tensionScore: 38,
    activeIncidents: 2,
    threatSummary: 'Strategic autonomous nuclear deterrence posture; European rapid intervention force leadership.',
    theater: 'Europe'
  },
  '392': {
    numericId: '392',
    code2: 'JP',
    code3: 'JPN',
    name: 'Japan',
    flag: '🇯🇵',
    lat: 36.2048,
    lng: 138.2529,
    conflictStatus: 'elevated',
    tensionScore: 62,
    activeIncidents: 3,
    threatSummary: 'Southwestern Nansei islands missile battery reinforcement; Aegis ballistic missile defense tracking.',
    theater: 'Asia-Pacific'
  },
  '410': {
    numericId: '410',
    code2: 'KR',
    code3: 'KOR',
    name: 'South Korea',
    flag: '🇰🇷',
    lat: 35.9078,
    lng: 127.7669,
    conflictStatus: 'elevated',
    tensionScore: 72,
    activeIncidents: 3,
    threatSummary: 'DMZ surveillance on highest alert level; joint combined arms readiness exercises with US Forces Korea.',
    theater: 'Asia-Pacific'
  },
  '792': {
    numericId: '792',
    code2: 'TR',
    code3: 'TUR',
    name: 'Turkey',
    flag: '🇹🇷',
    lat: 38.9637,
    lng: 35.2433,
    conflictStatus: 'elevated',
    tensionScore: 65,
    activeIncidents: 3,
    threatSummary: 'Black Sea maritime security and Bosporus strait surveillance under Montreux Convention.',
    theater: 'Middle East'
  },
  '682': {
    numericId: '682',
    code2: 'SA',
    code3: 'SAU',
    name: 'Saudi Arabia',
    flag: '🇸🇦',
    lat: 23.8859,
    lng: 45.0792,
    conflictStatus: 'monitored',
    tensionScore: 55,
    activeIncidents: 2,
    threatSummary: 'Air defense radar surveillance along southern perimeter and Gulf energy terminal protection.',
    theater: 'Middle East'
  },
  '586': {
    numericId: '586',
    code2: 'PK',
    code3: 'PAK',
    name: 'Pakistan',
    flag: '🇵🇰',
    lat: 30.3753,
    lng: 69.3451,
    conflictStatus: 'elevated',
    tensionScore: 70,
    activeIncidents: 3,
    threatSummary: 'Border security monitoring along western frontiers and Line of Control vigilance.',
    theater: 'Asia-Pacific'
  },
  '004': {
    numericId: '004',
    code2: 'AF',
    code3: 'AFG',
    name: 'Afghanistan',
    flag: '🇦🇫',
    lat: 33.9391,
    lng: 67.71,
    conflictStatus: 'high_tension',
    tensionScore: 79,
    activeIncidents: 3,
    threatSummary: 'Internal armed resistance flare-ups and border skirmishes with neighboring frontier guards.',
    theater: 'Asia-Pacific'
  },
  '368': {
    numericId: '368',
    code2: 'IQ',
    code3: 'IRQ',
    name: 'Iraq',
    flag: '🇮🇶',
    lat: 33.2232,
    lng: 43.6793,
    conflictStatus: 'high_tension',
    tensionScore: 78,
    activeIncidents: 4,
    threatSummary: 'Militia drone targeting of coalition outposts and airspace defense surveillance.',
    theater: 'Middle East'
  },
  '704': {
    numericId: '704',
    code2: 'VN',
    code3: 'VNM',
    name: 'Vietnam',
    flag: '🇻🇳',
    lat: 14.0583,
    lng: 108.2772,
    conflictStatus: 'monitored',
    tensionScore: 50,
    activeIncidents: 2,
    threatSummary: 'South China Sea maritime militia surveillance and island outpost logistics.',
    theater: 'Asia-Pacific'
  },
  '608': {
    numericId: '608',
    code2: 'PH',
    code3: 'PHL',
    name: 'Philippines',
    flag: '🇵🇭',
    lat: 12.8797,
    lng: 121.774,
    conflictStatus: 'high_tension',
    tensionScore: 82,
    activeIncidents: 5,
    threatSummary: 'Second Thomas Shoal and Scarborough Shoal water cannon and acoustic interception incidents.',
    theater: 'Asia-Pacific'
  },
  '246': {
    numericId: '246',
    code2: 'FI',
    code3: 'FIN',
    name: 'Finland',
    flag: '🇫🇮',
    lat: 61.9241,
    lng: 25.7482,
    conflictStatus: 'monitored',
    tensionScore: 48,
    activeIncidents: 2,
    threatSummary: 'Eastern border closure and NATO northern flank defense infrastructure hardening.',
    theater: 'Europe'
  },
  '752': {
    numericId: '752',
    code2: 'SE',
    code3: 'SWE',
    name: 'Sweden',
    flag: '🇸🇪',
    lat: 60.1282,
    lng: 18.6435,
    conflictStatus: 'monitored',
    tensionScore: 42,
    activeIncidents: 1,
    threatSummary: 'Gotland island strategic positioning and Baltic undersea sensor net operations.',
    theater: 'Europe'
  },
  '076': {
    numericId: '076',
    code2: 'BR',
    code3: 'BRA',
    name: 'Brazil',
    flag: '🇧🇷',
    lat: -14.235,
    lng: -51.9253,
    conflictStatus: 'stable',
    tensionScore: 25,
    activeIncidents: 1,
    threatSummary: 'Amazon rainforest border protection and naval patrol in South Atlantic basin.',
    theater: 'Americas'
  },
  '036': {
    numericId: '036',
    code2: 'AU',
    code3: 'AUS',
    name: 'Australia',
    flag: '🇦🇺',
    lat: -25.2744,
    lng: 133.7751,
    conflictStatus: 'monitored',
    tensionScore: 35,
    activeIncidents: 1,
    threatSummary: 'AUKUS submarine infrastructure buildout and Indo-Pacific maritime patrol deployments.',
    theater: 'Asia-Pacific'
  },
  '124': {
    numericId: '124',
    code2: 'CA',
    code3: 'CAN',
    name: 'Canada',
    flag: '🇨🇦',
    lat: 56.1304,
    lng: -106.3468,
    conflictStatus: 'stable',
    tensionScore: 20,
    activeIncidents: 1,
    threatSummary: 'NORAD modernization and Arctic maritime surveillance patrols.',
    theater: 'Americas'
  },
  '818': {
    numericId: '818',
    code2: 'EG',
    code3: 'EGY',
    name: 'Egypt',
    flag: '🇪🇬',
    lat: 26.8206,
    lng: 30.8025,
    conflictStatus: 'high_tension',
    tensionScore: 76,
    activeIncidents: 3,
    threatSummary: 'Sinai and Rafah border corridor security; Suez canal revenue drop from Red Sea attacks.',
    theater: 'Middle East'
  },
  '710': {
    numericId: '710',
    code2: 'ZA',
    code3: 'ZAF',
    name: 'South Africa',
    flag: '🇿🇦',
    lat: -30.5595,
    lng: 22.9375,
    conflictStatus: 'stable',
    tensionScore: 30,
    activeIncidents: 1,
    threatSummary: 'Cape route maritime transit monitoring for diverted global shipping.',
    theater: 'Africa'
  },
  '398': {
    numericId: '398',
    code2: 'KZ',
    code3: 'KAZ',
    name: 'Kazakhstan',
    flag: '🇰🇿',
    lat: 48.0196,
    lng: 66.9237,
    conflictStatus: 'monitored',
    tensionScore: 40,
    activeIncidents: 1,
    threatSummary: 'Caspian oil transit route security and Central Asian regional defense neutrality.',
    theater: 'Asia-Pacific'
  },
  '566': {
    numericId: '566',
    code2: 'NG',
    code3: 'NGA',
    name: 'Nigeria',
    flag: '🇳🇬',
    lat: 9.082,
    lng: 8.6753,
    conflictStatus: 'high_tension',
    tensionScore: 78,
    activeIncidents: 4,
    threatSummary: 'Boko Haram & ISWAP counter-insurgency in Lake Chad basin; Gulf of Guinea piracy patrols.',
    theater: 'Africa'
  },
  '562': {
    numericId: '562',
    code2: 'NE',
    code3: 'NER',
    name: 'Niger',
    flag: '🇳🇪',
    lat: 17.6078,
    lng: 8.0817,
    conflictStatus: 'active_war',
    tensionScore: 89,
    activeIncidents: 5,
    threatSummary: 'Alliance of Sahel States military junta operations; ongoing jihadist insurgency clashes in Tillabéri.',
    theater: 'Africa'
  },
  '854': {
    numericId: '854',
    code2: 'BF',
    code3: 'BFA',
    name: 'Burkina Faso',
    flag: '🇧🇫',
    lat: 12.2383,
    lng: -1.5616,
    conflictStatus: 'active_war',
    tensionScore: 92,
    activeIncidents: 6,
    threatSummary: 'Contested northern territory with militant factions; heavy military drone strikes across Soum province.',
    theater: 'Africa'
  },
  '434': {
    numericId: '434',
    code2: 'LY',
    code3: 'LBY',
    name: 'Libya',
    flag: '🇱🇾',
    lat: 26.3351,
    lng: 17.2283,
    conflictStatus: 'high_tension',
    tensionScore: 81,
    activeIncidents: 3,
    threatSummary: 'Dual rival government military posturing around Sirte-Jufra line; central Mediterranean migrant interception patrols.',
    theater: 'Middle East'
  },
  '012': {
    numericId: '012',
    code2: 'DZ',
    code3: 'DZA',
    name: 'Algeria',
    flag: '🇩🇿',
    lat: 28.0339,
    lng: 1.6596,
    conflictStatus: 'elevated',
    tensionScore: 60,
    activeIncidents: 2,
    threatSummary: 'Southern desert border defense against Sahel arms smuggling; Western Sahara diplomatic friction.',
    theater: 'Africa'
  },
  '504': {
    numericId: '504',
    code2: 'MA',
    code3: 'MAR',
    name: 'Morocco',
    flag: '🇲🇦',
    lat: 31.7917,
    lng: -7.0926,
    conflictStatus: 'elevated',
    tensionScore: 55,
    activeIncidents: 2,
    threatSummary: 'Western Sahara defensive berm surveillance and Strait of Gibraltar maritime surveillance.',
    theater: 'Africa'
  },
  '724': {
    numericId: '724',
    code2: 'ES',
    code3: 'ESP',
    name: 'Spain',
    flag: '🇪🇸',
    lat: 40.4637,
    lng: -3.7492,
    conflictStatus: 'monitored',
    tensionScore: 28,
    activeIncidents: 1,
    threatSummary: 'Rota naval air base NATO ballistic missile defense support and Canary Islands sea patrol.',
    theater: 'Europe'
  },
  '578': {
    numericId: '578',
    code2: 'NO',
    code3: 'NOR',
    name: 'Norway',
    flag: '🇳🇴',
    lat: 60.472,
    lng: 8.4689,
    conflictStatus: 'elevated',
    tensionScore: 50,
    activeIncidents: 2,
    threatSummary: 'High North Arctic surveillance; Barents Sea maritime patrol aircraft tracking Northern Fleet submarines.',
    theater: 'Europe'
  },
  '380': {
    numericId: '380',
    code2: 'IT',
    code3: 'ITA',
    name: 'Italy',
    flag: '🇮🇹',
    lat: 41.8719,
    lng: 12.5674,
    conflictStatus: 'monitored',
    tensionScore: 30,
    activeIncidents: 1,
    threatSummary: 'Sigonella airbase ISR drone deployments across central Mediterranean and Red Sea naval task group leadership.',
    theater: 'Europe'
  },
  '642': {
    numericId: '642',
    code2: 'RO',
    code3: 'ROU',
    name: 'Romania',
    flag: '🇷🇴',
    lat: 45.9432,
    lng: 24.9668,
    conflictStatus: 'elevated',
    tensionScore: 65,
    activeIncidents: 3,
    threatSummary: 'Danube delta drone debris interception alerts; NATO multinational battle group presence in Mihail Kogălniceanu.',
    theater: 'Europe'
  },
  '100': {
    numericId: '100',
    code2: 'BG',
    code3: 'BGR',
    name: 'Bulgaria',
    flag: '🇧🇬',
    lat: 42.7339,
    lng: 25.4858,
    conflictStatus: 'elevated',
    tensionScore: 52,
    activeIncidents: 2,
    threatSummary: 'Black Sea naval mine counter-measure task group with Romania and Turkey.',
    theater: 'Europe'
  },
  '300': {
    numericId: '300',
    code2: 'GR',
    code3: 'GRC',
    name: 'Greece',
    flag: '🇬🇷',
    lat: 39.0742,
    lng: 21.8243,
    conflictStatus: 'elevated',
    tensionScore: 54,
    activeIncidents: 2,
    threatSummary: 'Aegean airspace surveillance and Souda Bay NATO carrier strike group support logistics.',
    theater: 'Europe'
  },
  '784': {
    numericId: '784',
    code2: 'AE',
    code3: 'ARE',
    name: 'United Arab Emirates',
    flag: '🇦🇪',
    lat: 23.4241,
    lng: 53.8478,
    conflictStatus: 'monitored',
    tensionScore: 48,
    activeIncidents: 2,
    threatSummary: 'Strait of Hormuz maritime security taskforce; advanced air defense radar coverage.',
    theater: 'Middle East'
  }
};

// Extract real GeoJSON boundaries from Natural Earth dataset
export interface GeoBorderMesh {
  countryBorders: [number, number][][];
  coastlines: [number, number][][];
  countries: Array<{
    id: string;
    info?: RealCountryInfo;
    coordinates: [number, number][][];
  }>;
}

let cachedGeoMesh: GeoBorderMesh | null = null;

export function getRealWorldGeoData(): GeoBorderMesh {
  if (cachedGeoMesh) return cachedGeoMesh;

  const result: GeoBorderMesh = {
    countryBorders: [],
    coastlines: [],
    countries: []
  };

  try {
    // 1. Coastlines from Natural Earth land data
    const landMesh = topojson.mesh(
      landData as any,
      (landData as any).objects.land
    ) as any;

    if (landMesh && landMesh.coordinates) {
      if (Array.isArray(landMesh.coordinates[0]?.[0])) {
        // MultiLineString
        landMesh.coordinates.forEach((line: [number, number][]) => {
          result.coastlines.push(line);
        });
      } else {
        result.coastlines.push(landMesh.coordinates as [number, number][]);
      }
    }

    // 2. Real International Country Borders (interior borders between adjacent nations)
    const bordersMesh = topojson.mesh(
      countriesData as any,
      (countriesData as any).objects.countries,
      (a: any, b: any) => a !== b
    ) as any;

    if (bordersMesh && bordersMesh.coordinates) {
      if (Array.isArray(bordersMesh.coordinates[0]?.[0])) {
        bordersMesh.coordinates.forEach((line: [number, number][]) => {
          result.countryBorders.push(line);
        });
      } else {
        result.countryBorders.push(bordersMesh.coordinates as [number, number][]);
      }
    }

    // 3. Individual Country GeoJSON features
    const countriesFeatures = topojson.feature(
      countriesData as any,
      (countriesData as any).objects.countries
    ) as any;

    if (countriesFeatures && countriesFeatures.features) {
      countriesFeatures.features.forEach((feat: any) => {
        const idStr = String(feat.id).padStart(3, '0');
        const info = REAL_COUNTRIES_MAP[idStr] || REAL_COUNTRIES_MAP[String(feat.id)];
        const coords: [number, number][][] = [];

        if (feat.geometry) {
          if (feat.geometry.type === 'Polygon') {
            feat.geometry.coordinates.forEach((ring: [number, number][]) => {
              coords.push(ring);
            });
          } else if (feat.geometry.type === 'MultiPolygon') {
            feat.geometry.coordinates.forEach((poly: [number, number][][]) => {
              poly.forEach((ring: [number, number][]) => {
                coords.push(ring);
              });
            });
          }
        }

        result.countries.push({
          id: idStr,
          info,
          coordinates: coords
        });
      });
    }
  } catch (err) {
    console.error('Error parsing Natural Earth geo data:', err);
  }

  cachedGeoMesh = result;
  return result;
}
