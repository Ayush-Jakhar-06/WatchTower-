import {
  DollarSign,
  ShieldAlert,
  Waves,
  Droplets,
  Swords,
  AlertTriangle,
  Building2,
  Leaf,
  LucideIcon,
} from 'lucide-react';
import { EventCategory, EventSeverity, TrustTier } from '../types.js';

export interface CategoryMeta {
  name: EventCategory;
  icon: LucideIcon;
  color: string;
  bgColor: string;
  borderColor: string;
  accentHex: string;
  description: string;
}

export const CATEGORIES: Record<EventCategory, CategoryMeta> = {
  Corruption: {
    name: 'Corruption',
    icon: DollarSign,
    color: 'text-amber-400',
    bgColor: 'bg-amber-500/10',
    borderColor: 'border-amber-500/30',
    accentHex: '#f59e0b',
    description: 'Procurement fraud, bribery, embezzlement, money laundering & public fund misuse',
  },
  Crime: {
    name: 'Crime',
    icon: ShieldAlert,
    color: 'text-rose-400',
    bgColor: 'bg-rose-500/10',
    borderColor: 'border-rose-500/30',
    accentHex: '#f43f5e',
    description: 'Organized crime, major violent offenses, cyber-syndicates & illicit trafficking',
  },
  'Natural Disaster': {
    name: 'Natural Disaster',
    icon: Waves,
    color: 'text-cyan-400',
    bgColor: 'bg-cyan-500/10',
    borderColor: 'border-cyan-500/30',
    accentHex: '#06b6d4',
    description: 'Floods, earthquakes, tsunamis, cyclones, volcanic activity & severe weather',
  },
  'Water & Resource Scarcity': {
    name: 'Water & Resource Scarcity',
    icon: Droplets,
    color: 'text-sky-400',
    bgColor: 'bg-sky-500/10',
    borderColor: 'border-sky-500/30',
    accentHex: '#0284c7',
    description: 'Groundwater depletion, urban water rationing, reservoir crises & acute drought',
  },
  'Conflict & War': {
    name: 'Conflict & War',
    icon: Swords,
    color: 'text-red-500',
    bgColor: 'bg-red-500/10',
    borderColor: 'border-red-500/30',
    accentHex: '#ef4444',
    description: 'Armed hostilities, border clashes, kinetic strikes, missile and drone attacks',
  },
  'Public Safety': {
    name: 'Public Safety',
    icon: AlertTriangle,
    color: 'text-orange-400',
    bgColor: 'bg-orange-500/10',
    borderColor: 'border-orange-500/30',
    accentHex: '#f97316',
    description: 'Mass transport accidents, chemical leaks, structural collapses & civil emergencies',
  },
  'Economic & Infrastructure': {
    name: 'Economic & Infrastructure',
    icon: Building2,
    color: 'text-indigo-400',
    bgColor: 'bg-indigo-500/10',
    borderColor: 'border-indigo-500/30',
    accentHex: '#6366f1',
    description: 'Power grid blackouts, critical port halts, supply chain breakdown & bank runs',
  },
  'Health & Environment': {
    name: 'Health & Environment',
    icon: Leaf,
    color: 'text-emerald-400',
    bgColor: 'bg-emerald-500/10',
    borderColor: 'border-emerald-500/30',
    accentHex: '#10b981',
    description: 'Toxic industrial dumping, epidemic outbreaks, ecological damage & wildfire smog',
  },
};

export const ALL_CATEGORIES = Object.keys(CATEGORIES) as EventCategory[];

export function getCategoryMeta(category: string): CategoryMeta {
  return (
    CATEGORIES[category as EventCategory] || {
      name: 'Public Safety',
      icon: AlertTriangle,
      color: 'text-slate-400',
      bgColor: 'bg-slate-500/10',
      borderColor: 'border-slate-500/30',
      accentHex: '#94a3b8',
      description: 'General intelligence notice',
    }
  );
}

export function getSeverityBadge(severity: EventSeverity): {
  label: string;
  className: string;
  dotColor: string;
} {
  switch (severity) {
    case 'critical':
      return {
        label: 'CRITICAL',
        className: 'bg-red-500/15 text-red-400 border border-red-500/40 animate-pulse',
        dotColor: 'bg-red-500',
      };
    case 'high':
      return {
        label: 'HIGH',
        className: 'bg-orange-500/15 text-orange-400 border border-orange-500/30',
        dotColor: 'bg-orange-500',
      };
    case 'medium':
      return {
        label: 'MODERATE',
        className: 'bg-amber-500/15 text-amber-400 border border-amber-500/30',
        dotColor: 'bg-amber-500',
      };
    case 'low':
    default:
      return {
        label: 'LOW',
        className: 'bg-slate-500/15 text-slate-300 border border-slate-500/30',
        dotColor: 'bg-slate-400',
      };
  }
}

export function getTrustTierBadge(tier: TrustTier): {
  label: string;
  className: string;
  border: string;
} {
  switch (tier) {
    case 'Virtuoso':
      return {
        label: 'Virtuoso Reporter (171-200)',
        className: 'bg-purple-500/20 text-purple-300 border-purple-500/50',
        border: 'border-purple-500',
      };
    case 'Veteran':
      return {
        label: 'Veteran Reporter (51-170)',
        className: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50',
        border: 'border-cyan-500',
      };
    case 'Rookie':
    default:
      return {
        label: 'Rookie Reporter (0-50)',
        className: 'bg-slate-500/20 text-slate-300 border-slate-500/40',
        border: 'border-slate-500',
      };
  }
}
