export type UserRole = 'guest' | 'user' | 'field-reporter' | 'admin';

export type EventCategory =
  | 'Conflict & War'
  | 'Corruption'
  | 'Crime'
  | 'Natural Disaster'
  | 'Water & Resource Scarcity'
  | 'Public Safety'
  | 'Economic & Infrastructure'
  | 'Health & Environment';

export type EventSeverity = 'low' | 'medium' | 'high' | 'critical';

export type EventStatus =
  | 'draft'
  | 'submitted'
  | 'ai_checked'
  | 'under_review'
  | 'approved'
  | 'published'
  | 'rejected'
  | 'confirmed_false';

export type TrustTier = 'Rookie' | 'Veteran' | 'Virtuoso';

export interface ReporterProfile {
  anonymousId: string;
  pseudonym: string;
  trustScore: number;
  tier: TrustTier;
  approvedReportsCount: number;
  rejectedReportsCount?: number;
  falseReportsCount: number;
  totalSubmitted: number;
  joinedDate: string;
}

export interface User {
  id: string;
  name: string;
  codeName?: string;
  designation?: string;
  email: string;
  role: UserRole;
  createdAt: string;
  reporterProfile?: ReporterProfile;
}

export interface EventLocation {
  country: string;
  countryCode?: string;
  state: string;
  city: string;
  description: string;
  lat: number;
  lng: number;
}

export interface EventSource {
  title: string;
  url?: string;
  publisher?: string;
}

export interface AiAnalysis {
  suggestedCategory: EventCategory;
  suggestedSubcategory: string;
  suggestedTags: string[];
  executiveSummary: string;
  riskLevel: 'low' | 'moderate' | 'high' | 'extreme';
  sensitivityFlags: string[];
  duplicateSignals: string[];
  confidence: number;
  rawAiAssessment: string;
}

export interface TrustMetrics {
  upvotes: number;
  downvotes: number;
  userVotes: Record<string, 'up' | 'down'>;
  netTrustScore: number;
  verificationBadge: 'Verified' | 'Community High-Trust' | 'Under Investigation' | 'Unverified';
}

export interface AuditLogEntry {
  id: string;
  eventId?: string;
  action: string;
  actorRole: UserRole;
  actorName?: string;
  actorId?: string;
  targetReporterId?: string;
  scoreChange?: number;
  reason?: string;
  timestamp: string;
}

export interface GlobalEvent {
  id: string;
  title: string;
  summary: string;
  description: string;
  category: EventCategory;
  subcategory: string;
  tags: string[];
  location: EventLocation;
  eventDate: string;
  submissionDate: string;
  severity: EventSeverity;
  status: EventStatus;
  isHotAlert: boolean;
  hotScore: number;
  images: string[];
  sources: EventSource[];
  reporterStatement: string;
  reporterId?: string;
  anonymousReporter: {
    anonymousId: string;
    pseudonym: string;
    tier: TrustTier;
  };
  aiAnalysis?: AiAnalysis;
  trustMetrics: TrustMetrics;
  rejectionReason?: string;
  isRejected?: boolean;
  createdAt: string;
  updatedAt: string;
  countryFlag?: string;
  isNewsIntel?: boolean;
  videoUrl?: string;
  sourceUrl?: string;
  clusterCount?: number;
}

export interface ReporterScoreHistory {
  id: string;
  reporterId: string;
  eventId?: string;
  oldScore: number;
  newScore: number;
  changeAmount: number;
  reason: string;
  actor: string;
  timestamp: string;
}

export type ConflictStatus = 'active_war' | 'high_tension' | 'elevated' | 'monitored' | 'peaceful';

export interface CountryData {
  id: string;
  code: string;
  name: string;
  flag: string;
  lat: number;
  lng: number;
  conflictStatus: ConflictStatus;
  tensionScore: number; // 0 - 100
  activeIncidents: number;
  threatSummary: string;
  polygonRings?: [number, number][][]; // [lng, lat] coordinates
  allies?: string[];
  theater: 'Europe' | 'Middle East' | 'Asia-Pacific' | 'Africa' | 'Americas' | 'Global';
}

export interface PredictionMarketItem {
  id: string;
  title: string;
  category: 'MIL' | 'GEOPOLITICS' | 'ENERGY' | 'DEFENSE';
  totalVotes: number;
  closingDateText: string;
  yesPercentage: number;
  noPercentage: number;
  userVoted?: 'yes' | 'no';
  tags: string[];
}

export interface MarketAsset {
  symbol: string;
  name: string;
  region: 'US' | 'EU' | 'IL' | 'TW' | 'GLOBAL';
  price: string;
  changePercent: number; // e.g. +0.84 or -1.20
  type: 'defense_stock' | 'commodity';
  currency: string;
  trend: 'up' | 'down';
}

export interface LiveTickerItem {
  id: string;
  text: string;
  flag?: string;
  timeAgo: string;
  isUrgent?: boolean;
  country?: string;
}
