import fs from 'fs';
import path from 'path';
import {
  GlobalEvent,
  User,
  ReporterScoreHistory,
  AuditLogEntry,
  TrustTier,
  EventCategory,
  EventSeverity,
} from '../src/types.js';
import { INITIAL_USERS, INITIAL_EVENTS } from '../src/data/initialEvents.js';

// Haversine distance calculator in KM
export function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

// Compute tier based on finalized 0-200 boundaries:
// Rookie: 0 - 50
// Veteran: 51 - 170
// Virtuoso: 171 - 200
export function computeTrustTier(score: number): TrustTier {
  if (score <= 50) return 'Rookie';
  if (score <= 170) return 'Veteran';
  return 'Virtuoso';
}

const STORAGE_PATH = path.join(process.cwd(), 'data_storage.json');

const defaultAuditLogs: AuditLogEntry[] = [
  {
    id: 'audit-1',
    eventId: 'evt-1',
    action: 'REPORT_APPROVED',
    actorRole: 'admin',
    actorName: 'Director (Command Lead)',
    actorId: 'user-admin-1',
    targetReporterId: 'user-reporter-2',
    scoreChange: 10,
    reason: 'Verified documentary evidence submitted for public infrastructure procurement scam',
    timestamp: '2026-08-20T14:32:00.000Z',
  },
  {
    id: 'audit-2',
    eventId: 'evt-4',
    action: 'HOT_ALERT_ACTIVATED',
    actorRole: 'admin',
    actorName: 'Director (Command Lead)',
    actorId: 'user-admin-1',
    reason: 'Severe flash flooding threatening regional hydroelectric dam and 45,000 residents',
    timestamp: '2026-08-22T08:15:00.000Z',
  },
];

const defaultReporterScoreHistories: ReporterScoreHistory[] = [
  {
    id: 'hist-1',
    reporterId: 'user-reporter-2',
    eventId: 'evt-1',
    oldScore: 110,
    newScore: 120,
    changeAmount: 10,
    reason: 'Milestone reached: 3 consecutive verified field reports approved (+10 Trust)',
    actor: 'System / Admin Moderation',
    timestamp: '2026-08-20T14:32:00.000Z',
  },
];

const defaultUserPasswords: Record<string, string> = {
  'ayush@gmail.com': 'Ayush@060305',
  'ayush@gamil.com': 'Ayush@060305',
  'admin@watchtower.io': 'Ayush@060305',
  'admin@watchtower.org': 'Ayush@060305',
  'admin': 'Ayush@060305',
  'echohawk@watchtower.org': 'Watchtower@2026',
  'echohawk': 'Watchtower@2026',
  'echohawk_92': 'Watchtower@2026',
  'elena.reporter@watchtower.org': 'Watchtower@2026',
  'vigilantoasis@watchtower.org': 'Watchtower@2026',
  'vigilantoasis': 'Watchtower@2026',
  'tariq.reporter@watchtower.org': 'Watchtower@2026',
  'geosentinel@fieldnet.io': 'Watchtower@2026',
  'sarah.jenkins@fieldnet.io': 'Watchtower@2026',
  'observer44@watchtower.io': 'Watchtower@2026',
  'test01@gmail.com': 'test01',
  'test01': 'test01',
  'test_citizen_01': 'test01',
  'test02@gmail.com': 'test02',
  'test02': 'test02',
  'test_citizen02': 'test02',
  'testcitizen01@gmail.com': 'testcitizen',
  'testcitizen@gmail.com': 'testcitizen',
  'testcitizen': 'testcitizen',
  'test': 'testcitizen',
};

// Ensure Director Admin user
const defaultAdminUser: User = {
  id: 'user-admin-ayush',
  name: 'Ayush (Director)',
  codeName: 'Command_Lead',
  designation: 'Chief Director',
  email: 'Ayush@gmail.com',
  role: 'admin',
  createdAt: '2026-01-01T08:00:00.000Z',
  reporterProfile: {
    anonymousId: 'DIR-001',
    pseudonym: 'Command_Lead',
    trustScore: 200,
    tier: 'Virtuoso',
    approvedReportsCount: 42,
    rejectedReportsCount: 0,
    falseReportsCount: 0,
    totalSubmitted: 42,
    joinedDate: '2026-01-01T08:00:00.000Z',
  },
};

// In-Memory Database instances
export const users: User[] = [];
export const events: GlobalEvent[] = [];
export const auditLogs: AuditLogEntry[] = [];
export const reporterScoreHistories: ReporterScoreHistory[] = [];
export const userPasswords: Record<string, string> = { ...defaultUserPasswords };

// Helper to index passwords across multiple user identifiers
export function indexUserPassword(u: User, password?: string): void {
  if (!password) return;
  const p = password.trim();
  if (u.email) {
    const eNorm = u.email.trim().toLowerCase();
    userPasswords[eNorm] = p;
    if (eNorm.includes('@')) {
      userPasswords[eNorm.split('@')[0]] = p;
    }
  }
  if (u.codeName) {
    userPasswords[u.codeName.trim().toLowerCase()] = p;
    userPasswords[u.codeName.trim().toLowerCase().replace(/[_\s-]/g, '')] = p;
  }
  if (u.name) {
    userPasswords[u.name.trim().toLowerCase()] = p;
  }
  if (u.id) {
    userPasswords[u.id.trim()] = p;
  }
  if (u.reporterProfile?.anonymousId) {
    userPasswords[u.reporterProfile.anonymousId.trim().toLowerCase()] = p;
  }
  if (u.reporterProfile?.pseudonym) {
    userPasswords[u.reporterProfile.pseudonym.trim().toLowerCase()] = p;
  }
}

// Load storage from disk or initialize
export function loadStorage(): void {
  try {
    if (fs.existsSync(STORAGE_PATH)) {
      const raw = fs.readFileSync(STORAGE_PATH, 'utf-8');
      const data = JSON.parse(raw);

      users.length = 0;
      if (Array.isArray(data.users) && data.users.length > 0) {
        users.push(...data.users);
      } else {
        users.push(...JSON.parse(JSON.stringify(INITIAL_USERS)));
      }

      events.length = 0;
      if (Array.isArray(data.events) && data.events.length > 0) {
        events.push(...data.events);
      } else {
        events.push(...JSON.parse(JSON.stringify(INITIAL_EVENTS)));
      }

      auditLogs.length = 0;
      if (Array.isArray(data.auditLogs)) {
        auditLogs.push(...data.auditLogs);
      } else {
        auditLogs.push(...defaultAuditLogs);
      }

      reporterScoreHistories.length = 0;
      if (Array.isArray(data.reporterScoreHistories)) {
        reporterScoreHistories.push(...data.reporterScoreHistories);
      } else {
        reporterScoreHistories.push(...defaultReporterScoreHistories);
      }

      Object.assign(userPasswords, defaultUserPasswords);
      if (data.userPasswords && typeof data.userPasswords === 'object') {
        Object.assign(userPasswords, data.userPasswords);
      }
    } else {
      users.length = 0;
      users.push(...JSON.parse(JSON.stringify(INITIAL_USERS)));
      events.length = 0;
      events.push(...JSON.parse(JSON.stringify(INITIAL_EVENTS)));
      auditLogs.length = 0;
      auditLogs.push(...defaultAuditLogs);
      reporterScoreHistories.length = 0;
      reporterScoreHistories.push(...defaultReporterScoreHistories);
      Object.assign(userPasswords, defaultUserPasswords);
    }
  } catch (err) {
    console.warn('Could not read data_storage.json, falling back to seed data', err);
    users.length = 0;
    users.push(...JSON.parse(JSON.stringify(INITIAL_USERS)));
    events.length = 0;
    events.push(...JSON.parse(JSON.stringify(INITIAL_EVENTS)));
    auditLogs.length = 0;
    auditLogs.push(...defaultAuditLogs);
    reporterScoreHistories.length = 0;
    reporterScoreHistories.push(...defaultReporterScoreHistories);
    Object.assign(userPasswords, defaultUserPasswords);
  }

  // Ensure Director Ayush is always present in users
  if (!users.some((u) => u.email?.toLowerCase() === 'ayush@gmail.com' || u.id === 'user-admin-ayush')) {
    users.unshift(defaultAdminUser);
  }
  userPasswords['ayush@gmail.com'] = 'Ayush@060305';
  userPasswords['ayush@gamil.com'] = 'Ayush@060305';
  userPasswords['admin'] = 'Ayush@060305';

  // Cross-index all passwords for all loaded users so any identifier succeeds
  for (const u of users) {
    const pw =
      (u.email ? userPasswords[u.email.toLowerCase()] : undefined) ||
      (u.codeName ? userPasswords[u.codeName.toLowerCase()] : undefined) ||
      (u.id ? userPasswords[u.id] : undefined) ||
      (u.email && u.email.includes('@') ? userPasswords[u.email.toLowerCase().split('@')[0]] : undefined);
    if (pw) {
      indexUserPassword(u, pw);
    }
  }
}

// Save storage to disk
export function saveStorage(): void {
  try {
    const data = {
      users,
      events,
      auditLogs,
      reporterScoreHistories,
      userPasswords,
      updatedAt: new Date().toISOString(),
    };
    fs.writeFileSync(STORAGE_PATH, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.warn('Failed to write data_storage.json', err);
  }
}

// Initial load
loadStorage();

