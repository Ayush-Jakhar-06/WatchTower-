import express, { Request, Response } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import {
  users,
  events,
  auditLogs,
  reporterScoreHistories,
  userPasswords,
  computeTrustTier,
  calculateDistanceKm,
  saveStorage,
  loadStorage,
  indexUserPassword,
} from './server/dataStore.js';
import { analyzeEventReport } from './server/gemini.js';
import { GlobalEvent, User, AuditLogEntry, EventCategory, EventSeverity } from './src/types.js';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // CORS middleware for iframe and multi-origin safety
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, x-user-data');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    next();
  });

  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // Admin permanent credentials and accepted email aliases
  const ADMIN_EMAIL = 'Ayush@gmail.com';
  const ADMIN_PASSWORD = 'Ayush@060305';
  const ADMIN_EMAILS = [
    'ayush@gmail.com',
    'ayush@gamil.com', // Common user typo handling
    'ingen8529@gmail.com', // User primary email alias
    'admin@watchtower.io',
    'admin@watchtower.org',
    'admin@gmail.com',
    'admin',
    'director',
    'command_lead',
  ];

  const isAdminEmail = (emailStr?: string): boolean => {
    if (!emailStr) return false;
    const norm = emailStr.trim().toLowerCase();
    return ADMIN_EMAILS.includes(norm) || norm.startsWith('ayush@') || norm === 'admin';
  };

  const isMatchingAdminPassword = (passStr?: string): boolean => {
    if (!passStr) return false;
    const trimmed = passStr.trim();
    return trimmed === ADMIN_PASSWORD || trimmed.toLowerCase() === ADMIN_PASSWORD.toLowerCase();
  };

  // Robust session authorization helper that supports Bearer token, header user sync, and direct ID matching
  const authenticateUser = (req: Request): User | null => {
    const authHeader = req.headers.authorization;
    let token = '';
    if (authHeader) {
      token = authHeader.replace('Bearer ', '').trim();
    }

    // 1. If token matches admin token or admin email directly
    if (token === 'user-admin-ayush' || isAdminEmail(token)) {
      const admin = users.find((u) => u.role === 'admin' || u.id === 'user-admin-ayush');
      if (admin) return admin;
    }

    // 2. Direct match by id, email, or pseudonym in current users list
    if (token) {
      const found = users.find(
        (u) =>
          u.id === token ||
          (u.email && u.email.toLowerCase() === token.toLowerCase()) ||
          (u.codeName && u.codeName.toLowerCase() === token.toLowerCase())
      );
      if (found) return found;
    }

    // 3. Check X-User-Data header (from client localStorage session)
    const rawUserData = req.headers['x-user-data'];
    if (rawUserData && typeof rawUserData === 'string') {
      try {
        const parsed = JSON.parse(decodeURIComponent(rawUserData)) as User;
        if (parsed && parsed.id && (parsed.name || parsed.codeName)) {
          let existing = users.find(
            (u) =>
              u.id === parsed.id ||
              (u.email && parsed.email && u.email.toLowerCase() === parsed.email.toLowerCase())
          );
          if (!existing) {
            users.unshift(parsed);
            saveStorage();
            return parsed;
          }
          return existing;
        }
      } catch (err) {
        // Continue fallback
      }
    }

    // 4. Check req.body.reporterUser fallback
    if (req.body && req.body.reporterUser && req.body.reporterUser.id) {
      const u = req.body.reporterUser as User;
      let existing = users.find(
        (item) =>
          item.id === u.id ||
          (item.email && u.email && item.email.toLowerCase() === u.email.toLowerCase())
      );
      if (!existing) {
        users.unshift(u);
        saveStorage();
        return u;
      }
      return existing;
    }

    return null;
  };

  // Ensure Director admin user exists
  if (!users.some((u) => u.role === 'admin')) {
    users.unshift({
      id: 'user-admin-ayush',
      name: 'Ayush (Director)',
      codeName: 'Command_Lead',
      designation: 'Chief Director',
      email: ADMIN_EMAIL,
      role: 'admin',
      createdAt: '2026-01-01T08:00:00.000Z',
      reporterProfile: {
        anonymousId: 'DIR-001',
        pseudonym: 'Command_Lead',
        trustScore: 200,
        tier: 'Virtuoso',
        approvedReportsCount: 42,
        rejectedReportsCount: 0,
        falseReportsCount: 0,
        totalSubmitted: 42,
        joinedDate: '2026-01-01T08:00:00.000Z',
      },
    });
    saveStorage();
  }

  // ----------------------------------------------------
  // HEALTH CHECK
  // ----------------------------------------------------
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({
      success: true,
      message: 'EventGrid Intelligence Backend Running',
      eventsCount: events.length,
      usersCount: users.length,
      environment: process.env.NODE_ENV || 'development',
      timestamp: new Date().toISOString(),
    });
  });

  // ----------------------------------------------------
  // AUTHENTICATION ROUTES & HELPER
  // ----------------------------------------------------
  function findUserByIdentifier(identifier: string): User | undefined {
    if (!identifier) return undefined;
    const raw = identifier.trim();
    const norm = raw.toLowerCase();
    const normNoSeparators = norm.replace(/[_\s-]/g, '');

    return users.find((u) => {
      if (!u) return false;
      const uEmail = (u.email || '').trim().toLowerCase();
      const uCodeName = (u.codeName || '').trim().toLowerCase();
      const uName = (u.name || '').trim().toLowerCase();
      const uPseudonym = (u.reporterProfile?.pseudonym || '').trim().toLowerCase();
      const uAnonId = (u.reporterProfile?.anonymousId || '').trim().toLowerCase();
      const uId = (u.id || '').trim();

      // 1. Direct matches
      if (uEmail && uEmail === norm) return true;
      if (uCodeName && uCodeName === norm) return true;
      if (uName && uName === norm) return true;
      if (uPseudonym && uPseudonym === norm) return true;
      if (uAnonId && uAnonId === norm) return true;
      if (uId && (uId === raw || uId.toLowerCase() === norm)) return true;

      // 2. Email prefix match (e.g. "test01" or "echohawk" for "test01@gmail.com")
      if (uEmail && uEmail.includes('@')) {
        const prefix = uEmail.split('@')[0];
        if (prefix === norm) return true;
      }

      // 3. Normalized without hyphens, underscores, or spaces
      if (uCodeName && uCodeName.replace(/[_\s-]/g, '') === normNoSeparators) return true;
      if (uName && uName.replace(/[_\s-]/g, '') === normNoSeparators) return true;
      if (uPseudonym && uPseudonym.replace(/[_\s-]/g, '') === normNoSeparators) return true;

      return false;
    });
  }

  app.post('/api/auth/register', (req: Request, res: Response) => {
    const { codeName, designation, email, password, role, name, pseudonym } = req.body;
    const finalCodeName = (codeName || pseudonym || name || '').trim();
    if (!finalCodeName || !email) {
      return res.status(400).json({ error: 'Code name and email are required.' });
    }

    const finalDesignation = (
      designation || (role === 'user' ? 'Tactical Observer' : 'Field Reporter')
    ).trim();

    const emailNorm = email.trim().toLowerCase();

    // Prevent overriding admin email
    if (isAdminEmail(emailNorm)) {
      return res.status(400).json({
        error: 'Ayush@gmail.com is exclusively reserved for the Chief System Administrator. Please use Admin Sign In.',
      });
    }

    // Check if user already exists
    const existing = users.find((u) => u.email && u.email.toLowerCase() === emailNorm);
    if (existing) {
      return res.status(409).json({
        error: 'An account with this email address already exists. Please sign in.',
      });
    }

    const userRole = role === 'field-reporter' || role === 'reporter' ? 'field-reporter' : 'user';
    const newUser: User = {
      id: `user-${Date.now()}`,
      name: finalCodeName,
      codeName: finalCodeName,
      designation: finalDesignation,
      email: email.trim(),
      role: userRole,
      createdAt: new Date().toISOString(),
    };

    const code = Math.floor(1000 + Math.random() * 9000);
    const anonId = userRole === 'field-reporter' ? `REP-${code}` : `USR-${code}`;
    newUser.reporterProfile = {
      anonymousId: anonId,
      pseudonym: finalCodeName,
      trustScore: 0, // All new registering users/reporters start with score of 0
      tier: 'Rookie',
      approvedReportsCount: 0,
      rejectedReportsCount: 0,
      falseReportsCount: 0,
      totalSubmitted: 0,
      joinedDate: new Date().toISOString(),
    };

    if (password) {
      indexUserPassword(newUser, password);
    }

    users.push(newUser);
    saveStorage();

    res.status(201).json({
      success: true,
      token: newUser.id,
      user: newUser,
    });
  });

  app.post('/api/auth/login', (req: Request, res: Response) => {
    const { email, password } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email, Code Name, or Operator ID is required.' });
    }

    const emailNorm = email.trim().toLowerCase();

    // Admin authentication path (handles both Ayush@gmail.com and common typos like ayush@gamil.com)
    if (isAdminEmail(emailNorm)) {
      if (!isMatchingAdminPassword(password)) {
        return res.status(401).json({
          error: 'Invalid Administrator password. Please check your credentials.',
        });
      }

      let adminUser = users.find((u) => u.role === 'admin');
      if (!adminUser) {
        adminUser = {
          id: 'user-admin-ayush',
          name: 'Ayush (Director)',
          codeName: 'Command_Lead',
          designation: 'Chief Director',
          email: ADMIN_EMAIL,
          role: 'admin',
          createdAt: '2026-01-01T08:00:00.000Z',
          reporterProfile: {
            anonymousId: 'DIR-001',
            pseudonym: 'Command_Lead',
            trustScore: 200,
            tier: 'Virtuoso',
            approvedReportsCount: 42,
            rejectedReportsCount: 0,
            falseReportsCount: 0,
            totalSubmitted: 42,
            joinedDate: '2026-01-01T08:00:00.000Z',
          },
        };
        users.unshift(adminUser);
        saveStorage();
      }

      return res.json({
        success: true,
        token: adminUser.id,
        user: adminUser,
        isAdmin: true,
      });
    }

    // Standard user login: search by email, codeName, name, anonymousId, ID, email prefix
    let user = findUserByIdentifier(email);

    // If not found in current memory, reload from storage disk in case written by parallel process/tab
    if (!user) {
      loadStorage();
      user = findUserByIdentifier(email);
    }

    if (!user) {
      // Check if this was an attempt to log in with an admin password
      if (isMatchingAdminPassword(password)) {
        const adminUser = users.find((u) => u.role === 'admin');
        if (adminUser) {
          return res.json({
            success: true,
            token: adminUser.id,
            user: adminUser,
            isAdmin: true,
          });
        }
      }

      return res.status(404).json({
        error: 'No registered account found with this email or code name. Please check your credentials or switch to Register.',
      });
    }

    // Comprehensive password verification across all user identifier aliases
    const enteredPassword = password ? password.trim() : '';
    const storedPassword =
      (user.email ? userPasswords[user.email.toLowerCase()] : undefined) ||
      (user.codeName ? userPasswords[user.codeName.toLowerCase()] : undefined) ||
      (user.name ? userPasswords[user.name.toLowerCase()] : undefined) ||
      (user.reporterProfile?.anonymousId ? userPasswords[user.reporterProfile.anonymousId.toLowerCase()] : undefined) ||
      userPasswords[user.id] ||
      userPasswords[emailNorm] ||
      (user.email && user.email.includes('@') ? userPasswords[user.email.toLowerCase().split('@')[0]] : undefined);

    if (storedPassword && enteredPassword && storedPassword !== enteredPassword) {
      return res.status(401).json({ error: 'Incorrect password entered. Please verify your credentials.' });
    }

    if (!user.reporterProfile && user.role !== 'admin') {
      const code = Math.floor(1000 + Math.random() * 9000);
      user.reporterProfile = {
        anonymousId: user.role === 'field-reporter' ? `REP-${code}` : `USR-${code}`,
        pseudonym: user.codeName || user.name,
        trustScore: 0,
        tier: 'Rookie',
        approvedReportsCount: 0,
        rejectedReportsCount: 0,
        falseReportsCount: 0,
        totalSubmitted: 0,
        joinedDate: user.createdAt || new Date().toISOString(),
      };
      saveStorage();
    }

    res.json({
      success: true,
      token: user.id,
      user,
    });
  });

  app.get('/api/auth/me', (req: Request, res: Response) => {
    const user = authenticateUser(req);
    if (!user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    res.json({ success: true, user });
  });

  // POST /api/auth/sync - Seamlessly sync client session user with backend
  app.post('/api/auth/sync', (req: Request, res: Response) => {
    const clientUser = req.body.user as User;
    if (!clientUser || !clientUser.id) {
      return res.status(400).json({ error: 'Invalid user object.' });
    }

    let existing = users.find(
      (u) =>
        u.id === clientUser.id ||
        (u.email && clientUser.email && u.email.toLowerCase() === clientUser.email.toLowerCase())
    );

    if (!existing) {
      users.unshift(clientUser);
      saveStorage();
      existing = clientUser;
    } else {
      if (clientUser.reporterProfile && !existing.reporterProfile) {
        existing.reporterProfile = clientUser.reporterProfile;
        saveStorage();
      }
    }

    res.json({ success: true, user: existing });
  });

  // GET /api/reporter/my-reports - Fetch reports submitted by current reporter/user
  app.get('/api/reporter/my-reports', (req: Request, res: Response) => {
    const user = authenticateUser(req);
    if (!user) {
      return res.status(401).json({ error: 'Authentication required to view your reports.' });
    }

    const myEvents = events.filter((e) => {
      const isDirectId = e.reporterId === user.id;
      const isEmail = Boolean(user.email && e.reporterId === user.email);
      const isPseudonym = Boolean(
        e.anonymousReporter &&
          (e.anonymousReporter.pseudonym === user.codeName ||
            e.anonymousReporter.pseudonym === user.name ||
            (user.reporterProfile &&
              e.anonymousReporter.anonymousId === user.reporterProfile.anonymousId))
      );
      return isDirectId || isEmail || isPseudonym;
    });

    res.json({
      success: true,
      count: myEvents.length,
      events: myEvents,
    });
  });

  // ----------------------------------------------------
  // EVENT ROUTES
  // ----------------------------------------------------
  // GET /api/events - List events with filtering
  app.get('/api/events', (req: Request, res: Response) => {
    const user = authenticateUser(req);
    const isAdmin = user?.role === 'admin';

    const { category, search, severity, isHot, status, limit } = req.query;

    let filtered = [...events];

    // Status filter: guests and normal users only see 'published' events by default unless status is specified and allowed
    if (!isAdmin) {
      filtered = filtered.filter((e) => e.status === 'published');
    } else if (status) {
      filtered = filtered.filter((e) => e.status === String(status));
    }

    if (category && category !== 'All') {
      filtered = filtered.filter(
        (e) => e.category.toLowerCase() === String(category).toLowerCase()
      );
    }

    if (severity && severity !== 'All') {
      filtered = filtered.filter((e) => e.severity === String(severity));
    }

    if (isHot === 'true') {
      filtered = filtered.filter((e) => e.isHotAlert);
    }

    if (search && typeof search === 'string') {
      const q = search.toLowerCase().trim();
      filtered = filtered.filter(
        (e) =>
          e.title.toLowerCase().includes(q) ||
          e.summary.toLowerCase().includes(q) ||
          e.description.toLowerCase().includes(q) ||
          e.subcategory.toLowerCase().includes(q) ||
          e.location.country.toLowerCase().includes(q) ||
          e.location.city.toLowerCase().includes(q) ||
          e.tags.some((t) => t.toLowerCase().includes(q))
      );
    }

    // Sort by hot score / recency
    filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    // Sanitize reporter private ID for non-admins, but preserve for author so their dashboard displays correctly
    const sanitized = filtered.map((e) => {
      if (isAdmin || (user && e.reporterId === user.id)) return e;
      const { reporterId, ...publicSafe } = e;
      return publicSafe;
    });

    res.json({
      success: true,
      count: sanitized.length,
      events: limit ? sanitized.slice(0, Number(limit)) : sanitized,
    });
  });

  // GET /api/reporter/my-reports - All reports submitted by the logged-in user or field reporter
  app.get('/api/reporter/my-reports', (req: Request, res: Response) => {
    const user = authenticateUser(req);
    if (!user) {
      return res.status(401).json({ error: 'Authentication required.' });
    }

    const myEvents = events.filter((e) => e.reporterId === user.id);
    const approved = myEvents.filter((e) => e.status === 'published');
    const rejected = myEvents.filter((e) => e.status === 'rejected' || e.status === 'confirmed_false');
    const pending = myEvents.filter(
      (e) => e.status === 'ai_checked' || e.status === 'under_review' || e.status === 'submitted'
    );

    res.json({
      success: true,
      count: myEvents.length,
      events: myEvents,
      stats: {
        total: myEvents.length,
        approvedCount: approved.length,
        rejectedCount: rejected.length,
        pendingCount: pending.length,
      },
      reporterProfile: user.reporterProfile || {
        anonymousId: `USR-${user.id.slice(-4)}`,
        pseudonym: user.codeName || user.name,
        trustScore: 0,
        tier: 'Rookie',
        approvedReportsCount: approved.length,
        rejectedReportsCount: rejected.length,
        falseReportsCount: 0,
        totalSubmitted: myEvents.length,
        joinedDate: user.createdAt,
      },
    });
  });

  // GET /api/events/nearby - Find events near given coordinates
  app.get('/api/events/nearby', (req: Request, res: Response) => {
    const { lat, lng, radiusKm } = req.query;
    if (!lat || !lng) {
      return res.status(400).json({ error: 'Latitude and Longitude are required.' });
    }

    const userLat = parseFloat(String(lat));
    const userLng = parseFloat(String(lng));
    const maxRadius = radiusKm ? parseFloat(String(radiusKm)) : 2500;

    const user = authenticateUser(req);
    const isAdmin = user?.role === 'admin';

    const nearby = events
      .filter((e) => isAdmin || e.status === 'published')
      .map((e) => {
        const distance = calculateDistanceKm(userLat, userLng, e.location.lat, e.location.lng);
        return {
          ...e,
          distanceKm: distance,
        };
      })
      .filter((e) => e.distanceKm <= maxRadius)
      .sort((a, b) => a.distanceKm - b.distanceKm);

    // Sanitize
    const sanitized = nearby.map((e) => {
      if (isAdmin) return e;
      const { reporterId, ...publicSafe } = e;
      return publicSafe;
    });

    res.json({
      success: true,
      userLocation: { lat: userLat, lng: userLng },
      radiusKm: maxRadius,
      count: sanitized.length,
      events: sanitized,
    });
  });

  // GET /api/events/:id - Single event detail
  app.get('/api/events/:id', (req: Request, res: Response) => {
    const user = authenticateUser(req);
    const isAdmin = user?.role === 'admin';

    const event = events.find((e) => e.id === req.params.id);
    if (!event) {
      return res.status(404).json({ error: 'Event not found.' });
    }

    if (!isAdmin && event.status !== 'published') {
      // If reporter is viewing their own pending report, allow
      if (user && event.reporterId === user.id) {
        return res.json({ success: true, event });
      }
      return res.status(403).json({ error: 'Event is pending moderation.' });
    }

    if (!isAdmin) {
      const { reporterId, ...publicSafe } = event;
      return res.json({ success: true, event: publicSafe });
    }

    res.json({ success: true, event });
  });

  // POST /api/events/ai-precheck - Test AI Precheck before submission
  app.post('/api/events/ai-precheck', async (req: Request, res: Response) => {
    const { title, description, category, subcategory, country, city, statement } = req.body;
    if (!title || !description) {
      return res.status(400).json({ error: 'Title and description are required for AI analysis.' });
    }

    try {
      const existingPreviews = events.map((e) => ({
        title: e.title,
        category: e.category,
        location: `${e.location.city}, ${e.location.country}`,
      }));

      const analysis = await analyzeEventReport({
        title,
        description,
        category,
        subcategory,
        country,
        city,
        statement,
        existingEvents: existingPreviews,
      });

      res.json({ success: true, analysis });
    } catch (err: any) {
      res.status(500).json({ error: 'AI Precheck failed', details: err.message });
    }
  });

  // POST /api/events/submit - Field Reporter & Registered User Structured Submission
  app.post('/api/events/submit', async (req: Request, res: Response) => {
    let user = authenticateUser(req);
    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required. Guests are not permitted to submit reports. Please sign in or register.',
      });
    }

    const {
      title,
      description,
      category,
      subcategory,
      tags,
      location,
      eventDate,
      severity,
      images,
      sources,
      reporterStatement,
    } = req.body;

    if (!title || !description || !category || !location?.lat || !location?.lng || !location?.country) {
      return res.status(400).json({
        error: 'Missing required fields: title, description, category, coordinates, and country are required.',
      });
    }

    // Trigger AI pre-check with Gemini
    const existingPreviews = events.map((e) => ({
      title: e.title,
      category: e.category,
      location: `${e.location.city}, ${e.location.country}`,
    }));

    const aiAnalysis = await analyzeEventReport({
      title,
      description,
      category,
      subcategory,
      country: location.country,
      city: location.city,
      statement: reporterStatement,
      existingEvents: existingPreviews,
    });

    const reporterProfile = user.reporterProfile || {
      anonymousId: `REP-${Math.floor(1000 + Math.random() * 9000)}`,
      pseudonym: user.codeName || user.name || 'Field_Observer',
      trustScore: 0,
      tier: 'Rookie' as const,
      approvedReportsCount: 0,
      rejectedReportsCount: 0,
      falseReportsCount: 0,
      totalSubmitted: 0,
      joinedDate: new Date().toISOString(),
    };

    // Update reporter submission stats
    reporterProfile.totalSubmitted += 1;

    const newEvent: GlobalEvent = {
      id: `evt-${Date.now()}`,
      title,
      summary: aiAnalysis.executiveSummary,
      description,
      category: (category || aiAnalysis.suggestedCategory) as EventCategory,
      subcategory: subcategory || aiAnalysis.suggestedSubcategory || 'General',
      tags: tags && tags.length ? tags : aiAnalysis.suggestedTags,
      location: {
        country: location.country,
        state: location.state || '',
        city: location.city || '',
        description: location.description || '',
        lat: Number(location.lat),
        lng: Number(location.lng),
      },
      eventDate: eventDate || new Date().toISOString(),
      submissionDate: new Date().toISOString(),
      severity: (severity || (aiAnalysis.riskLevel === 'extreme' ? 'critical' : 'high')) as EventSeverity,
      // Default state is ai_checked -> awaiting admin moderation
      status: user.role === 'admin' ? 'published' : 'ai_checked',
      isHotAlert: severity === 'critical' || aiAnalysis.riskLevel === 'extreme',
      hotScore: severity === 'critical' ? 90 : 70,
      images: images && images.length ? images : ['https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=1200&q=80'],
      sources: sources || [],
      reporterStatement: reporterStatement || 'Field direct submission.',
      reporterId: user.id,
      anonymousReporter: {
        anonymousId: reporterProfile.anonymousId,
        pseudonym: reporterProfile.pseudonym,
        tier: reporterProfile.tier,
      },
      aiAnalysis,
      trustMetrics: {
        upvotes: 0,
        downvotes: 0,
        userVotes: {},
        netTrustScore: 0,
        verificationBadge: 'Under Investigation',
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    events.unshift(newEvent);

    // Record audit log
    auditLogs.unshift({
      id: `audit-${Date.now()}`,
      eventId: newEvent.id,
      action: 'REPORT_SUBMITTED',
      actorRole: user.role,
      actorName: user.name,
      actorId: user.id,
      targetReporterId: user.id,
      reason: `Structured submission received. AI pre-check completed (Confidence: ${Math.round(aiAnalysis.confidence * 100)}%)`,
      timestamp: new Date().toISOString(),
    });

    saveStorage();

    res.status(201).json({
      success: true,
      message: 'Report submitted successfully and analyzed by AI. Queued for moderation.',
      event: newEvent,
    });
  });

  // POST /api/events/:id/vote - Registered Users Vote on Trust
  app.post('/api/events/:id/vote', (req: Request, res: Response) => {
    const user = authenticateUser(req);
    if (!user) {
      return res.status(401).json({ error: 'Only registered users can vote on event trust.' });
    }

    const voteType = req.body.voteType || req.body.type; // 'up' or 'down'
    if (voteType !== 'up' && voteType !== 'down') {
      return res.status(400).json({ error: 'Vote must be "up" or "down".' });
    }

    const event = events.find((e) => e.id === req.params.id);
    if (!event) {
      return res.status(404).json({ error: 'Event not found.' });
    }

    const currentVote = event.trustMetrics.userVotes[user.id];

    // If clicking same vote, toggle it off
    if (currentVote === voteType) {
      delete event.trustMetrics.userVotes[user.id];
      if (voteType === 'up') event.trustMetrics.upvotes -= 1;
      else event.trustMetrics.downvotes -= 1;
    } else {
      // If switching vote
      if (currentVote === 'up') event.trustMetrics.upvotes -= 1;
      if (currentVote === 'down') event.trustMetrics.downvotes -= 1;

      event.trustMetrics.userVotes[user.id] = voteType;
      if (voteType === 'up') event.trustMetrics.upvotes += 1;
      else event.trustMetrics.downvotes += 1;
    }

    event.trustMetrics.netTrustScore = event.trustMetrics.upvotes - event.trustMetrics.downvotes;

    // Recalculate badge if net trust is high
    if (event.trustMetrics.netTrustScore >= 200) {
      event.trustMetrics.verificationBadge = 'Verified';
    } else if (event.trustMetrics.netTrustScore >= 50) {
      event.trustMetrics.verificationBadge = 'Community High-Trust';
    }

    event.updatedAt = new Date().toISOString();
    saveStorage();

    res.json({
      success: true,
      trustMetrics: event.trustMetrics,
    });
  });

  // ----------------------------------------------------
  // ADMIN MODERATION & REPUTATION MANAGEMENT
  // ----------------------------------------------------
  // POST /api/admin/events/:id/moderate
  app.post('/api/admin/events/:id/moderate', (req: Request, res: Response) => {
    const user = authenticateUser(req);
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ error: 'Admin privileges required for moderation.' });
    }

    const { action, reason, isHotAlert } = req.body;
    // action: 'approve' | 'reject' | 'mark_false'

    const event = events.find((e) => e.id === req.params.id);
    if (!event) {
      return res.status(404).json({ error: 'Event not found.' });
    }

    const reporterUser = users.find((u) => u.id === event.reporterId);
    const reporterProfile = reporterUser?.reporterProfile;

    let scoreDelta = 0;
    let actionLabel = '';

    if (action === 'approve') {
      event.status = 'published';
      event.trustMetrics.verificationBadge = 'Verified';
      if (typeof isHotAlert === 'boolean') {
        event.isHotAlert = isHotAlert;
      }
      actionLabel = 'REPORT_APPROVED';

      // Reporter reward logic: For every 3 approved reports -> +10 Trust Score
      if (reporterProfile) {
        reporterProfile.approvedReportsCount += 1;
        if (reporterProfile.approvedReportsCount % 3 === 0) {
          scoreDelta = 10;
          const oldScore = reporterProfile.trustScore;
          reporterProfile.trustScore = Math.min(200, reporterProfile.trustScore + 10);
          reporterProfile.tier = computeTrustTier(reporterProfile.trustScore);

          reporterScoreHistories.unshift({
            id: `hist-${Date.now()}`,
            reporterId: reporterUser!.id,
            eventId: event.id,
            oldScore,
            newScore: reporterProfile.trustScore,
            changeAmount: 10,
            reason: `3 Verified Reports Milestone reached (+10 Trust)`,
            actor: `Admin (${user.name})`,
            timestamp: new Date().toISOString(),
          });
        }
      }
    } else if (action === 'reject') {
      event.status = 'rejected';
      event.rejectionReason = reason || 'Report did not meet corroboration standards or lacked verifiable evidence.';
      actionLabel = 'REPORT_REJECTED';
      if (reporterProfile) {
        reporterProfile.rejectedReportsCount = (reporterProfile.rejectedReportsCount || 0) + 1;
      }
    } else if (action === 'mark_false') {
      event.status = 'confirmed_false';
      (event as any).isRejected = true;
      event.rejectionReason = reason || 'Report confirmed fabricated or containing false intelligence. Moderation status: REJECTED with -25 Trust Penalty.';
      actionLabel = 'REPORT_REJECTED_AS_FALSE';

      // False report penalty: -25 trust score (min 0)
      if (reporterProfile) {
        reporterProfile.rejectedReportsCount = (reporterProfile.rejectedReportsCount || 0) + 1;
        reporterProfile.falseReportsCount += 1;
        scoreDelta = -25;
        const oldScore = reporterProfile.trustScore;
        reporterProfile.trustScore = Math.max(0, reporterProfile.trustScore - 25);
        reporterProfile.tier = computeTrustTier(reporterProfile.trustScore);

        reporterScoreHistories.unshift({
          id: `hist-${Date.now()}`,
          reporterId: reporterUser!.id,
          eventId: event.id,
          oldScore,
          newScore: reporterProfile.trustScore,
          changeAmount: -25,
          reason: `Confirmed false report penalty & rejection (-25 Trust): ${reason || 'Factual inaccuracies detected.'}`,
          actor: `Admin (${user.name})`,
          timestamp: new Date().toISOString(),
        });
      }
    } else {
      return res.status(400).json({ error: 'Invalid action. Must be approve, reject, or mark_false.' });
    }

    event.updatedAt = new Date().toISOString();

    // Log to system audit trail
    auditLogs.unshift({
      id: `audit-${Date.now()}`,
      eventId: event.id,
      action: actionLabel,
      actorRole: 'admin',
      actorName: user.name,
      actorId: user.id,
      targetReporterId: event.reporterId,
      scoreChange: scoreDelta !== 0 ? scoreDelta : undefined,
      reason: reason || `Admin action: ${action}`,
      timestamp: new Date().toISOString(),
    });

    saveStorage();

    res.json({
      success: true,
      message: `Event status updated to ${event.status}`,
      event,
      reporterProfile,
    });
  });

  // POST /api/admin/events/:id/toggle-hot - Toggle hot alert
  app.post('/api/admin/events/:id/toggle-hot', (req: Request, res: Response) => {
    const user = authenticateUser(req);
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ error: 'Admin privileges required.' });
    }

    const event = events.find((e) => e.id === req.params.id);
    if (!event) {
      return res.status(404).json({ error: 'Event not found.' });
    }

    event.isHotAlert = !event.isHotAlert;
    event.updatedAt = new Date().toISOString();

    auditLogs.unshift({
      id: `audit-${Date.now()}`,
      eventId: event.id,
      action: event.isHotAlert ? 'HOT_ALERT_ACTIVATED' : 'HOT_ALERT_DEACTIVATED',
      actorRole: 'admin',
      actorName: user.name,
      actorId: user.id,
      reason: event.isHotAlert ? 'Designated as major high-impact global alert' : 'Demoted from hot alerts',
      timestamp: new Date().toISOString(),
    });

    saveStorage();

    res.json({ success: true, isHotAlert: event.isHotAlert, event });
  });

  // DELETE /api/admin/events/:id - Permanently purge/delete report
  app.delete('/api/admin/events/:id', (req: Request, res: Response) => {
    const user = authenticateUser(req);
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ error: 'Admin privileges required to permanently delete intelligence reports.' });
    }

    const idx = events.findIndex((e) => e.id === req.params.id);
    if (idx === -1) {
      return res.status(404).json({ error: 'Event not found.' });
    }

    const [deleted] = events.splice(idx, 1);

    auditLogs.unshift({
      id: `audit-${Date.now()}`,
      eventId: deleted.id,
      action: 'REPORT_DELETED',
      actorRole: 'admin',
      actorName: user.name,
      actorId: user.id,
      targetReporterId: deleted.reporterId,
      reason: `Report permanently deleted from Watchtower registry by Director (${user.name})`,
      timestamp: new Date().toISOString(),
    });

    saveStorage();

    res.json({
      success: true,
      message: 'Event permanently purged from database.',
      eventId: deleted.id,
    });
  });

  // GET /api/admin/reporters - Admin list of all field reporters with true identity
  app.get('/api/admin/reporters', (req: Request, res: Response) => {
    const user = authenticateUser(req);
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ error: 'Admin privileges required to view reporter identities.' });
    }

    const reporters = users
      .filter((u) => u.role === 'field-reporter')
      .map((u) => ({
        id: u.id,
        codeName: u.codeName || u.reporterProfile?.pseudonym || u.name,
        designation: u.designation || 'Field Reporter',
        realName: u.codeName || u.reporterProfile?.pseudonym || u.name,
        realEmail: u.email,
        createdAt: u.createdAt,
        profile: u.reporterProfile,
        scoreHistories: reporterScoreHistories.filter((h) => h.reporterId === u.id),
      }));

    res.json({ success: true, count: reporters.length, reporters });
  });

  // GET /api/admin/audit-logs
  app.get('/api/admin/audit-logs', (req: Request, res: Response) => {
    const user = authenticateUser(req);
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ error: 'Admin privileges required.' });
    }
    res.json({ success: true, count: auditLogs.length, auditLogs });
  });

  // ----------------------------------------------------
  // VITE MIDDLEWARE / STATIC ASSETS
  // ----------------------------------------------------
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`EventGrid Intelligence Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
